#
# TABLE STRUCTURE FOR: areas
#

DROP TABLE IF EXISTS `areas`;

CREATE TABLE `areas` (
  `area_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`area_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `areas` (`area_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('1', 'RUC', '2017-07-24 00:55:04', '0000-00-00 00:00:00', '1');
INSERT INTO `areas` (`area_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('2', 'CERTIFICACIÓN', '2017-07-24 00:55:06', '2017-08-30 10:45:42', '1');
INSERT INTO `areas` (`area_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('3', 'AFILIACIÓN', '2017-07-24 00:55:22', '2017-08-30 10:45:52', '1');
INSERT INTO `areas` (`area_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('4', 'CAPACITACIÓN', '2017-08-30 10:45:57', '0000-00-00 00:00:00', '1');
INSERT INTO `areas` (`area_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('5', 'NO APLICA', '2017-08-30 10:46:09', '0000-00-00 00:00:00', '1');


#
# TABLE STRUCTURE FOR: arl
#

DROP TABLE IF EXISTS `arl`;

CREATE TABLE `arl` (
  `arl_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`arl_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `arl` (`arl_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('1', 'No Aplica', '2017-07-26 11:30:53', '2017-07-26 11:31:32', '1');
INSERT INTO `arl` (`arl_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('2', 'Positiva', '2017-07-26 11:30:58', '0000-00-00 00:00:00', '1');
INSERT INTO `arl` (`arl_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('3', 'Bolivar', '2017-07-26 11:31:08', '0000-00-00 00:00:00', '1');
INSERT INTO `arl` (`arl_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('4', 'Mapre', '2017-07-26 11:32:12', '0000-00-00 00:00:00', '1');


#
# TABLE STRUCTURE FOR: check_state_events
#

DROP TABLE IF EXISTS `check_state_events`;

CREATE TABLE `check_state_events` (
  `check_state_event_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `user_id` bigint(20) NOT NULL,
  PRIMARY KEY (`check_state_event_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

INSERT INTO `check_state_events` (`check_state_event_id`, `date`, `created_at`, `updated_at`, `user_id`) VALUES ('26', '2018-01-10', '2018-01-10 13:33:57', '0000-00-00 00:00:00', '1');
INSERT INTO `check_state_events` (`check_state_event_id`, `date`, `created_at`, `updated_at`, `user_id`) VALUES ('27', '2018-01-16', '2018-01-16 10:49:37', '0000-00-00 00:00:00', '1');


#
# TABLE STRUCTURE FOR: cities
#

DROP TABLE IF EXISTS `cities`;

CREATE TABLE `cities` (
  `city_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `country_code` varchar(5) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`city_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4588 DEFAULT CHARSET=utf8;

INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1', 'Kabul', 'AFG', '2016-12-13 11:13:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2', 'Qandahar', 'AFG', '2016-12-13 11:13:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3', 'Herat', 'AFG', '2016-12-13 11:13:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4', 'Mazar-e-Sharif', 'AFG', '2016-12-13 11:13:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('5', 'Amsterdam', 'NLD', '2016-12-13 11:13:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('6', 'Rotterdam', 'NLD', '2016-12-13 11:13:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('7', 'Haag', 'NLD', '2016-12-13 11:13:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('8', 'Utrecht', 'NLD', '2016-12-13 11:13:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('9', 'Eindhoven', 'NLD', '2016-12-13 11:13:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('10', 'Tilburg', 'NLD', '2016-12-13 11:13:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('11', 'Groningen', 'NLD', '2016-12-13 11:13:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('12', 'Breda', 'NLD', '2016-12-13 11:13:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('13', 'Apeldoorn', 'NLD', '2016-12-13 11:13:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('14', 'Nijmegen', 'NLD', '2016-12-13 11:13:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('15', 'Enschede', 'NLD', '2016-12-13 11:13:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('16', 'Haarlem', 'NLD', '2016-12-13 11:13:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('17', 'Almere', 'NLD', '2016-12-13 11:13:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('18', 'Arnhem', 'NLD', '2016-12-13 11:13:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('19', 'Zaanstad', 'NLD', '2016-12-13 11:13:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('20', 'Â´s-Hertogenbosch', 'NLD', '2016-12-13 11:13:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('21', 'Amersfoort', 'NLD', '2016-12-13 11:13:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('22', 'Maastricht', 'NLD', '2016-12-13 11:13:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('23', 'Dordrecht', 'NLD', '2016-12-13 11:13:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('24', 'Leiden', 'NLD', '2016-12-13 11:13:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('25', 'Haarlemmermeer', 'NLD', '2016-12-13 11:13:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('26', 'Zoetermeer', 'NLD', '2016-12-13 11:13:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('27', 'Emmen', 'NLD', '2016-12-13 11:13:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('28', 'Zwolle', 'NLD', '2016-12-13 11:13:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('29', 'Ede', 'NLD', '2016-12-13 11:13:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('30', 'Delft', 'NLD', '2016-12-13 11:13:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('31', 'Heerlen', 'NLD', '2016-12-13 11:13:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('32', 'Alkmaar', 'NLD', '2016-12-13 11:13:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('33', 'Willemstad', 'ANT', '2016-12-13 11:13:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('34', 'Tirana', 'ALB', '2016-12-13 11:13:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('35', 'Alger', 'DZA', '2016-12-13 11:13:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('36', 'Oran', 'DZA', '2016-12-13 11:13:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('37', 'Constantine', 'DZA', '2016-12-13 11:13:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('38', 'Annaba', 'DZA', '2016-12-13 11:13:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('39', 'Batna', 'DZA', '2016-12-13 11:13:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('40', 'SÃ©tif', 'DZA', '2016-12-13 11:13:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('41', 'Sidi Bel AbbÃ¨s', 'DZA', '2016-12-13 11:13:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('42', 'Skikda', 'DZA', '2016-12-13 11:13:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('43', 'Biskra', 'DZA', '2016-12-13 11:13:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('44', 'Blida (el-Boulaida)', 'DZA', '2016-12-13 11:13:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('45', 'BÃ©jaÃ¯a', 'DZA', '2016-12-13 11:13:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('46', 'Mostaganem', 'DZA', '2016-12-13 11:13:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('47', 'TÃ©bessa', 'DZA', '2016-12-13 11:13:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('48', 'Tlemcen (Tilimsen)', 'DZA', '2016-12-13 11:13:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('49', 'BÃ©char', 'DZA', '2016-12-13 11:13:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('50', 'Tiaret', 'DZA', '2016-12-13 11:13:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('51', 'Ech-Chleff (el-Asnam)', 'DZA', '2016-12-13 11:13:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('52', 'GhardaÃ¯a', 'DZA', '2016-12-13 11:13:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('53', 'Tafuna', 'ASM', '2016-12-13 11:13:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('54', 'Fagatogo', 'ASM', '2016-12-13 11:13:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('55', 'Andorra la Vella', 'AND', '2016-12-13 11:13:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('56', 'Luanda', 'AGO', '2016-12-13 11:13:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('57', 'Huambo', 'AGO', '2016-12-13 11:13:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('58', 'Lobito', 'AGO', '2016-12-13 11:13:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('59', 'Benguela', 'AGO', '2016-12-13 11:13:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('60', 'Namibe', 'AGO', '2016-12-13 11:13:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('61', 'South Hill', 'AIA', '2016-12-13 11:13:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('62', 'The Valley', 'AIA', '2016-12-13 11:13:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('63', 'Saint JohnÂ´s', 'ATG', '2016-12-13 11:13:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('64', 'Dubai', 'ARE', '2016-12-13 11:13:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('65', 'Abu Dhabi', 'ARE', '2016-12-13 11:13:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('66', 'Sharja', 'ARE', '2016-12-13 11:13:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('67', 'al-Ayn', 'ARE', '2016-12-13 11:13:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('68', 'Ajman', 'ARE', '2016-12-13 11:13:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('69', 'Buenos Aires', 'ARG', '2016-12-13 11:13:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('70', 'La Matanza', 'ARG', '2016-12-13 11:13:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('71', 'Córdoba', 'ARG', '2016-12-13 11:39:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('72', 'Rosario', 'ARG', '2016-12-13 11:13:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('73', 'Lomas de Zamora', 'ARG', '2016-12-13 11:13:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('74', 'Quilmes', 'ARG', '2016-12-13 11:13:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('75', 'Almirante Brown', 'ARG', '2016-12-13 11:13:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('76', 'La Plata', 'ARG', '2016-12-13 11:13:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('77', 'Mar del Plata', 'ARG', '2016-12-13 11:13:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('78', 'San Miguel de Tucumán', 'ARG', '2016-12-13 11:39:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('79', 'Lanús', 'ARG', '2016-12-13 11:39:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('80', 'Merlo', 'ARG', '2016-12-13 11:13:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('81', 'General San Martín', 'ARG', '2016-12-13 11:39:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('82', 'Salta', 'ARG', '2016-12-13 11:13:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('83', 'Moreno', 'ARG', '2016-12-13 11:13:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('84', 'Santa Fé', 'ARG', '2016-12-13 11:39:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('85', 'Avellaneda', 'ARG', '2016-12-13 11:13:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('86', 'Tres de Febrero', 'ARG', '2016-12-13 11:13:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('87', 'Morón', 'ARG', '2016-12-13 11:39:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('88', 'Florencio Varela', 'ARG', '2016-12-13 11:13:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('89', 'San Isidro', 'ARG', '2016-12-13 11:13:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('90', 'Tigre', 'ARG', '2016-12-13 11:13:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('91', 'Malvinas Argentinas', 'ARG', '2016-12-13 11:13:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('92', 'Vicente López', 'ARG', '2016-12-13 11:39:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('93', 'Berazategui', 'ARG', '2016-12-13 11:13:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('94', 'Corrientes', 'ARG', '2016-12-13 11:13:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('95', 'San Miguel', 'ARG', '2016-12-13 11:13:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('96', 'Bahía Blanca', 'ARG', '2016-12-13 11:40:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('97', 'Esteban Echeverría', 'ARG', '2016-12-13 11:40:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('98', 'Resistencia', 'ARG', '2016-12-13 11:13:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('99', 'José C. Paz', 'ARG', '2016-12-13 11:40:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('100', 'Paraná', 'ARG', '2016-12-13 11:40:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('101', 'Godoy Cruz', 'ARG', '2016-12-13 11:13:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('102', 'Posadas', 'ARG', '2016-12-13 11:13:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('103', 'Guaymallón', 'ARG', '2016-12-13 11:40:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('104', 'Santiago del Estero', 'ARG', '2016-12-13 11:13:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('105', 'San Salvador de Jujuy', 'ARG', '2016-12-13 11:13:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('106', 'Hurlingham', 'ARG', '2016-12-13 11:13:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('107', 'Neuquón', 'ARG', '2016-12-13 11:45:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('108', 'Ituzaingá', 'ARG', '2016-12-13 11:46:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('109', 'San Fernando', 'ARG', '2016-12-13 11:13:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('110', 'Formosa', 'ARG', '2016-12-13 11:13:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('111', 'Las Heras', 'ARG', '2016-12-13 11:13:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('112', 'La Rioja', 'ARG', '2016-12-13 11:13:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('113', 'San Fernando del Valle de Cata', 'ARG', '2016-12-13 11:13:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('114', 'Río Cuarto', 'ARG', '2016-12-13 11:46:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('115', 'Comodoro Rivadavia', 'ARG', '2016-12-13 11:13:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('116', 'Mendoza', 'ARG', '2016-12-13 11:13:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('117', 'San Nicolás de los Arroyos', 'ARG', '2016-12-13 11:46:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('118', 'San Juan', 'ARG', '2016-12-13 11:13:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('119', 'Escobar', 'ARG', '2016-12-13 11:13:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('120', 'Concordia', 'ARG', '2016-12-13 11:13:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('121', 'Pilar', 'ARG', '2016-12-13 11:13:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('122', 'San Luis', 'ARG', '2016-12-13 11:13:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('123', 'Ezeiza', 'ARG', '2016-12-13 11:13:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('124', 'San Rafael', 'ARG', '2016-12-13 11:13:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('125', 'Tandil', 'ARG', '2016-12-13 11:13:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('126', 'Yerevan', 'ARM', '2016-12-13 11:13:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('127', 'Gjumri', 'ARM', '2016-12-13 11:13:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('128', 'Vanadzor', 'ARM', '2016-12-13 11:13:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('129', 'Oranjestad', 'ABW', '2016-12-13 11:13:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('130', 'Sydney', 'AUS', '2016-12-13 11:13:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('131', 'Melbourne', 'AUS', '2016-12-13 11:13:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('132', 'Brisbane', 'AUS', '2016-12-13 11:13:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('133', 'Perth', 'AUS', '2016-12-13 11:13:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('134', 'Adelaide', 'AUS', '2016-12-13 11:13:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('135', 'Canberra', 'AUS', '2016-12-13 11:13:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('136', 'Gold Coast', 'AUS', '2016-12-13 11:13:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('137', 'Newcastle', 'AUS', '2016-12-13 11:13:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('138', 'Central Coast', 'AUS', '2016-12-13 11:13:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('139', 'Wollongong', 'AUS', '2016-12-13 11:13:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('140', 'Hobart', 'AUS', '2016-12-13 11:13:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('141', 'Geelong', 'AUS', '2016-12-13 11:13:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('142', 'Townsville', 'AUS', '2016-12-13 11:13:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('143', 'Cairns', 'AUS', '2016-12-13 11:13:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('144', 'Baku', 'AZE', '2016-12-13 11:13:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('145', 'GÃ¤ncÃ¤', 'AZE', '2016-12-13 11:13:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('146', 'Sumqayit', 'AZE', '2016-12-13 11:13:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('147', 'MingÃ¤Ã§evir', 'AZE', '2016-12-13 11:13:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('148', 'Nassau', 'BHS', '2016-12-13 11:13:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('149', 'al-Manama', 'BHR', '2016-12-13 11:13:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('150', 'Dhaka', 'BGD', '2016-12-13 11:13:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('151', 'Chittagong', 'BGD', '2016-12-13 11:13:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('152', 'Khulna', 'BGD', '2016-12-13 11:13:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('153', 'Rajshahi', 'BGD', '2016-12-13 11:13:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('154', 'Narayanganj', 'BGD', '2016-12-13 11:13:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('155', 'Rangpur', 'BGD', '2016-12-13 11:13:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('156', 'Mymensingh', 'BGD', '2016-12-13 11:13:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('157', 'Barisal', 'BGD', '2016-12-13 11:13:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('158', 'Tungi', 'BGD', '2016-12-13 11:13:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('159', 'Jessore', 'BGD', '2016-12-13 11:13:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('160', 'Comilla', 'BGD', '2016-12-13 11:13:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('161', 'Nawabganj', 'BGD', '2016-12-13 11:13:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('162', 'Dinajpur', 'BGD', '2016-12-13 11:13:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('163', 'Bogra', 'BGD', '2016-12-13 11:13:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('164', 'Sylhet', 'BGD', '2016-12-13 11:13:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('165', 'Brahmanbaria', 'BGD', '2016-12-13 11:13:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('166', 'Tangail', 'BGD', '2016-12-13 11:13:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('167', 'Jamalpur', 'BGD', '2016-12-13 11:13:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('168', 'Pabna', 'BGD', '2016-12-13 11:13:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('169', 'Naogaon', 'BGD', '2016-12-13 11:13:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('170', 'Sirajganj', 'BGD', '2016-12-13 11:13:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('171', 'Narsinghdi', 'BGD', '2016-12-13 11:13:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('172', 'Saidpur', 'BGD', '2016-12-13 11:13:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('173', 'Gazipur', 'BGD', '2016-12-13 11:13:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('174', 'Bridgetown', 'BRB', '2016-12-13 11:13:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('175', 'Antwerpen', 'BEL', '2016-12-13 11:13:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('176', 'Gent', 'BEL', '2016-12-13 11:13:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('177', 'Charleroi', 'BEL', '2016-12-13 11:13:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('178', 'LiÃ¨ge', 'BEL', '2016-12-13 11:13:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('179', 'Bruxelles [Brussel]', 'BEL', '2016-12-13 11:13:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('180', 'Brugge', 'BEL', '2016-12-13 11:13:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('181', 'Schaerbeek', 'BEL', '2016-12-13 11:13:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('182', 'Namur', 'BEL', '2016-12-13 11:13:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('183', 'Mons', 'BEL', '2016-12-13 11:13:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('184', 'Belize City', 'BLZ', '2016-12-13 11:13:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('185', 'Belmopan', 'BLZ', '2016-12-13 11:13:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('186', 'Cotonou', 'BEN', '2016-12-13 11:13:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('187', 'Porto-Novo', 'BEN', '2016-12-13 11:13:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('188', 'Djougou', 'BEN', '2016-12-13 11:13:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('189', 'Parakou', 'BEN', '2016-12-13 11:13:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('190', 'Saint George', 'BMU', '2016-12-13 11:13:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('191', 'Hamilton', 'BMU', '2016-12-13 11:13:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('192', 'Thimphu', 'BTN', '2016-12-13 11:13:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('193', 'Santa Cruz de la Sierra', 'BOL', '2016-12-13 11:13:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('194', 'La Paz', 'BOL', '2016-12-13 11:13:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('195', 'El Alto', 'BOL', '2016-12-13 11:13:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('196', 'Cochabamba', 'BOL', '2016-12-13 11:13:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('197', 'Oruro', 'BOL', '2016-12-13 11:13:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('198', 'Sucre', 'BOL', '2016-12-13 11:13:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('199', 'PotosÃ­', 'BOL', '2016-12-13 11:13:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('200', 'Tarija', 'BOL', '2016-12-13 11:13:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('201', 'Sarajevo', 'BIH', '2016-12-13 11:13:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('202', 'Banja Luka', 'BIH', '2016-12-13 11:13:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('203', 'Zenica', 'BIH', '2016-12-13 11:13:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('204', 'Gaborone', 'BWA', '2016-12-13 11:13:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('205', 'Francistown', 'BWA', '2016-12-13 11:13:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('206', 'SÃ£o Paulo', 'BRA', '2016-12-13 11:13:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('207', 'Rio de Janeiro', 'BRA', '2016-12-13 11:13:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('208', 'Salvador', 'BRA', '2016-12-13 11:13:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('209', 'Belo Horizonte', 'BRA', '2016-12-13 11:13:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('210', 'Fortaleza', 'BRA', '2016-12-13 11:13:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('211', 'BrasÃ­lia', 'BRA', '2016-12-13 11:13:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('212', 'Curitiba', 'BRA', '2016-12-13 11:13:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('213', 'Recife', 'BRA', '2016-12-13 11:13:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('214', 'Porto Alegre', 'BRA', '2016-12-13 11:13:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('215', 'Manaus', 'BRA', '2016-12-13 11:13:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('216', 'BelÃ©m', 'BRA', '2016-12-13 11:13:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('217', 'Guarulhos', 'BRA', '2016-12-13 11:13:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('218', 'GoiÃ¢nia', 'BRA', '2016-12-13 11:13:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('219', 'Campinas', 'BRA', '2016-12-13 11:13:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('220', 'SÃ£o GonÃ§alo', 'BRA', '2016-12-13 11:13:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('221', 'Nova IguaÃ§u', 'BRA', '2016-12-13 11:13:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('222', 'SÃ£o LuÃ­s', 'BRA', '2016-12-13 11:13:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('223', 'MaceiÃ³', 'BRA', '2016-12-13 11:13:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('224', 'Duque de Caxias', 'BRA', '2016-12-13 11:13:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('225', 'SÃ£o Bernardo do Campo', 'BRA', '2016-12-13 11:13:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('226', 'Teresina', 'BRA', '2016-12-13 11:13:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('227', 'Natal', 'BRA', '2016-12-13 11:13:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('228', 'Osasco', 'BRA', '2016-12-13 11:13:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('229', 'Campo Grande', 'BRA', '2016-12-13 11:13:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('230', 'Santo AndrÃ©', 'BRA', '2016-12-13 11:13:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('231', 'JoÃ£o Pessoa', 'BRA', '2016-12-13 11:13:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('232', 'JaboatÃ£o dos Guararapes', 'BRA', '2016-12-13 11:13:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('233', 'Contagem', 'BRA', '2016-12-13 11:13:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('234', 'SÃ£o JosÃ© dos Campos', 'BRA', '2016-12-13 11:13:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('235', 'UberlÃ¢ndia', 'BRA', '2016-12-13 11:13:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('236', 'Feira de Santana', 'BRA', '2016-12-13 11:13:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('237', 'RibeirÃ£o Preto', 'BRA', '2016-12-13 11:13:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('238', 'Sorocaba', 'BRA', '2016-12-13 11:13:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('239', 'NiterÃ³i', 'BRA', '2016-12-13 11:13:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('240', 'CuiabÃ¡', 'BRA', '2016-12-13 11:13:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('241', 'Juiz de Fora', 'BRA', '2016-12-13 11:13:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('242', 'Aracaju', 'BRA', '2016-12-13 11:13:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('243', 'SÃ£o JoÃ£o de Meriti', 'BRA', '2016-12-13 11:13:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('244', 'Londrina', 'BRA', '2016-12-13 11:13:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('245', 'Joinville', 'BRA', '2016-12-13 11:13:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('246', 'Belford Roxo', 'BRA', '2016-12-13 11:13:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('247', 'Santos', 'BRA', '2016-12-13 11:13:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('248', 'Ananindeua', 'BRA', '2016-12-13 11:13:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('249', 'Campos dos Goytacazes', 'BRA', '2016-12-13 11:13:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('250', 'MauÃ¡', 'BRA', '2016-12-13 11:13:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('251', 'CarapicuÃ­ba', 'BRA', '2016-12-13 11:13:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('252', 'Olinda', 'BRA', '2016-12-13 11:13:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('253', 'Campina Grande', 'BRA', '2016-12-13 11:13:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('254', 'SÃ£o JosÃ© do Rio Preto', 'BRA', '2016-12-13 11:13:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('255', 'Caxias do Sul', 'BRA', '2016-12-13 11:13:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('256', 'Moji das Cruzes', 'BRA', '2016-12-13 11:13:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('257', 'Diadema', 'BRA', '2016-12-13 11:13:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('258', 'Aparecida de GoiÃ¢nia', 'BRA', '2016-12-13 11:13:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('259', 'Piracicaba', 'BRA', '2016-12-13 11:13:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('260', 'Cariacica', 'BRA', '2016-12-13 11:13:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('261', 'Vila Velha', 'BRA', '2016-12-13 11:13:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('262', 'Pelotas', 'BRA', '2016-12-13 11:13:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('263', 'Bauru', 'BRA', '2016-12-13 11:13:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('264', 'Porto Velho', 'BRA', '2016-12-13 11:13:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('265', 'Serra', 'BRA', '2016-12-13 11:13:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('266', 'Betim', 'BRA', '2016-12-13 11:13:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('267', 'JundÃ­aÃ­', 'BRA', '2016-12-13 11:13:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('268', 'Canoas', 'BRA', '2016-12-13 11:13:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('269', 'Franca', 'BRA', '2016-12-13 11:13:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('270', 'SÃ£o Vicente', 'BRA', '2016-12-13 11:13:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('271', 'MaringÃ¡', 'BRA', '2016-12-13 11:13:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('272', 'Montes Claros', 'BRA', '2016-12-13 11:13:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('273', 'AnÃ¡polis', 'BRA', '2016-12-13 11:13:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('274', 'FlorianÃ³polis', 'BRA', '2016-12-13 11:13:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('275', 'PetrÃ³polis', 'BRA', '2016-12-13 11:13:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('276', 'Itaquaquecetuba', 'BRA', '2016-12-13 11:13:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('277', 'VitÃ³ria', 'BRA', '2016-12-13 11:13:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('278', 'Ponta Grossa', 'BRA', '2016-12-13 11:13:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('279', 'Rio Branco', 'BRA', '2016-12-13 11:13:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('280', 'Foz do IguaÃ§u', 'BRA', '2016-12-13 11:13:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('281', 'MacapÃ¡', 'BRA', '2016-12-13 11:13:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('282', 'IlhÃ©us', 'BRA', '2016-12-13 11:13:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('283', 'VitÃ³ria da Conquista', 'BRA', '2016-12-13 11:13:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('284', 'Uberaba', 'BRA', '2016-12-13 11:13:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('285', 'Paulista', 'BRA', '2016-12-13 11:13:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('286', 'Limeira', 'BRA', '2016-12-13 11:13:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('287', 'Blumenau', 'BRA', '2016-12-13 11:14:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('288', 'Caruaru', 'BRA', '2016-12-13 11:14:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('289', 'SantarÃ©m', 'BRA', '2016-12-13 11:14:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('290', 'Volta Redonda', 'BRA', '2016-12-13 11:14:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('291', 'Novo Hamburgo', 'BRA', '2016-12-13 11:14:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('292', 'Caucaia', 'BRA', '2016-12-13 11:14:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('293', 'Santa Maria', 'BRA', '2016-12-13 11:14:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('294', 'Cascavel', 'BRA', '2016-12-13 11:14:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('295', 'GuarujÃ¡', 'BRA', '2016-12-13 11:14:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('296', 'RibeirÃ£o das Neves', 'BRA', '2016-12-13 11:14:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('297', 'Governador Valadares', 'BRA', '2016-12-13 11:14:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('298', 'TaubatÃ©', 'BRA', '2016-12-13 11:14:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('299', 'Imperatriz', 'BRA', '2016-12-13 11:14:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('300', 'GravataÃ­', 'BRA', '2016-12-13 11:14:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('301', 'Embu', 'BRA', '2016-12-13 11:14:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('302', 'MossorÃ³', 'BRA', '2016-12-13 11:14:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('303', 'VÃ¡rzea Grande', 'BRA', '2016-12-13 11:14:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('304', 'Petrolina', 'BRA', '2016-12-13 11:14:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('305', 'Barueri', 'BRA', '2016-12-13 11:14:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('306', 'ViamÃ£o', 'BRA', '2016-12-13 11:14:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('307', 'Ipatinga', 'BRA', '2016-12-13 11:14:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('308', 'Juazeiro', 'BRA', '2016-12-13 11:14:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('309', 'Juazeiro do Norte', 'BRA', '2016-12-13 11:14:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('310', 'TaboÃ£o da Serra', 'BRA', '2016-12-13 11:14:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('311', 'SÃ£o JosÃ© dos Pinhais', 'BRA', '2016-12-13 11:14:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('312', 'MagÃ©', 'BRA', '2016-12-13 11:14:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('313', 'Suzano', 'BRA', '2016-12-13 11:14:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('314', 'SÃ£o Leopoldo', 'BRA', '2016-12-13 11:14:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('315', 'MarÃ­lia', 'BRA', '2016-12-13 11:14:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('316', 'SÃ£o Carlos', 'BRA', '2016-12-13 11:14:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('317', 'SumarÃ©', 'BRA', '2016-12-13 11:14:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('318', 'Presidente Prudente', 'BRA', '2016-12-13 11:14:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('319', 'DivinÃ³polis', 'BRA', '2016-12-13 11:14:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('320', 'Sete Lagoas', 'BRA', '2016-12-13 11:14:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('321', 'Rio Grande', 'BRA', '2016-12-13 11:14:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('322', 'Itabuna', 'BRA', '2016-12-13 11:14:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('323', 'JequiÃ©', 'BRA', '2016-12-13 11:14:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('324', 'Arapiraca', 'BRA', '2016-12-13 11:14:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('325', 'Colombo', 'BRA', '2016-12-13 11:14:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('326', 'Americana', 'BRA', '2016-12-13 11:14:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('327', 'Alvorada', 'BRA', '2016-12-13 11:14:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('328', 'Araraquara', 'BRA', '2016-12-13 11:14:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('329', 'ItaboraÃ­', 'BRA', '2016-12-13 11:14:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('330', 'Santa BÃ¡rbara dÂ´Oeste', 'BRA', '2016-12-13 11:14:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('331', 'Nova Friburgo', 'BRA', '2016-12-13 11:14:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('332', 'JacareÃ­', 'BRA', '2016-12-13 11:14:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('333', 'AraÃ§atuba', 'BRA', '2016-12-13 11:14:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('334', 'Barra Mansa', 'BRA', '2016-12-13 11:14:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('335', 'Praia Grande', 'BRA', '2016-12-13 11:14:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('336', 'MarabÃ¡', 'BRA', '2016-12-13 11:14:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('337', 'CriciÃºma', 'BRA', '2016-12-13 11:14:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('338', 'Boa Vista', 'BRA', '2016-12-13 11:14:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('339', 'Passo Fundo', 'BRA', '2016-12-13 11:14:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('340', 'Dourados', 'BRA', '2016-12-13 11:14:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('341', 'Santa Luzia', 'BRA', '2016-12-13 11:14:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('342', 'Rio Claro', 'BRA', '2016-12-13 11:14:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('343', 'MaracanaÃº', 'BRA', '2016-12-13 11:14:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('344', 'Guarapuava', 'BRA', '2016-12-13 11:14:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('345', 'RondonÃ³polis', 'BRA', '2016-12-13 11:14:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('346', 'SÃ£o JosÃ©', 'BRA', '2016-12-13 11:14:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('347', 'Cachoeiro de Itapemirim', 'BRA', '2016-12-13 11:14:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('348', 'NilÃ³polis', 'BRA', '2016-12-13 11:14:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('349', 'Itapevi', 'BRA', '2016-12-13 11:14:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('350', 'Cabo de Santo Agostinho', 'BRA', '2016-12-13 11:14:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('351', 'CamaÃ§ari', 'BRA', '2016-12-13 11:14:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('352', 'Sobral', 'BRA', '2016-12-13 11:14:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('353', 'ItajaÃ­', 'BRA', '2016-12-13 11:14:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('354', 'ChapecÃ³', 'BRA', '2016-12-13 11:14:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('355', 'Cotia', 'BRA', '2016-12-13 11:14:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('356', 'Lages', 'BRA', '2016-12-13 11:14:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('357', 'Ferraz de Vasconcelos', 'BRA', '2016-12-13 11:14:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('358', 'Indaiatuba', 'BRA', '2016-12-13 11:14:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('359', 'HortolÃ¢ndia', 'BRA', '2016-12-13 11:14:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('360', 'Caxias', 'BRA', '2016-12-13 11:14:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('361', 'SÃ£o Caetano do Sul', 'BRA', '2016-12-13 11:14:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('362', 'Itu', 'BRA', '2016-12-13 11:14:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('363', 'Nossa Senhora do Socorro', 'BRA', '2016-12-13 11:14:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('364', 'ParnaÃ­ba', 'BRA', '2016-12-13 11:14:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('365', 'PoÃ§os de Caldas', 'BRA', '2016-12-13 11:14:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('366', 'TeresÃ³polis', 'BRA', '2016-12-13 11:14:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('367', 'Barreiras', 'BRA', '2016-12-13 11:14:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('368', 'Castanhal', 'BRA', '2016-12-13 11:14:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('369', 'Alagoinhas', 'BRA', '2016-12-13 11:14:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('370', 'Itapecerica da Serra', 'BRA', '2016-12-13 11:14:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('371', 'Uruguaiana', 'BRA', '2016-12-13 11:14:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('372', 'ParanaguÃ¡', 'BRA', '2016-12-13 11:14:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('373', 'IbiritÃ©', 'BRA', '2016-12-13 11:14:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('374', 'Timon', 'BRA', '2016-12-13 11:14:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('375', 'LuziÃ¢nia', 'BRA', '2016-12-13 11:14:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('376', 'MacaÃ©', 'BRA', '2016-12-13 11:14:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('377', 'TeÃ³filo Otoni', 'BRA', '2016-12-13 11:14:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('378', 'Moji-GuaÃ§u', 'BRA', '2016-12-13 11:14:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('379', 'Palmas', 'BRA', '2016-12-13 11:14:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('380', 'Pindamonhangaba', 'BRA', '2016-12-13 11:14:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('381', 'Francisco Morato', 'BRA', '2016-12-13 11:14:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('382', 'BagÃ©', 'BRA', '2016-12-13 11:14:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('383', 'Sapucaia do Sul', 'BRA', '2016-12-13 11:14:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('384', 'Cabo Frio', 'BRA', '2016-12-13 11:14:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('385', 'Itapetininga', 'BRA', '2016-12-13 11:14:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('386', 'Patos de Minas', 'BRA', '2016-12-13 11:14:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('387', 'Camaragibe', 'BRA', '2016-12-13 11:14:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('388', 'BraganÃ§a Paulista', 'BRA', '2016-12-13 11:14:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('389', 'Queimados', 'BRA', '2016-12-13 11:14:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('390', 'AraguaÃ­na', 'BRA', '2016-12-13 11:14:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('391', 'Garanhuns', 'BRA', '2016-12-13 11:14:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('392', 'VitÃ³ria de Santo AntÃ£o', 'BRA', '2016-12-13 11:14:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('393', 'Santa Rita', 'BRA', '2016-12-13 11:14:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('394', 'Barbacena', 'BRA', '2016-12-13 11:14:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('395', 'Abaetetuba', 'BRA', '2016-12-13 11:14:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('396', 'JaÃº', 'BRA', '2016-12-13 11:14:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('397', 'Lauro de Freitas', 'BRA', '2016-12-13 11:14:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('398', 'Franco da Rocha', 'BRA', '2016-12-13 11:14:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('399', 'Teixeira de Freitas', 'BRA', '2016-12-13 11:14:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('400', 'Varginha', 'BRA', '2016-12-13 11:14:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('401', 'RibeirÃ£o Pires', 'BRA', '2016-12-13 11:14:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('402', 'SabarÃ¡', 'BRA', '2016-12-13 11:14:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('403', 'Catanduva', 'BRA', '2016-12-13 11:14:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('404', 'Rio Verde', 'BRA', '2016-12-13 11:14:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('405', 'Botucatu', 'BRA', '2016-12-13 11:14:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('406', 'Colatina', 'BRA', '2016-12-13 11:14:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('407', 'Santa Cruz do Sul', 'BRA', '2016-12-13 11:14:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('408', 'Linhares', 'BRA', '2016-12-13 11:14:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('409', 'Apucarana', 'BRA', '2016-12-13 11:14:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('410', 'Barretos', 'BRA', '2016-12-13 11:14:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('411', 'GuaratinguetÃ¡', 'BRA', '2016-12-13 11:14:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('412', 'Cachoeirinha', 'BRA', '2016-12-13 11:14:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('413', 'CodÃ³', 'BRA', '2016-12-13 11:14:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('414', 'JaraguÃ¡ do Sul', 'BRA', '2016-12-13 11:14:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('415', 'CubatÃ£o', 'BRA', '2016-12-13 11:14:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('416', 'Itabira', 'BRA', '2016-12-13 11:14:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('417', 'Itaituba', 'BRA', '2016-12-13 11:14:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('418', 'Araras', 'BRA', '2016-12-13 11:14:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('419', 'Resende', 'BRA', '2016-12-13 11:14:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('420', 'Atibaia', 'BRA', '2016-12-13 11:14:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('421', 'Pouso Alegre', 'BRA', '2016-12-13 11:14:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('422', 'Toledo', 'BRA', '2016-12-13 11:14:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('423', 'Crato', 'BRA', '2016-12-13 11:14:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('424', 'Passos', 'BRA', '2016-12-13 11:14:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('425', 'Araguari', 'BRA', '2016-12-13 11:14:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('426', 'SÃ£o JosÃ© de Ribamar', 'BRA', '2016-12-13 11:14:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('427', 'Pinhais', 'BRA', '2016-12-13 11:14:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('428', 'SertÃ£ozinho', 'BRA', '2016-12-13 11:14:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('429', 'Conselheiro Lafaiete', 'BRA', '2016-12-13 11:14:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('430', 'Paulo Afonso', 'BRA', '2016-12-13 11:14:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('431', 'Angra dos Reis', 'BRA', '2016-12-13 11:14:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('432', 'EunÃ¡polis', 'BRA', '2016-12-13 11:14:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('433', 'Salto', 'BRA', '2016-12-13 11:14:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('434', 'Ourinhos', 'BRA', '2016-12-13 11:14:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('435', 'Parnamirim', 'BRA', '2016-12-13 11:14:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('436', 'Jacobina', 'BRA', '2016-12-13 11:14:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('437', 'Coronel Fabriciano', 'BRA', '2016-12-13 11:14:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('438', 'Birigui', 'BRA', '2016-12-13 11:14:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('439', 'TatuÃ­', 'BRA', '2016-12-13 11:14:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('440', 'Ji-ParanÃ¡', 'BRA', '2016-12-13 11:14:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('441', 'Bacabal', 'BRA', '2016-12-13 11:14:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('442', 'CametÃ¡', 'BRA', '2016-12-13 11:14:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('443', 'GuaÃ­ba', 'BRA', '2016-12-13 11:14:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('444', 'SÃ£o LourenÃ§o da Mata', 'BRA', '2016-12-13 11:14:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('445', 'Santana do Livramento', 'BRA', '2016-12-13 11:14:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('446', 'Votorantim', 'BRA', '2016-12-13 11:14:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('447', 'Campo Largo', 'BRA', '2016-12-13 11:14:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('448', 'Patos', 'BRA', '2016-12-13 11:14:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('449', 'Ituiutaba', 'BRA', '2016-12-13 11:14:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('450', 'CorumbÃ¡', 'BRA', '2016-12-13 11:14:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('451', 'PalhoÃ§a', 'BRA', '2016-12-13 11:14:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('452', 'Barra do PiraÃ­', 'BRA', '2016-12-13 11:14:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('453', 'Bento GonÃ§alves', 'BRA', '2016-12-13 11:14:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('454', 'PoÃ¡', 'BRA', '2016-12-13 11:14:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('455', 'Ãguas Lindas de GoiÃ¡s', 'BRA', '2016-12-13 11:14:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('456', 'London', 'GBR', '2016-12-13 11:14:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('457', 'Birmingham', 'GBR', '2016-12-13 11:14:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('458', 'Glasgow', 'GBR', '2016-12-13 11:14:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('459', 'Liverpool', 'GBR', '2016-12-13 11:14:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('460', 'Edinburgh', 'GBR', '2016-12-13 11:14:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('461', 'Sheffield', 'GBR', '2016-12-13 11:14:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('462', 'Manchester', 'GBR', '2016-12-13 11:14:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('463', 'Leeds', 'GBR', '2016-12-13 11:14:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('464', 'Bristol', 'GBR', '2016-12-13 11:14:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('465', 'Cardiff', 'GBR', '2016-12-13 11:14:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('466', 'Coventry', 'GBR', '2016-12-13 11:14:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('467', 'Leicester', 'GBR', '2016-12-13 11:14:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('468', 'Bradford', 'GBR', '2016-12-13 11:14:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('469', 'Belfast', 'GBR', '2016-12-13 11:14:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('470', 'Nottingham', 'GBR', '2016-12-13 11:14:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('471', 'Kingston upon Hull', 'GBR', '2016-12-13 11:14:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('472', 'Plymouth', 'GBR', '2016-12-13 11:14:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('473', 'Stoke-on-Trent', 'GBR', '2016-12-13 11:14:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('474', 'Wolverhampton', 'GBR', '2016-12-13 11:14:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('475', 'Derby', 'GBR', '2016-12-13 11:14:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('476', 'Swansea', 'GBR', '2016-12-13 11:14:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('477', 'Southampton', 'GBR', '2016-12-13 11:14:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('478', 'Aberdeen', 'GBR', '2016-12-13 11:14:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('479', 'Northampton', 'GBR', '2016-12-13 11:14:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('480', 'Dudley', 'GBR', '2016-12-13 11:14:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('481', 'Portsmouth', 'GBR', '2016-12-13 11:14:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('482', 'Newcastle upon Tyne', 'GBR', '2016-12-13 11:14:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('483', 'Sunderland', 'GBR', '2016-12-13 11:14:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('484', 'Luton', 'GBR', '2016-12-13 11:14:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('485', 'Swindon', 'GBR', '2016-12-13 11:14:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('486', 'Southend-on-Sea', 'GBR', '2016-12-13 11:14:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('487', 'Walsall', 'GBR', '2016-12-13 11:14:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('488', 'Bournemouth', 'GBR', '2016-12-13 11:14:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('489', 'Peterborough', 'GBR', '2016-12-13 11:14:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('490', 'Brighton', 'GBR', '2016-12-13 11:14:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('491', 'Blackpool', 'GBR', '2016-12-13 11:14:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('492', 'Dundee', 'GBR', '2016-12-13 11:14:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('493', 'West Bromwich', 'GBR', '2016-12-13 11:14:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('494', 'Reading', 'GBR', '2016-12-13 11:14:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('495', 'Oldbury/Smethwick (Warley)', 'GBR', '2016-12-13 11:14:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('496', 'Middlesbrough', 'GBR', '2016-12-13 11:14:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('497', 'Huddersfield', 'GBR', '2016-12-13 11:14:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('498', 'Oxford', 'GBR', '2016-12-13 11:14:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('499', 'Poole', 'GBR', '2016-12-13 11:14:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('500', 'Bolton', 'GBR', '2016-12-13 11:14:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('501', 'Blackburn', 'GBR', '2016-12-13 11:14:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('502', 'Newport', 'GBR', '2016-12-13 11:14:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('503', 'Preston', 'GBR', '2016-12-13 11:14:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('504', 'Stockport', 'GBR', '2016-12-13 11:14:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('505', 'Norwich', 'GBR', '2016-12-13 11:14:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('506', 'Rotherham', 'GBR', '2016-12-13 11:14:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('507', 'Cambridge', 'GBR', '2016-12-13 11:14:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('508', 'Watford', 'GBR', '2016-12-13 11:14:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('509', 'Ipswich', 'GBR', '2016-12-13 11:14:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('510', 'Slough', 'GBR', '2016-12-13 11:14:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('511', 'Exeter', 'GBR', '2016-12-13 11:14:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('512', 'Cheltenham', 'GBR', '2016-12-13 11:14:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('513', 'Gloucester', 'GBR', '2016-12-13 11:14:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('514', 'Saint Helens', 'GBR', '2016-12-13 11:14:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('515', 'Sutton Coldfield', 'GBR', '2016-12-13 11:14:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('516', 'York', 'GBR', '2016-12-13 11:14:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('517', 'Oldham', 'GBR', '2016-12-13 11:14:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('518', 'Basildon', 'GBR', '2016-12-13 11:14:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('519', 'Worthing', 'GBR', '2016-12-13 11:14:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('520', 'Chelmsford', 'GBR', '2016-12-13 11:14:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('521', 'Colchester', 'GBR', '2016-12-13 11:14:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('522', 'Crawley', 'GBR', '2016-12-13 11:14:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('523', 'Gillingham', 'GBR', '2016-12-13 11:14:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('524', 'Solihull', 'GBR', '2016-12-13 11:14:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('525', 'Rochdale', 'GBR', '2016-12-13 11:14:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('526', 'Birkenhead', 'GBR', '2016-12-13 11:14:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('527', 'Worcester', 'GBR', '2016-12-13 11:14:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('528', 'Hartlepool', 'GBR', '2016-12-13 11:14:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('529', 'Halifax', 'GBR', '2016-12-13 11:14:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('530', 'Woking/Byfleet', 'GBR', '2016-12-13 11:14:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('531', 'Southport', 'GBR', '2016-12-13 11:14:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('532', 'Maidstone', 'GBR', '2016-12-13 11:14:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('533', 'Eastbourne', 'GBR', '2016-12-13 11:14:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('534', 'Grimsby', 'GBR', '2016-12-13 11:14:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('535', 'Saint Helier', 'GBR', '2016-12-13 11:14:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('536', 'Douglas', 'GBR', '2016-12-13 11:14:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('537', 'Road Town', 'VGB', '2016-12-13 11:14:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('538', 'Bandar Seri Begawan', 'BRN', '2016-12-13 11:14:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('539', 'Sofija', 'BGR', '2016-12-13 11:14:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('540', 'Plovdiv', 'BGR', '2016-12-13 11:14:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('541', 'Varna', 'BGR', '2016-12-13 11:14:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('542', 'Burgas', 'BGR', '2016-12-13 11:14:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('543', 'Ruse', 'BGR', '2016-12-13 11:14:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('544', 'Stara Zagora', 'BGR', '2016-12-13 11:14:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('545', 'Pleven', 'BGR', '2016-12-13 11:14:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('546', 'Sliven', 'BGR', '2016-12-13 11:14:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('547', 'Dobric', 'BGR', '2016-12-13 11:14:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('548', 'Å umen', 'BGR', '2016-12-13 11:14:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('549', 'Ouagadougou', 'BFA', '2016-12-13 11:14:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('550', 'Bobo-Dioulasso', 'BFA', '2016-12-13 11:14:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('551', 'Koudougou', 'BFA', '2016-12-13 11:14:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('552', 'Bujumbura', 'BDI', '2016-12-13 11:14:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('553', 'George Town', 'CYM', '2016-12-13 11:14:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('554', 'Santiago de Chile', 'CHL', '2016-12-13 11:14:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('555', 'Puente Alto', 'CHL', '2016-12-13 11:14:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('556', 'ViÃ±a del Mar', 'CHL', '2016-12-13 11:14:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('557', 'ValparaÃ­so', 'CHL', '2016-12-13 11:14:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('558', 'Talcahuano', 'CHL', '2016-12-13 11:14:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('559', 'Antofagasta', 'CHL', '2016-12-13 11:14:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('560', 'San Bernardo', 'CHL', '2016-12-13 11:14:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('561', 'Temuco', 'CHL', '2016-12-13 11:14:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('562', 'ConcepciÃ³n', 'CHL', '2016-12-13 11:14:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('563', 'Rancagua', 'CHL', '2016-12-13 11:14:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('564', 'Arica', 'CHL', '2016-12-13 11:14:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('565', 'Talca', 'CHL', '2016-12-13 11:14:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('566', 'ChillÃ¡n', 'CHL', '2016-12-13 11:14:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('567', 'Iquique', 'CHL', '2016-12-13 11:14:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('568', 'Los Angeles', 'CHL', '2016-12-13 11:14:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('569', 'Puerto Montt', 'CHL', '2016-12-13 11:14:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('570', 'Coquimbo', 'CHL', '2016-12-13 11:14:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('571', 'Osorno', 'CHL', '2016-12-13 11:14:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('572', 'La Serena', 'CHL', '2016-12-13 11:14:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('573', 'Calama', 'CHL', '2016-12-13 11:14:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('574', 'Valdivia', 'CHL', '2016-12-13 11:14:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('575', 'Punta Arenas', 'CHL', '2016-12-13 11:14:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('576', 'CopiapÃ³', 'CHL', '2016-12-13 11:14:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('577', 'QuilpuÃ©', 'CHL', '2016-12-13 11:14:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('578', 'CuricÃ³', 'CHL', '2016-12-13 11:14:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('579', 'Ovalle', 'CHL', '2016-12-13 11:14:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('580', 'Coronel', 'CHL', '2016-12-13 11:14:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('581', 'San Pedro de la Paz', 'CHL', '2016-12-13 11:14:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('582', 'Melipilla', 'CHL', '2016-12-13 11:14:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('583', 'Avarua', 'COK', '2016-12-13 11:14:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('584', 'San JosÃ©', 'CRI', '2016-12-13 11:14:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('585', 'Djibouti', 'DJI', '2016-12-13 11:14:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('586', 'Roseau', 'DMA', '2016-12-13 11:14:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('587', 'Santo Domingo', 'DOM', '2016-12-13 11:14:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('588', 'Santiago de los Caballeros', 'DOM', '2016-12-13 11:14:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('589', 'La Romana', 'DOM', '2016-12-13 11:14:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('590', 'San Pedro de MacorÃ­s', 'DOM', '2016-12-13 11:14:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('591', 'San Francisco de MacorÃ­s', 'DOM', '2016-12-13 11:14:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('592', 'San Felipe de Puerto Plata', 'DOM', '2016-12-13 11:14:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('593', 'Guayaquil', 'ECU', '2016-12-13 11:14:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('594', 'Quito', 'ECU', '2016-12-13 11:14:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('595', 'Cuenca', 'ECU', '2016-12-13 11:14:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('596', 'Machala', 'ECU', '2016-12-13 11:14:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('597', 'Santo Domingo de los Colorados', 'ECU', '2016-12-13 11:14:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('598', 'Portoviejo', 'ECU', '2016-12-13 11:14:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('599', 'Ambato', 'ECU', '2016-12-13 11:14:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('600', 'Manta', 'ECU', '2016-12-13 11:14:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('601', 'Duran [Eloy Alfaro]', 'ECU', '2016-12-13 11:14:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('602', 'Ibarra', 'ECU', '2016-12-13 11:14:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('603', 'Quevedo', 'ECU', '2016-12-13 11:14:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('604', 'Milagro', 'ECU', '2016-12-13 11:14:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('605', 'Loja', 'ECU', '2016-12-13 11:14:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('606', 'RÃ­obamba', 'ECU', '2016-12-13 11:14:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('607', 'Esmeraldas', 'ECU', '2016-12-13 11:14:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('608', 'Cairo', 'EGY', '2016-12-13 11:14:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('609', 'Alexandria', 'EGY', '2016-12-13 11:14:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('610', 'Giza', 'EGY', '2016-12-13 11:14:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('611', 'Shubra al-Khayma', 'EGY', '2016-12-13 11:14:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('612', 'Port Said', 'EGY', '2016-12-13 11:14:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('613', 'Suez', 'EGY', '2016-12-13 11:14:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('614', 'al-Mahallat al-Kubra', 'EGY', '2016-12-13 11:14:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('615', 'Tanta', 'EGY', '2016-12-13 11:14:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('616', 'al-Mansura', 'EGY', '2016-12-13 11:14:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('617', 'Luxor', 'EGY', '2016-12-13 11:14:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('618', 'Asyut', 'EGY', '2016-12-13 11:14:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('619', 'Bahtim', 'EGY', '2016-12-13 11:14:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('620', 'Zagazig', 'EGY', '2016-12-13 11:14:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('621', 'al-Faiyum', 'EGY', '2016-12-13 11:14:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('622', 'Ismailia', 'EGY', '2016-12-13 11:14:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('623', 'Kafr al-Dawwar', 'EGY', '2016-12-13 11:14:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('624', 'Assuan', 'EGY', '2016-12-13 11:14:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('625', 'Damanhur', 'EGY', '2016-12-13 11:14:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('626', 'al-Minya', 'EGY', '2016-12-13 11:14:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('627', 'Bani Suwayf', 'EGY', '2016-12-13 11:14:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('628', 'Qina', 'EGY', '2016-12-13 11:14:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('629', 'Sawhaj', 'EGY', '2016-12-13 11:14:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('630', 'Shibin al-Kawm', 'EGY', '2016-12-13 11:14:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('631', 'Bulaq al-Dakrur', 'EGY', '2016-12-13 11:14:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('632', 'Banha', 'EGY', '2016-12-13 11:14:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('633', 'Warraq al-Arab', 'EGY', '2016-12-13 11:14:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('634', 'Kafr al-Shaykh', 'EGY', '2016-12-13 11:14:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('635', 'Mallawi', 'EGY', '2016-12-13 11:14:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('636', 'Bilbays', 'EGY', '2016-12-13 11:14:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('637', 'Mit Ghamr', 'EGY', '2016-12-13 11:14:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('638', 'al-Arish', 'EGY', '2016-12-13 11:14:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('639', 'Talkha', 'EGY', '2016-12-13 11:14:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('640', 'Qalyub', 'EGY', '2016-12-13 11:14:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('641', 'Jirja', 'EGY', '2016-12-13 11:14:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('642', 'Idfu', 'EGY', '2016-12-13 11:14:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('643', 'al-Hawamidiya', 'EGY', '2016-12-13 11:14:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('644', 'Disuq', 'EGY', '2016-12-13 11:14:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('645', 'San Salvador', 'SLV', '2016-12-13 11:14:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('646', 'Santa Ana', 'SLV', '2016-12-13 11:14:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('647', 'Mejicanos', 'SLV', '2016-12-13 11:14:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('648', 'Soyapango', 'SLV', '2016-12-13 11:14:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('649', 'San Miguel', 'SLV', '2016-12-13 11:14:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('650', 'Nueva San Salvador', 'SLV', '2016-12-13 11:14:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('651', 'Apopa', 'SLV', '2016-12-13 11:14:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('652', 'Asmara', 'ERI', '2016-12-13 11:14:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('653', 'Madrid', 'ESP', '2016-12-13 11:14:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('654', 'Barcelona', 'ESP', '2016-12-13 11:14:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('655', 'Valencia', 'ESP', '2016-12-13 11:14:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('656', 'Sevilla', 'ESP', '2016-12-13 11:14:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('657', 'Zaragoza', 'ESP', '2016-12-13 11:14:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('658', 'MÃ¡laga', 'ESP', '2016-12-13 11:14:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('659', 'Bilbao', 'ESP', '2016-12-13 11:14:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('660', 'Las Palmas de Gran Canaria', 'ESP', '2016-12-13 11:14:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('661', 'Murcia', 'ESP', '2016-12-13 11:14:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('662', 'Palma de Mallorca', 'ESP', '2016-12-13 11:14:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('663', 'Valladolid', 'ESP', '2016-12-13 11:14:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('664', 'CÃ³rdoba', 'ESP', '2016-12-13 11:14:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('665', 'Vigo', 'ESP', '2016-12-13 11:14:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('666', 'Alicante [Alacant]', 'ESP', '2016-12-13 11:14:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('667', 'GijÃ³n', 'ESP', '2016-12-13 11:14:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('668', 'LÂ´Hospitalet de Llobregat', 'ESP', '2016-12-13 11:14:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('669', 'Granada', 'ESP', '2016-12-13 11:14:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('670', 'A CoruÃ±a (La CoruÃ±a)', 'ESP', '2016-12-13 11:14:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('671', 'Vitoria-Gasteiz', 'ESP', '2016-12-13 11:14:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('672', 'Santa Cruz de Tenerife', 'ESP', '2016-12-13 11:14:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('673', 'Badalona', 'ESP', '2016-12-13 11:14:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('674', 'Oviedo', 'ESP', '2016-12-13 11:14:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('675', 'MÃ³stoles', 'ESP', '2016-12-13 11:14:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('676', 'Elche [Elx]', 'ESP', '2016-12-13 11:14:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('677', 'Sabadell', 'ESP', '2016-12-13 11:14:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('678', 'Santander', 'ESP', '2016-12-13 11:14:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('679', 'Jerez de la Frontera', 'ESP', '2016-12-13 11:14:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('680', 'Pamplona [IruÃ±a]', 'ESP', '2016-12-13 11:14:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('681', 'Donostia-San SebastiÃ¡n', 'ESP', '2016-12-13 11:14:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('682', 'Cartagena', 'ESP', '2016-12-13 11:14:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('683', 'LeganÃ©s', 'ESP', '2016-12-13 11:14:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('684', 'Fuenlabrada', 'ESP', '2016-12-13 11:14:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('685', 'AlmerÃ­a', 'ESP', '2016-12-13 11:14:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('686', 'Terrassa', 'ESP', '2016-12-13 11:14:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('687', 'AlcalÃ¡ de Henares', 'ESP', '2016-12-13 11:14:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('688', 'Burgos', 'ESP', '2016-12-13 11:14:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('689', 'Salamanca', 'ESP', '2016-12-13 11:14:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('690', 'Albacete', 'ESP', '2016-12-13 11:14:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('691', 'Getafe', 'ESP', '2016-12-13 11:14:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('692', 'CÃ¡diz', 'ESP', '2016-12-13 11:14:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('693', 'AlcorcÃ³n', 'ESP', '2016-12-13 11:14:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('694', 'Huelva', 'ESP', '2016-12-13 11:14:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('695', 'LeÃ³n', 'ESP', '2016-12-13 11:14:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('696', 'CastellÃ³n de la Plana [Castell', 'ESP', '2016-12-13 11:14:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('697', 'Badajoz', 'ESP', '2016-12-13 11:14:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('698', '[San CristÃ³bal de] la Laguna', 'ESP', '2016-12-13 11:14:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('699', 'LogroÃ±o', 'ESP', '2016-12-13 11:14:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('700', 'Santa Coloma de Gramenet', 'ESP', '2016-12-13 11:14:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('701', 'Tarragona', 'ESP', '2016-12-13 11:14:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('702', 'Lleida (LÃ©rida)', 'ESP', '2016-12-13 11:14:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('703', 'JaÃ©n', 'ESP', '2016-12-13 11:14:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('704', 'Ourense (Orense)', 'ESP', '2016-12-13 11:14:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('705', 'MatarÃ³', 'ESP', '2016-12-13 11:14:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('706', 'Algeciras', 'ESP', '2016-12-13 11:14:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('707', 'Marbella', 'ESP', '2016-12-13 11:14:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('708', 'Barakaldo', 'ESP', '2016-12-13 11:14:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('709', 'Dos Hermanas', 'ESP', '2016-12-13 11:14:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('710', 'Santiago de Compostela', 'ESP', '2016-12-13 11:14:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('711', 'TorrejÃ³n de Ardoz', 'ESP', '2016-12-13 11:14:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('712', 'Cape Town', 'ZAF', '2016-12-13 11:14:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('713', 'Soweto', 'ZAF', '2016-12-13 11:14:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('714', 'Johannesburg', 'ZAF', '2016-12-13 11:14:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('715', 'Port Elizabeth', 'ZAF', '2016-12-13 11:14:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('716', 'Pretoria', 'ZAF', '2016-12-13 11:14:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('717', 'Inanda', 'ZAF', '2016-12-13 11:14:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('718', 'Durban', 'ZAF', '2016-12-13 11:14:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('719', 'Vanderbijlpark', 'ZAF', '2016-12-13 11:14:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('720', 'Kempton Park', 'ZAF', '2016-12-13 11:14:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('721', 'Alberton', 'ZAF', '2016-12-13 11:14:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('722', 'Pinetown', 'ZAF', '2016-12-13 11:14:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('723', 'Pietermaritzburg', 'ZAF', '2016-12-13 11:14:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('724', 'Benoni', 'ZAF', '2016-12-13 11:14:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('725', 'Randburg', 'ZAF', '2016-12-13 11:14:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('726', 'Umlazi', 'ZAF', '2016-12-13 11:14:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('727', 'Bloemfontein', 'ZAF', '2016-12-13 11:14:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('728', 'Vereeniging', 'ZAF', '2016-12-13 11:14:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('729', 'Wonderboom', 'ZAF', '2016-12-13 11:14:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('730', 'Roodepoort', 'ZAF', '2016-12-13 11:14:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('731', 'Boksburg', 'ZAF', '2016-12-13 11:14:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('732', 'Klerksdorp', 'ZAF', '2016-12-13 11:14:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('733', 'Soshanguve', 'ZAF', '2016-12-13 11:14:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('734', 'Newcastle', 'ZAF', '2016-12-13 11:14:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('735', 'East London', 'ZAF', '2016-12-13 11:14:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('736', 'Welkom', 'ZAF', '2016-12-13 11:14:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('737', 'Kimberley', 'ZAF', '2016-12-13 11:14:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('738', 'Uitenhage', 'ZAF', '2016-12-13 11:14:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('739', 'Chatsworth', 'ZAF', '2016-12-13 11:14:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('740', 'Mdantsane', 'ZAF', '2016-12-13 11:14:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('741', 'Krugersdorp', 'ZAF', '2016-12-13 11:14:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('742', 'Botshabelo', 'ZAF', '2016-12-13 11:14:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('743', 'Brakpan', 'ZAF', '2016-12-13 11:14:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('744', 'Witbank', 'ZAF', '2016-12-13 11:14:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('745', 'Oberholzer', 'ZAF', '2016-12-13 11:14:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('746', 'Germiston', 'ZAF', '2016-12-13 11:14:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('747', 'Springs', 'ZAF', '2016-12-13 11:14:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('748', 'Westonaria', 'ZAF', '2016-12-13 11:14:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('749', 'Randfontein', 'ZAF', '2016-12-13 11:14:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('750', 'Paarl', 'ZAF', '2016-12-13 11:14:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('751', 'Potchefstroom', 'ZAF', '2016-12-13 11:14:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('752', 'Rustenburg', 'ZAF', '2016-12-13 11:14:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('753', 'Nigel', 'ZAF', '2016-12-13 11:14:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('754', 'George', 'ZAF', '2016-12-13 11:14:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('755', 'Ladysmith', 'ZAF', '2016-12-13 11:14:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('756', 'Addis Abeba', 'ETH', '2016-12-13 11:14:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('757', 'Dire Dawa', 'ETH', '2016-12-13 11:14:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('758', 'Nazret', 'ETH', '2016-12-13 11:14:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('759', 'Gonder', 'ETH', '2016-12-13 11:14:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('760', 'Dese', 'ETH', '2016-12-13 11:14:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('761', 'Mekele', 'ETH', '2016-12-13 11:14:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('762', 'Bahir Dar', 'ETH', '2016-12-13 11:14:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('763', 'Stanley', 'FLK', '2016-12-13 11:14:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('764', 'Suva', 'FJI', '2016-12-13 11:14:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('765', 'Quezon', 'PHL', '2016-12-13 11:14:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('766', 'Manila', 'PHL', '2016-12-13 11:14:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('767', 'Kalookan', 'PHL', '2016-12-13 11:14:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('768', 'Davao', 'PHL', '2016-12-13 11:14:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('769', 'Cebu', 'PHL', '2016-12-13 11:14:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('770', 'Zamboanga', 'PHL', '2016-12-13 11:14:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('771', 'Pasig', 'PHL', '2016-12-13 11:14:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('772', 'Valenzuela', 'PHL', '2016-12-13 11:14:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('773', 'Las PiÃ±as', 'PHL', '2016-12-13 11:14:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('774', 'Antipolo', 'PHL', '2016-12-13 11:14:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('775', 'Taguig', 'PHL', '2016-12-13 11:14:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('776', 'Cagayan de Oro', 'PHL', '2016-12-13 11:14:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('777', 'ParaÃ±aque', 'PHL', '2016-12-13 11:14:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('778', 'Makati', 'PHL', '2016-12-13 11:14:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('779', 'Bacolod', 'PHL', '2016-12-13 11:14:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('780', 'General Santos', 'PHL', '2016-12-13 11:14:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('781', 'Marikina', 'PHL', '2016-12-13 11:14:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('782', 'DasmariÃ±as', 'PHL', '2016-12-13 11:14:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('783', 'Muntinlupa', 'PHL', '2016-12-13 11:14:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('784', 'Iloilo', 'PHL', '2016-12-13 11:14:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('785', 'Pasay', 'PHL', '2016-12-13 11:14:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('786', 'Malabon', 'PHL', '2016-12-13 11:14:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('787', 'San JosÃ© del Monte', 'PHL', '2016-12-13 11:14:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('788', 'Bacoor', 'PHL', '2016-12-13 11:14:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('789', 'Iligan', 'PHL', '2016-12-13 11:14:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('790', 'Calamba', 'PHL', '2016-12-13 11:14:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('791', 'Mandaluyong', 'PHL', '2016-12-13 11:14:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('792', 'Butuan', 'PHL', '2016-12-13 11:14:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('793', 'Angeles', 'PHL', '2016-12-13 11:14:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('794', 'Tarlac', 'PHL', '2016-12-13 11:14:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('795', 'Mandaue', 'PHL', '2016-12-13 11:14:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('796', 'Baguio', 'PHL', '2016-12-13 11:14:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('797', 'Batangas', 'PHL', '2016-12-13 11:14:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('798', 'Cainta', 'PHL', '2016-12-13 11:14:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('799', 'San Pedro', 'PHL', '2016-12-13 11:14:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('800', 'Navotas', 'PHL', '2016-12-13 11:14:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('801', 'Cabanatuan', 'PHL', '2016-12-13 11:14:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('802', 'San Fernando', 'PHL', '2016-12-13 11:14:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('803', 'Lipa', 'PHL', '2016-12-13 11:14:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('804', 'Lapu-Lapu', 'PHL', '2016-12-13 11:14:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('805', 'San Pablo', 'PHL', '2016-12-13 11:14:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('806', 'BiÃ±an', 'PHL', '2016-12-13 11:14:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('807', 'Taytay', 'PHL', '2016-12-13 11:14:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('808', 'Lucena', 'PHL', '2016-12-13 11:14:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('809', 'Imus', 'PHL', '2016-12-13 11:14:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('810', 'Olongapo', 'PHL', '2016-12-13 11:14:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('811', 'Binangonan', 'PHL', '2016-12-13 11:14:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('812', 'Santa Rosa', 'PHL', '2016-12-13 11:14:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('813', 'Tagum', 'PHL', '2016-12-13 11:14:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('814', 'Tacloban', 'PHL', '2016-12-13 11:14:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('815', 'Malolos', 'PHL', '2016-12-13 11:14:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('816', 'Mabalacat', 'PHL', '2016-12-13 11:14:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('817', 'Cotabato', 'PHL', '2016-12-13 11:14:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('818', 'Meycauayan', 'PHL', '2016-12-13 11:14:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('819', 'Puerto Princesa', 'PHL', '2016-12-13 11:14:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('820', 'Legazpi', 'PHL', '2016-12-13 11:14:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('821', 'Silang', 'PHL', '2016-12-13 11:14:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('822', 'Ormoc', 'PHL', '2016-12-13 11:14:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('823', 'San Carlos', 'PHL', '2016-12-13 11:14:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('824', 'Kabankalan', 'PHL', '2016-12-13 11:14:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('825', 'Talisay', 'PHL', '2016-12-13 11:14:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('826', 'Valencia', 'PHL', '2016-12-13 11:14:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('827', 'Calbayog', 'PHL', '2016-12-13 11:14:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('828', 'Santa Maria', 'PHL', '2016-12-13 11:14:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('829', 'Pagadian', 'PHL', '2016-12-13 11:14:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('830', 'Cadiz', 'PHL', '2016-12-13 11:14:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('831', 'Bago', 'PHL', '2016-12-13 11:14:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('832', 'Toledo', 'PHL', '2016-12-13 11:14:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('833', 'Naga', 'PHL', '2016-12-13 11:14:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('834', 'San Mateo', 'PHL', '2016-12-13 11:14:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('835', 'Panabo', 'PHL', '2016-12-13 11:14:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('836', 'Koronadal', 'PHL', '2016-12-13 11:14:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('837', 'Marawi', 'PHL', '2016-12-13 11:14:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('838', 'Dagupan', 'PHL', '2016-12-13 11:14:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('839', 'Sagay', 'PHL', '2016-12-13 11:14:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('840', 'Roxas', 'PHL', '2016-12-13 11:14:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('841', 'Lubao', 'PHL', '2016-12-13 11:14:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('842', 'Digos', 'PHL', '2016-12-13 11:14:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('843', 'San Miguel', 'PHL', '2016-12-13 11:14:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('844', 'Malaybalay', 'PHL', '2016-12-13 11:14:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('845', 'Tuguegarao', 'PHL', '2016-12-13 11:14:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('846', 'Ilagan', 'PHL', '2016-12-13 11:14:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('847', 'Baliuag', 'PHL', '2016-12-13 11:14:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('848', 'Surigao', 'PHL', '2016-12-13 11:14:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('849', 'San Carlos', 'PHL', '2016-12-13 11:14:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('850', 'San Juan del Monte', 'PHL', '2016-12-13 11:14:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('851', 'Tanauan', 'PHL', '2016-12-13 11:14:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('852', 'Concepcion', 'PHL', '2016-12-13 11:14:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('853', 'Rodriguez (Montalban)', 'PHL', '2016-12-13 11:14:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('854', 'Sariaya', 'PHL', '2016-12-13 11:14:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('855', 'Malasiqui', 'PHL', '2016-12-13 11:14:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('856', 'General Mariano Alvarez', 'PHL', '2016-12-13 11:14:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('857', 'Urdaneta', 'PHL', '2016-12-13 11:14:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('858', 'Hagonoy', 'PHL', '2016-12-13 11:14:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('859', 'San Jose', 'PHL', '2016-12-13 11:14:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('860', 'Polomolok', 'PHL', '2016-12-13 11:14:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('861', 'Santiago', 'PHL', '2016-12-13 11:14:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('862', 'Tanza', 'PHL', '2016-12-13 11:14:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('863', 'Ozamis', 'PHL', '2016-12-13 11:14:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('864', 'Mexico', 'PHL', '2016-12-13 11:14:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('865', 'San Jose', 'PHL', '2016-12-13 11:14:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('866', 'Silay', 'PHL', '2016-12-13 11:14:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('867', 'General Trias', 'PHL', '2016-12-13 11:14:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('868', 'Tabaco', 'PHL', '2016-12-13 11:14:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('869', 'Cabuyao', 'PHL', '2016-12-13 11:14:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('870', 'Calapan', 'PHL', '2016-12-13 11:14:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('871', 'Mati', 'PHL', '2016-12-13 11:14:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('872', 'Midsayap', 'PHL', '2016-12-13 11:14:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('873', 'Cauayan', 'PHL', '2016-12-13 11:14:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('874', 'Gingoog', 'PHL', '2016-12-13 11:14:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('875', 'Dumaguete', 'PHL', '2016-12-13 11:14:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('876', 'San Fernando', 'PHL', '2016-12-13 11:14:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('877', 'Arayat', 'PHL', '2016-12-13 11:14:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('878', 'Bayawan (Tulong)', 'PHL', '2016-12-13 11:14:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('879', 'Kidapawan', 'PHL', '2016-12-13 11:14:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('880', 'Daraga (Locsin)', 'PHL', '2016-12-13 11:14:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('881', 'Marilao', 'PHL', '2016-12-13 11:14:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('882', 'Malita', 'PHL', '2016-12-13 11:14:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('883', 'Dipolog', 'PHL', '2016-12-13 11:14:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('884', 'Cavite', 'PHL', '2016-12-13 11:14:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('885', 'Danao', 'PHL', '2016-12-13 11:14:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('886', 'Bislig', 'PHL', '2016-12-13 11:14:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('887', 'Talavera', 'PHL', '2016-12-13 11:14:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('888', 'Guagua', 'PHL', '2016-12-13 11:14:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('889', 'Bayambang', 'PHL', '2016-12-13 11:14:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('890', 'Nasugbu', 'PHL', '2016-12-13 11:14:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('891', 'Baybay', 'PHL', '2016-12-13 11:14:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('892', 'Capas', 'PHL', '2016-12-13 11:14:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('893', 'Sultan Kudarat', 'PHL', '2016-12-13 11:14:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('894', 'Laoag', 'PHL', '2016-12-13 11:14:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('895', 'Bayugan', 'PHL', '2016-12-13 11:14:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('896', 'Malungon', 'PHL', '2016-12-13 11:14:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('897', 'Santa Cruz', 'PHL', '2016-12-13 11:14:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('898', 'Sorsogon', 'PHL', '2016-12-13 11:14:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('899', 'Candelaria', 'PHL', '2016-12-13 11:14:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('900', 'Ligao', 'PHL', '2016-12-13 11:14:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('901', 'TÃ³rshavn', 'FRO', '2016-12-13 11:14:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('902', 'Libreville', 'GAB', '2016-12-13 11:14:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('903', 'Serekunda', 'GMB', '2016-12-13 11:14:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('904', 'Banjul', 'GMB', '2016-12-13 11:14:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('905', 'Tbilisi', 'GEO', '2016-12-13 11:14:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('906', 'Kutaisi', 'GEO', '2016-12-13 11:14:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('907', 'Rustavi', 'GEO', '2016-12-13 11:14:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('908', 'Batumi', 'GEO', '2016-12-13 11:14:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('909', 'Sohumi', 'GEO', '2016-12-13 11:14:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('910', 'Accra', 'GHA', '2016-12-13 11:14:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('911', 'Kumasi', 'GHA', '2016-12-13 11:14:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('912', 'Tamale', 'GHA', '2016-12-13 11:14:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('913', 'Tema', 'GHA', '2016-12-13 11:14:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('914', 'Sekondi-Takoradi', 'GHA', '2016-12-13 11:14:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('915', 'Gibraltar', 'GIB', '2016-12-13 11:14:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('916', 'Saint GeorgeÂ´s', 'GRD', '2016-12-13 11:14:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('917', 'Nuuk', 'GRL', '2016-12-13 11:14:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('918', 'Les Abymes', 'GLP', '2016-12-13 11:14:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('919', 'Basse-Terre', 'GLP', '2016-12-13 11:14:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('920', 'Tamuning', 'GUM', '2016-12-13 11:14:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('921', 'AgaÃ±a', 'GUM', '2016-12-13 11:14:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('922', 'Guatemala', 'GTM', '2016-12-13 11:14:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('923', 'Mixco', 'GTM', '2016-12-13 11:14:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('924', 'Villa Nueva', 'GTM', '2016-12-13 11:14:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('925', 'Quetzaltenango', 'GTM', '2016-12-13 11:14:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('926', 'Conakry', 'GIN', '2016-12-13 11:14:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('927', 'Bissau', 'GNB', '2016-12-13 11:14:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('928', 'Georgetown', 'GUY', '2016-12-13 11:14:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('929', 'Port-au-Prince', 'HTI', '2016-12-13 11:14:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('930', 'Carrefour', 'HTI', '2016-12-13 11:14:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('931', 'Delmas', 'HTI', '2016-12-13 11:14:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('932', 'Le-Cap-HaÃ¯tien', 'HTI', '2016-12-13 11:14:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('933', 'Tegucigalpa', 'HND', '2016-12-13 11:14:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('934', 'San Pedro Sula', 'HND', '2016-12-13 11:14:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('935', 'La Ceiba', 'HND', '2016-12-13 11:14:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('936', 'Kowloon and New Kowloon', 'HKG', '2016-12-13 11:14:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('937', 'Victoria', 'HKG', '2016-12-13 11:14:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('938', 'Longyearbyen', 'SJM', '2016-12-13 11:14:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('939', 'Jakarta', 'IDN', '2016-12-13 11:14:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('940', 'Surabaya', 'IDN', '2016-12-13 11:14:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('941', 'Bandung', 'IDN', '2016-12-13 11:14:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('942', 'Medan', 'IDN', '2016-12-13 11:14:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('943', 'Palembang', 'IDN', '2016-12-13 11:14:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('944', 'Tangerang', 'IDN', '2016-12-13 11:14:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('945', 'Semarang', 'IDN', '2016-12-13 11:14:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('946', 'Ujung Pandang', 'IDN', '2016-12-13 11:14:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('947', 'Malang', 'IDN', '2016-12-13 11:14:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('948', 'Bandar Lampung', 'IDN', '2016-12-13 11:14:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('949', 'Bekasi', 'IDN', '2016-12-13 11:14:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('950', 'Padang', 'IDN', '2016-12-13 11:14:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('951', 'Surakarta', 'IDN', '2016-12-13 11:14:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('952', 'Banjarmasin', 'IDN', '2016-12-13 11:14:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('953', 'Pekan Baru', 'IDN', '2016-12-13 11:14:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('954', 'Denpasar', 'IDN', '2016-12-13 11:14:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('955', 'Yogyakarta', 'IDN', '2016-12-13 11:14:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('956', 'Pontianak', 'IDN', '2016-12-13 11:14:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('957', 'Samarinda', 'IDN', '2016-12-13 11:14:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('958', 'Jambi', 'IDN', '2016-12-13 11:14:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('959', 'Depok', 'IDN', '2016-12-13 11:14:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('960', 'Cimahi', 'IDN', '2016-12-13 11:14:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('961', 'Balikpapan', 'IDN', '2016-12-13 11:14:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('962', 'Manado', 'IDN', '2016-12-13 11:14:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('963', 'Mataram', 'IDN', '2016-12-13 11:14:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('964', 'Pekalongan', 'IDN', '2016-12-13 11:14:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('965', 'Tegal', 'IDN', '2016-12-13 11:14:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('966', 'Bogor', 'IDN', '2016-12-13 11:14:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('967', 'Ciputat', 'IDN', '2016-12-13 11:14:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('968', 'Pondokgede', 'IDN', '2016-12-13 11:14:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('969', 'Cirebon', 'IDN', '2016-12-13 11:14:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('970', 'Kediri', 'IDN', '2016-12-13 11:14:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('971', 'Ambon', 'IDN', '2016-12-13 11:14:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('972', 'Jember', 'IDN', '2016-12-13 11:14:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('973', 'Cilacap', 'IDN', '2016-12-13 11:14:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('974', 'Cimanggis', 'IDN', '2016-12-13 11:14:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('975', 'Pematang Siantar', 'IDN', '2016-12-13 11:14:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('976', 'Purwokerto', 'IDN', '2016-12-13 11:14:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('977', 'Ciomas', 'IDN', '2016-12-13 11:14:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('978', 'Tasikmalaya', 'IDN', '2016-12-13 11:14:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('979', 'Madiun', 'IDN', '2016-12-13 11:14:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('980', 'Bengkulu', 'IDN', '2016-12-13 11:14:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('981', 'Karawang', 'IDN', '2016-12-13 11:14:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('982', 'Banda Aceh', 'IDN', '2016-12-13 11:14:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('983', 'Palu', 'IDN', '2016-12-13 11:14:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('984', 'Pasuruan', 'IDN', '2016-12-13 11:14:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('985', 'Kupang', 'IDN', '2016-12-13 11:14:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('986', 'Tebing Tinggi', 'IDN', '2016-12-13 11:14:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('987', 'Percut Sei Tuan', 'IDN', '2016-12-13 11:14:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('988', 'Binjai', 'IDN', '2016-12-13 11:14:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('989', 'Sukabumi', 'IDN', '2016-12-13 11:14:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('990', 'Waru', 'IDN', '2016-12-13 11:14:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('991', 'Pangkal Pinang', 'IDN', '2016-12-13 11:14:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('992', 'Magelang', 'IDN', '2016-12-13 11:14:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('993', 'Blitar', 'IDN', '2016-12-13 11:14:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('994', 'Serang', 'IDN', '2016-12-13 11:14:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('995', 'Probolinggo', 'IDN', '2016-12-13 11:14:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('996', 'Cilegon', 'IDN', '2016-12-13 11:14:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('997', 'Cianjur', 'IDN', '2016-12-13 11:14:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('998', 'Ciparay', 'IDN', '2016-12-13 11:14:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('999', 'Lhokseumawe', 'IDN', '2016-12-13 11:14:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1000', 'Taman', 'IDN', '2016-12-13 11:14:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1001', 'Depok', 'IDN', '2016-12-13 11:14:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1002', 'Citeureup', 'IDN', '2016-12-13 11:14:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1003', 'Pemalang', 'IDN', '2016-12-13 11:14:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1004', 'Klaten', 'IDN', '2016-12-13 11:14:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1005', 'Salatiga', 'IDN', '2016-12-13 11:14:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1006', 'Cibinong', 'IDN', '2016-12-13 11:14:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1007', 'Palangka Raya', 'IDN', '2016-12-13 11:14:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1008', 'Mojokerto', 'IDN', '2016-12-13 11:14:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1009', 'Purwakarta', 'IDN', '2016-12-13 11:14:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1010', 'Garut', 'IDN', '2016-12-13 11:14:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1011', 'Kudus', 'IDN', '2016-12-13 11:14:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1012', 'Kendari', 'IDN', '2016-12-13 11:14:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1013', 'Jaya Pura', 'IDN', '2016-12-13 11:14:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1014', 'Gorontalo', 'IDN', '2016-12-13 11:14:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1015', 'Majalaya', 'IDN', '2016-12-13 11:14:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1016', 'Pondok Aren', 'IDN', '2016-12-13 11:14:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1017', 'Jombang', 'IDN', '2016-12-13 11:14:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1018', 'Sunggal', 'IDN', '2016-12-13 11:14:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1019', 'Batam', 'IDN', '2016-12-13 11:14:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1020', 'Padang Sidempuan', 'IDN', '2016-12-13 11:14:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1021', 'Sawangan', 'IDN', '2016-12-13 11:14:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1022', 'Banyuwangi', 'IDN', '2016-12-13 11:14:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1023', 'Tanjung Pinang', 'IDN', '2016-12-13 11:14:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1024', 'Mumbai (Bombay)', 'IND', '2016-12-13 11:14:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1025', 'Delhi', 'IND', '2016-12-13 11:14:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1026', 'Calcutta [Kolkata]', 'IND', '2016-12-13 11:14:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1027', 'Chennai (Madras)', 'IND', '2016-12-13 11:14:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1028', 'Hyderabad', 'IND', '2016-12-13 11:14:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1029', 'Ahmedabad', 'IND', '2016-12-13 11:14:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1030', 'Bangalore', 'IND', '2016-12-13 11:14:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1031', 'Kanpur', 'IND', '2016-12-13 11:14:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1032', 'Nagpur', 'IND', '2016-12-13 11:14:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1033', 'Lucknow', 'IND', '2016-12-13 11:14:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1034', 'Pune', 'IND', '2016-12-13 11:14:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1035', 'Surat', 'IND', '2016-12-13 11:14:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1036', 'Jaipur', 'IND', '2016-12-13 11:14:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1037', 'Indore', 'IND', '2016-12-13 11:14:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1038', 'Bhopal', 'IND', '2016-12-13 11:14:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1039', 'Ludhiana', 'IND', '2016-12-13 11:14:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1040', 'Vadodara (Baroda)', 'IND', '2016-12-13 11:14:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1041', 'Kalyan', 'IND', '2016-12-13 11:14:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1042', 'Madurai', 'IND', '2016-12-13 11:14:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1043', 'Haora (Howrah)', 'IND', '2016-12-13 11:14:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1044', 'Varanasi (Benares)', 'IND', '2016-12-13 11:14:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1045', 'Patna', 'IND', '2016-12-13 11:14:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1046', 'Srinagar', 'IND', '2016-12-13 11:14:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1047', 'Agra', 'IND', '2016-12-13 11:14:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1048', 'Coimbatore', 'IND', '2016-12-13 11:14:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1049', 'Thane (Thana)', 'IND', '2016-12-13 11:14:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1050', 'Allahabad', 'IND', '2016-12-13 11:14:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1051', 'Meerut', 'IND', '2016-12-13 11:14:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1052', 'Vishakhapatnam', 'IND', '2016-12-13 11:14:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1053', 'Jabalpur', 'IND', '2016-12-13 11:14:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1054', 'Amritsar', 'IND', '2016-12-13 11:15:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1055', 'Faridabad', 'IND', '2016-12-13 11:15:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1056', 'Vijayawada', 'IND', '2016-12-13 11:15:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1057', 'Gwalior', 'IND', '2016-12-13 11:15:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1058', 'Jodhpur', 'IND', '2016-12-13 11:15:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1059', 'Nashik (Nasik)', 'IND', '2016-12-13 11:15:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1060', 'Hubli-Dharwad', 'IND', '2016-12-13 11:15:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1061', 'Solapur (Sholapur)', 'IND', '2016-12-13 11:15:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1062', 'Ranchi', 'IND', '2016-12-13 11:15:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1063', 'Bareilly', 'IND', '2016-12-13 11:15:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1064', 'Guwahati (Gauhati)', 'IND', '2016-12-13 11:15:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1065', 'Shambajinagar (Aurangabad)', 'IND', '2016-12-13 11:15:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1066', 'Cochin (Kochi)', 'IND', '2016-12-13 11:15:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1067', 'Rajkot', 'IND', '2016-12-13 11:15:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1068', 'Kota', 'IND', '2016-12-13 11:15:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1069', 'Thiruvananthapuram (Trivandrum', 'IND', '2016-12-13 11:15:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1070', 'Pimpri-Chinchwad', 'IND', '2016-12-13 11:15:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1071', 'Jalandhar (Jullundur)', 'IND', '2016-12-13 11:15:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1072', 'Gorakhpur', 'IND', '2016-12-13 11:15:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1073', 'Chandigarh', 'IND', '2016-12-13 11:15:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1074', 'Mysore', 'IND', '2016-12-13 11:15:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1075', 'Aligarh', 'IND', '2016-12-13 11:15:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1076', 'Guntur', 'IND', '2016-12-13 11:15:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1077', 'Jamshedpur', 'IND', '2016-12-13 11:15:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1078', 'Ghaziabad', 'IND', '2016-12-13 11:15:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1079', 'Warangal', 'IND', '2016-12-13 11:15:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1080', 'Raipur', 'IND', '2016-12-13 11:15:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1081', 'Moradabad', 'IND', '2016-12-13 11:15:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1082', 'Durgapur', 'IND', '2016-12-13 11:15:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1083', 'Amravati', 'IND', '2016-12-13 11:15:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1084', 'Calicut (Kozhikode)', 'IND', '2016-12-13 11:15:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1085', 'Bikaner', 'IND', '2016-12-13 11:15:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1086', 'Bhubaneswar', 'IND', '2016-12-13 11:15:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1087', 'Kolhapur', 'IND', '2016-12-13 11:15:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1088', 'Kataka (Cuttack)', 'IND', '2016-12-13 11:15:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1089', 'Ajmer', 'IND', '2016-12-13 11:15:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1090', 'Bhavnagar', 'IND', '2016-12-13 11:15:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1091', 'Tiruchirapalli', 'IND', '2016-12-13 11:15:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1092', 'Bhilai', 'IND', '2016-12-13 11:15:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1093', 'Bhiwandi', 'IND', '2016-12-13 11:15:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1094', 'Saharanpur', 'IND', '2016-12-13 11:15:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1095', 'Ulhasnagar', 'IND', '2016-12-13 11:15:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1096', 'Salem', 'IND', '2016-12-13 11:15:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1097', 'Ujjain', 'IND', '2016-12-13 11:15:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1098', 'Malegaon', 'IND', '2016-12-13 11:15:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1099', 'Jamnagar', 'IND', '2016-12-13 11:15:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1100', 'Bokaro Steel City', 'IND', '2016-12-13 11:15:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1101', 'Akola', 'IND', '2016-12-13 11:15:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1102', 'Belgaum', 'IND', '2016-12-13 11:15:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1103', 'Rajahmundry', 'IND', '2016-12-13 11:15:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1104', 'Nellore', 'IND', '2016-12-13 11:15:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1105', 'Udaipur', 'IND', '2016-12-13 11:15:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1106', 'New Bombay', 'IND', '2016-12-13 11:15:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1107', 'Bhatpara', 'IND', '2016-12-13 11:15:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1108', 'Gulbarga', 'IND', '2016-12-13 11:15:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1109', 'New Delhi', 'IND', '2016-12-13 11:15:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1110', 'Jhansi', 'IND', '2016-12-13 11:15:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1111', 'Gaya', 'IND', '2016-12-13 11:15:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1112', 'Kakinada', 'IND', '2016-12-13 11:15:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1113', 'Dhule (Dhulia)', 'IND', '2016-12-13 11:15:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1114', 'Panihati', 'IND', '2016-12-13 11:15:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1115', 'Nanded (Nander)', 'IND', '2016-12-13 11:15:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1116', 'Mangalore', 'IND', '2016-12-13 11:15:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1117', 'Dehra Dun', 'IND', '2016-12-13 11:15:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1118', 'Kamarhati', 'IND', '2016-12-13 11:15:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1119', 'Davangere', 'IND', '2016-12-13 11:15:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1120', 'Asansol', 'IND', '2016-12-13 11:15:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1121', 'Bhagalpur', 'IND', '2016-12-13 11:15:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1122', 'Bellary', 'IND', '2016-12-13 11:15:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1123', 'Barddhaman (Burdwan)', 'IND', '2016-12-13 11:15:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1124', 'Rampur', 'IND', '2016-12-13 11:15:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1125', 'Jalgaon', 'IND', '2016-12-13 11:15:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1126', 'Muzaffarpur', 'IND', '2016-12-13 11:15:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1127', 'Nizamabad', 'IND', '2016-12-13 11:15:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1128', 'Muzaffarnagar', 'IND', '2016-12-13 11:15:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1129', 'Patiala', 'IND', '2016-12-13 11:15:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1130', 'Shahjahanpur', 'IND', '2016-12-13 11:15:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1131', 'Kurnool', 'IND', '2016-12-13 11:15:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1132', 'Tiruppur (Tirupper)', 'IND', '2016-12-13 11:15:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1133', 'Rohtak', 'IND', '2016-12-13 11:15:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1134', 'South Dum Dum', 'IND', '2016-12-13 11:15:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1135', 'Mathura', 'IND', '2016-12-13 11:15:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1136', 'Chandrapur', 'IND', '2016-12-13 11:15:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1137', 'Barahanagar (Baranagar)', 'IND', '2016-12-13 11:15:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1138', 'Darbhanga', 'IND', '2016-12-13 11:15:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1139', 'Siliguri (Shiliguri)', 'IND', '2016-12-13 11:15:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1140', 'Raurkela', 'IND', '2016-12-13 11:15:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1141', 'Ambattur', 'IND', '2016-12-13 11:15:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1142', 'Panipat', 'IND', '2016-12-13 11:15:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1143', 'Firozabad', 'IND', '2016-12-13 11:15:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1144', 'Ichalkaranji', 'IND', '2016-12-13 11:15:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1145', 'Jammu', 'IND', '2016-12-13 11:15:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1146', 'Ramagundam', 'IND', '2016-12-13 11:15:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1147', 'Eluru', 'IND', '2016-12-13 11:15:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1148', 'Brahmapur', 'IND', '2016-12-13 11:15:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1149', 'Alwar', 'IND', '2016-12-13 11:15:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1150', 'Pondicherry', 'IND', '2016-12-13 11:15:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1151', 'Thanjavur', 'IND', '2016-12-13 11:15:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1152', 'Bihar Sharif', 'IND', '2016-12-13 11:15:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1153', 'Tuticorin', 'IND', '2016-12-13 11:15:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1154', 'Imphal', 'IND', '2016-12-13 11:15:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1155', 'Latur', 'IND', '2016-12-13 11:15:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1156', 'Sagar', 'IND', '2016-12-13 11:15:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1157', 'Farrukhabad-cum-Fatehgarh', 'IND', '2016-12-13 11:15:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1158', 'Sangli', 'IND', '2016-12-13 11:15:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1159', 'Parbhani', 'IND', '2016-12-13 11:15:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1160', 'Nagar Coil', 'IND', '2016-12-13 11:15:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1161', 'Bijapur', 'IND', '2016-12-13 11:15:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1162', 'Kukatpalle', 'IND', '2016-12-13 11:15:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1163', 'Bally', 'IND', '2016-12-13 11:15:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1164', 'Bhilwara', 'IND', '2016-12-13 11:15:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1165', 'Ratlam', 'IND', '2016-12-13 11:15:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1166', 'Avadi', 'IND', '2016-12-13 11:15:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1167', 'Dindigul', 'IND', '2016-12-13 11:15:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1168', 'Ahmadnagar', 'IND', '2016-12-13 11:15:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1169', 'Bilaspur', 'IND', '2016-12-13 11:15:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1170', 'Shimoga', 'IND', '2016-12-13 11:15:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1171', 'Kharagpur', 'IND', '2016-12-13 11:15:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1172', 'Mira Bhayandar', 'IND', '2016-12-13 11:15:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1173', 'Vellore', 'IND', '2016-12-13 11:15:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1174', 'Jalna', 'IND', '2016-12-13 11:15:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1175', 'Burnpur', 'IND', '2016-12-13 11:15:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1176', 'Anantapur', 'IND', '2016-12-13 11:15:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1177', 'Allappuzha (Alleppey)', 'IND', '2016-12-13 11:15:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1178', 'Tirupati', 'IND', '2016-12-13 11:15:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1179', 'Karnal', 'IND', '2016-12-13 11:15:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1180', 'Burhanpur', 'IND', '2016-12-13 11:15:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1181', 'Hisar (Hissar)', 'IND', '2016-12-13 11:15:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1182', 'Tiruvottiyur', 'IND', '2016-12-13 11:15:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1183', 'Mirzapur-cum-Vindhyachal', 'IND', '2016-12-13 11:15:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1184', 'Secunderabad', 'IND', '2016-12-13 11:15:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1185', 'Nadiad', 'IND', '2016-12-13 11:15:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1186', 'Dewas', 'IND', '2016-12-13 11:15:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1187', 'Murwara (Katni)', 'IND', '2016-12-13 11:15:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1188', 'Ganganagar', 'IND', '2016-12-13 11:15:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1189', 'Vizianagaram', 'IND', '2016-12-13 11:15:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1190', 'Erode', 'IND', '2016-12-13 11:15:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1191', 'Machilipatnam (Masulipatam)', 'IND', '2016-12-13 11:15:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1192', 'Bhatinda (Bathinda)', 'IND', '2016-12-13 11:15:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1193', 'Raichur', 'IND', '2016-12-13 11:15:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1194', 'Agartala', 'IND', '2016-12-13 11:15:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1195', 'Arrah (Ara)', 'IND', '2016-12-13 11:15:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1196', 'Satna', 'IND', '2016-12-13 11:15:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1197', 'Lalbahadur Nagar', 'IND', '2016-12-13 11:15:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1198', 'Aizawl', 'IND', '2016-12-13 11:15:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1199', 'Uluberia', 'IND', '2016-12-13 11:15:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1200', 'Katihar', 'IND', '2016-12-13 11:15:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1201', 'Cuddalore', 'IND', '2016-12-13 11:15:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1202', 'Hugli-Chinsurah', 'IND', '2016-12-13 11:15:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1203', 'Dhanbad', 'IND', '2016-12-13 11:15:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1204', 'Raiganj', 'IND', '2016-12-13 11:15:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1205', 'Sambhal', 'IND', '2016-12-13 11:15:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1206', 'Durg', 'IND', '2016-12-13 11:15:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1207', 'Munger (Monghyr)', 'IND', '2016-12-13 11:15:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1208', 'Kanchipuram', 'IND', '2016-12-13 11:15:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1209', 'North Dum Dum', 'IND', '2016-12-13 11:15:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1210', 'Karimnagar', 'IND', '2016-12-13 11:15:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1211', 'Bharatpur', 'IND', '2016-12-13 11:15:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1212', 'Sikar', 'IND', '2016-12-13 11:15:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1213', 'Hardwar (Haridwar)', 'IND', '2016-12-13 11:15:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1214', 'Dabgram', 'IND', '2016-12-13 11:15:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1215', 'Morena', 'IND', '2016-12-13 11:15:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1216', 'Noida', 'IND', '2016-12-13 11:15:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1217', 'Hapur', 'IND', '2016-12-13 11:15:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1218', 'Bhusawal', 'IND', '2016-12-13 11:15:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1219', 'Khandwa', 'IND', '2016-12-13 11:15:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1220', 'Yamuna Nagar', 'IND', '2016-12-13 11:15:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1221', 'Sonipat (Sonepat)', 'IND', '2016-12-13 11:15:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1222', 'Tenali', 'IND', '2016-12-13 11:15:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1223', 'Raurkela Civil Township', 'IND', '2016-12-13 11:15:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1224', 'Kollam (Quilon)', 'IND', '2016-12-13 11:15:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1225', 'Kumbakonam', 'IND', '2016-12-13 11:15:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1226', 'Ingraj Bazar (English Bazar)', 'IND', '2016-12-13 11:15:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1227', 'Timkur', 'IND', '2016-12-13 11:15:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1228', 'Amroha', 'IND', '2016-12-13 11:15:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1229', 'Serampore', 'IND', '2016-12-13 11:15:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1230', 'Chapra', 'IND', '2016-12-13 11:15:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1231', 'Pali', 'IND', '2016-12-13 11:15:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1232', 'Maunath Bhanjan', 'IND', '2016-12-13 11:15:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1233', 'Adoni', 'IND', '2016-12-13 11:15:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1234', 'Jaunpur', 'IND', '2016-12-13 11:15:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1235', 'Tirunelveli', 'IND', '2016-12-13 11:15:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1236', 'Bahraich', 'IND', '2016-12-13 11:15:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1237', 'Gadag Betigeri', 'IND', '2016-12-13 11:15:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1238', 'Proddatur', 'IND', '2016-12-13 11:15:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1239', 'Chittoor', 'IND', '2016-12-13 11:15:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1240', 'Barrackpur', 'IND', '2016-12-13 11:15:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1241', 'Bharuch (Broach)', 'IND', '2016-12-13 11:15:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1242', 'Naihati', 'IND', '2016-12-13 11:15:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1243', 'Shillong', 'IND', '2016-12-13 11:15:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1244', 'Sambalpur', 'IND', '2016-12-13 11:15:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1245', 'Junagadh', 'IND', '2016-12-13 11:15:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1246', 'Rae Bareli', 'IND', '2016-12-13 11:15:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1247', 'Rewa', 'IND', '2016-12-13 11:15:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1248', 'Gurgaon', 'IND', '2016-12-13 11:15:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1249', 'Khammam', 'IND', '2016-12-13 11:15:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1250', 'Bulandshahr', 'IND', '2016-12-13 11:15:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1251', 'Navsari', 'IND', '2016-12-13 11:15:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1252', 'Malkajgiri', 'IND', '2016-12-13 11:15:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1253', 'Midnapore (Medinipur)', 'IND', '2016-12-13 11:15:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1254', 'Miraj', 'IND', '2016-12-13 11:15:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1255', 'Raj Nandgaon', 'IND', '2016-12-13 11:15:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1256', 'Alandur', 'IND', '2016-12-13 11:15:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1257', 'Puri', 'IND', '2016-12-13 11:15:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1258', 'Navadwip', 'IND', '2016-12-13 11:15:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1259', 'Sirsa', 'IND', '2016-12-13 11:15:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1260', 'Korba', 'IND', '2016-12-13 11:15:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1261', 'Faizabad', 'IND', '2016-12-13 11:15:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1262', 'Etawah', 'IND', '2016-12-13 11:15:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1263', 'Pathankot', 'IND', '2016-12-13 11:15:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1264', 'Gandhinagar', 'IND', '2016-12-13 11:15:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1265', 'Palghat (Palakkad)', 'IND', '2016-12-13 11:15:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1266', 'Veraval', 'IND', '2016-12-13 11:15:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1267', 'Hoshiarpur', 'IND', '2016-12-13 11:15:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1268', 'Ambala', 'IND', '2016-12-13 11:15:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1269', 'Sitapur', 'IND', '2016-12-13 11:15:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1270', 'Bhiwani', 'IND', '2016-12-13 11:15:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1271', 'Cuddapah', 'IND', '2016-12-13 11:15:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1272', 'Bhimavaram', 'IND', '2016-12-13 11:15:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1273', 'Krishnanagar', 'IND', '2016-12-13 11:15:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1274', 'Chandannagar', 'IND', '2016-12-13 11:15:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1275', 'Mandya', 'IND', '2016-12-13 11:15:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1276', 'Dibrugarh', 'IND', '2016-12-13 11:15:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1277', 'Nandyal', 'IND', '2016-12-13 11:15:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1278', 'Balurghat', 'IND', '2016-12-13 11:15:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1279', 'Neyveli', 'IND', '2016-12-13 11:15:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1280', 'Fatehpur', 'IND', '2016-12-13 11:15:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1281', 'Mahbubnagar', 'IND', '2016-12-13 11:15:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1282', 'Budaun', 'IND', '2016-12-13 11:15:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1283', 'Porbandar', 'IND', '2016-12-13 11:15:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1284', 'Silchar', 'IND', '2016-12-13 11:15:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1285', 'Berhampore (Baharampur)', 'IND', '2016-12-13 11:15:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1286', 'Purnea (Purnia)', 'IND', '2016-12-13 11:15:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1287', 'Bankura', 'IND', '2016-12-13 11:15:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1288', 'Rajapalaiyam', 'IND', '2016-12-13 11:15:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1289', 'Titagarh', 'IND', '2016-12-13 11:15:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1290', 'Halisahar', 'IND', '2016-12-13 11:15:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1291', 'Hathras', 'IND', '2016-12-13 11:15:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1292', 'Bhir (Bid)', 'IND', '2016-12-13 11:15:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1293', 'Pallavaram', 'IND', '2016-12-13 11:15:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1294', 'Anand', 'IND', '2016-12-13 11:15:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1295', 'Mango', 'IND', '2016-12-13 11:15:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1296', 'Santipur', 'IND', '2016-12-13 11:15:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1297', 'Bhind', 'IND', '2016-12-13 11:15:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1298', 'Gondiya', 'IND', '2016-12-13 11:15:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1299', 'Tiruvannamalai', 'IND', '2016-12-13 11:15:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1300', 'Yeotmal (Yavatmal)', 'IND', '2016-12-13 11:15:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1301', 'Kulti-Barakar', 'IND', '2016-12-13 11:15:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1302', 'Moga', 'IND', '2016-12-13 11:15:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1303', 'Shivapuri', 'IND', '2016-12-13 11:15:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1304', 'Bidar', 'IND', '2016-12-13 11:15:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1305', 'Guntakal', 'IND', '2016-12-13 11:15:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1306', 'Unnao', 'IND', '2016-12-13 11:15:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1307', 'Barasat', 'IND', '2016-12-13 11:15:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1308', 'Tambaram', 'IND', '2016-12-13 11:15:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1309', 'Abohar', 'IND', '2016-12-13 11:15:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1310', 'Pilibhit', 'IND', '2016-12-13 11:15:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1311', 'Valparai', 'IND', '2016-12-13 11:15:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1312', 'Gonda', 'IND', '2016-12-13 11:15:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1313', 'Surendranagar', 'IND', '2016-12-13 11:15:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1314', 'Qutubullapur', 'IND', '2016-12-13 11:15:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1315', 'Beawar', 'IND', '2016-12-13 11:15:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1316', 'Hindupur', 'IND', '2016-12-13 11:15:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1317', 'Gandhidham', 'IND', '2016-12-13 11:15:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1318', 'Haldwani-cum-Kathgodam', 'IND', '2016-12-13 11:15:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1319', 'Tellicherry (Thalassery)', 'IND', '2016-12-13 11:15:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1320', 'Wardha', 'IND', '2016-12-13 11:15:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1321', 'Rishra', 'IND', '2016-12-13 11:15:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1322', 'Bhuj', 'IND', '2016-12-13 11:15:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1323', 'Modinagar', 'IND', '2016-12-13 11:15:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1324', 'Gudivada', 'IND', '2016-12-13 11:15:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1325', 'Basirhat', 'IND', '2016-12-13 11:15:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1326', 'Uttarpara-Kotrung', 'IND', '2016-12-13 11:15:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1327', 'Ongole', 'IND', '2016-12-13 11:15:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1328', 'North Barrackpur', 'IND', '2016-12-13 11:15:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1329', 'Guna', 'IND', '2016-12-13 11:15:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1330', 'Haldia', 'IND', '2016-12-13 11:15:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1331', 'Habra', 'IND', '2016-12-13 11:15:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1332', 'Kanchrapara', 'IND', '2016-12-13 11:15:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1333', 'Tonk', 'IND', '2016-12-13 11:15:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1334', 'Champdani', 'IND', '2016-12-13 11:15:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1335', 'Orai', 'IND', '2016-12-13 11:15:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1336', 'Pudukkottai', 'IND', '2016-12-13 11:15:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1337', 'Sasaram', 'IND', '2016-12-13 11:15:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1338', 'Hazaribag', 'IND', '2016-12-13 11:15:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1339', 'Palayankottai', 'IND', '2016-12-13 11:15:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1340', 'Banda', 'IND', '2016-12-13 11:15:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1341', 'Godhra', 'IND', '2016-12-13 11:15:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1342', 'Hospet', 'IND', '2016-12-13 11:15:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1343', 'Ashoknagar-Kalyangarh', 'IND', '2016-12-13 11:15:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1344', 'Achalpur', 'IND', '2016-12-13 11:15:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1345', 'Patan', 'IND', '2016-12-13 11:15:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1346', 'Mandasor', 'IND', '2016-12-13 11:15:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1347', 'Damoh', 'IND', '2016-12-13 11:15:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1348', 'Satara', 'IND', '2016-12-13 11:15:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1349', 'Meerut Cantonment', 'IND', '2016-12-13 11:15:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1350', 'Dehri', 'IND', '2016-12-13 11:15:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1351', 'Delhi Cantonment', 'IND', '2016-12-13 11:15:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1352', 'Chhindwara', 'IND', '2016-12-13 11:15:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1353', 'Bansberia', 'IND', '2016-12-13 11:15:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1354', 'Nagaon', 'IND', '2016-12-13 11:15:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1355', 'Kanpur Cantonment', 'IND', '2016-12-13 11:15:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1356', 'Vidisha', 'IND', '2016-12-13 11:15:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1357', 'Bettiah', 'IND', '2016-12-13 11:15:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1358', 'Purulia', 'IND', '2016-12-13 11:15:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1359', 'Hassan', 'IND', '2016-12-13 11:15:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1360', 'Ambala Sadar', 'IND', '2016-12-13 11:15:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1361', 'Baidyabati', 'IND', '2016-12-13 11:15:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1362', 'Morvi', 'IND', '2016-12-13 11:15:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1363', 'Raigarh', 'IND', '2016-12-13 11:15:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1364', 'Vejalpur', 'IND', '2016-12-13 11:15:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1365', 'Baghdad', 'IRQ', '2016-12-13 11:15:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1366', 'Mosul', 'IRQ', '2016-12-13 11:15:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1367', 'Irbil', 'IRQ', '2016-12-13 11:15:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1368', 'Kirkuk', 'IRQ', '2016-12-13 11:15:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1369', 'Basra', 'IRQ', '2016-12-13 11:15:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1370', 'al-Sulaymaniya', 'IRQ', '2016-12-13 11:15:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1371', 'al-Najaf', 'IRQ', '2016-12-13 11:15:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1372', 'Karbala', 'IRQ', '2016-12-13 11:15:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1373', 'al-Hilla', 'IRQ', '2016-12-13 11:15:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1374', 'al-Nasiriya', 'IRQ', '2016-12-13 11:15:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1375', 'al-Amara', 'IRQ', '2016-12-13 11:15:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1376', 'al-Diwaniya', 'IRQ', '2016-12-13 11:15:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1377', 'al-Ramadi', 'IRQ', '2016-12-13 11:15:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1378', 'al-Kut', 'IRQ', '2016-12-13 11:15:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1379', 'Baquba', 'IRQ', '2016-12-13 11:15:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1380', 'Teheran', 'IRN', '2016-12-13 11:15:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1381', 'Mashhad', 'IRN', '2016-12-13 11:15:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1382', 'Esfahan', 'IRN', '2016-12-13 11:15:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1383', 'Tabriz', 'IRN', '2016-12-13 11:15:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1384', 'Shiraz', 'IRN', '2016-12-13 11:15:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1385', 'Karaj', 'IRN', '2016-12-13 11:15:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1386', 'Ahvaz', 'IRN', '2016-12-13 11:15:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1387', 'Qom', 'IRN', '2016-12-13 11:15:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1388', 'Kermanshah', 'IRN', '2016-12-13 11:15:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1389', 'Urmia', 'IRN', '2016-12-13 11:15:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1390', 'Zahedan', 'IRN', '2016-12-13 11:15:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1391', 'Rasht', 'IRN', '2016-12-13 11:15:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1392', 'Hamadan', 'IRN', '2016-12-13 11:15:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1393', 'Kerman', 'IRN', '2016-12-13 11:15:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1394', 'Arak', 'IRN', '2016-12-13 11:15:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1395', 'Ardebil', 'IRN', '2016-12-13 11:15:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1396', 'Yazd', 'IRN', '2016-12-13 11:15:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1397', 'Qazvin', 'IRN', '2016-12-13 11:15:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1398', 'Zanjan', 'IRN', '2016-12-13 11:15:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1399', 'Sanandaj', 'IRN', '2016-12-13 11:15:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1400', 'Bandar-e-Abbas', 'IRN', '2016-12-13 11:15:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1401', 'Khorramabad', 'IRN', '2016-12-13 11:15:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1402', 'Eslamshahr', 'IRN', '2016-12-13 11:15:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1403', 'Borujerd', 'IRN', '2016-12-13 11:15:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1404', 'Abadan', 'IRN', '2016-12-13 11:15:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1405', 'Dezful', 'IRN', '2016-12-13 11:15:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1406', 'Kashan', 'IRN', '2016-12-13 11:15:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1407', 'Sari', 'IRN', '2016-12-13 11:15:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1408', 'Gorgan', 'IRN', '2016-12-13 11:15:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1409', 'Najafabad', 'IRN', '2016-12-13 11:15:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1410', 'Sabzevar', 'IRN', '2016-12-13 11:15:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1411', 'Khomeynishahr', 'IRN', '2016-12-13 11:15:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1412', 'Amol', 'IRN', '2016-12-13 11:15:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1413', 'Neyshabur', 'IRN', '2016-12-13 11:15:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1414', 'Babol', 'IRN', '2016-12-13 11:15:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1415', 'Khoy', 'IRN', '2016-12-13 11:15:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1416', 'Malayer', 'IRN', '2016-12-13 11:15:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1417', 'Bushehr', 'IRN', '2016-12-13 11:15:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1418', 'Qaemshahr', 'IRN', '2016-12-13 11:15:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1419', 'Qarchak', 'IRN', '2016-12-13 11:15:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1420', 'Qods', 'IRN', '2016-12-13 11:15:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1421', 'Sirjan', 'IRN', '2016-12-13 11:15:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1422', 'Bojnurd', 'IRN', '2016-12-13 11:15:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1423', 'Maragheh', 'IRN', '2016-12-13 11:15:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1424', 'Birjand', 'IRN', '2016-12-13 11:15:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1425', 'Ilam', 'IRN', '2016-12-13 11:15:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1426', 'Bukan', 'IRN', '2016-12-13 11:15:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1427', 'Masjed-e-Soleyman', 'IRN', '2016-12-13 11:15:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1428', 'Saqqez', 'IRN', '2016-12-13 11:15:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1429', 'Gonbad-e Qabus', 'IRN', '2016-12-13 11:15:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1430', 'Saveh', 'IRN', '2016-12-13 11:15:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1431', 'Mahabad', 'IRN', '2016-12-13 11:15:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1432', 'Varamin', 'IRN', '2016-12-13 11:15:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1433', 'Andimeshk', 'IRN', '2016-12-13 11:15:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1434', 'Khorramshahr', 'IRN', '2016-12-13 11:15:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1435', 'Shahrud', 'IRN', '2016-12-13 11:15:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1436', 'Marv Dasht', 'IRN', '2016-12-13 11:15:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1437', 'Zabol', 'IRN', '2016-12-13 11:15:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1438', 'Shahr-e Kord', 'IRN', '2016-12-13 11:15:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1439', 'Bandar-e Anzali', 'IRN', '2016-12-13 11:15:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1440', 'Rafsanjan', 'IRN', '2016-12-13 11:15:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1441', 'Marand', 'IRN', '2016-12-13 11:15:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1442', 'Torbat-e Heydariyeh', 'IRN', '2016-12-13 11:15:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1443', 'Jahrom', 'IRN', '2016-12-13 11:15:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1444', 'Semnan', 'IRN', '2016-12-13 11:15:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1445', 'Miandoab', 'IRN', '2016-12-13 11:15:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1446', 'Qomsheh', 'IRN', '2016-12-13 11:15:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1447', 'Dublin', 'IRL', '2016-12-13 11:15:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1448', 'Cork', 'IRL', '2016-12-13 11:15:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1449', 'ReykjavÃ­k', 'ISL', '2016-12-13 11:15:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1450', 'Jerusalem', 'ISR', '2016-12-13 11:15:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1451', 'Tel Aviv-Jaffa', 'ISR', '2016-12-13 11:15:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1452', 'Haifa', 'ISR', '2016-12-13 11:15:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1453', 'Rishon Le Ziyyon', 'ISR', '2016-12-13 11:15:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1454', 'Beerseba', 'ISR', '2016-12-13 11:15:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1455', 'Holon', 'ISR', '2016-12-13 11:15:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1456', 'Petah Tiqwa', 'ISR', '2016-12-13 11:15:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1457', 'Ashdod', 'ISR', '2016-12-13 11:15:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1458', 'Netanya', 'ISR', '2016-12-13 11:15:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1459', 'Bat Yam', 'ISR', '2016-12-13 11:15:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1460', 'Bene Beraq', 'ISR', '2016-12-13 11:15:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1461', 'Ramat Gan', 'ISR', '2016-12-13 11:15:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1462', 'Ashqelon', 'ISR', '2016-12-13 11:15:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1463', 'Rehovot', 'ISR', '2016-12-13 11:15:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1464', 'Roma', 'ITA', '2016-12-13 11:15:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1465', 'Milano', 'ITA', '2016-12-13 11:15:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1466', 'Napoli', 'ITA', '2016-12-13 11:15:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1467', 'Torino', 'ITA', '2016-12-13 11:15:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1468', 'Palermo', 'ITA', '2016-12-13 11:15:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1469', 'Genova', 'ITA', '2016-12-13 11:15:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1470', 'Bologna', 'ITA', '2016-12-13 11:15:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1471', 'Firenze', 'ITA', '2016-12-13 11:15:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1472', 'Catania', 'ITA', '2016-12-13 11:15:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1473', 'Bari', 'ITA', '2016-12-13 11:15:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1474', 'Venezia', 'ITA', '2016-12-13 11:15:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1475', 'Messina', 'ITA', '2016-12-13 11:15:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1476', 'Verona', 'ITA', '2016-12-13 11:15:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1477', 'Trieste', 'ITA', '2016-12-13 11:15:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1478', 'Padova', 'ITA', '2016-12-13 11:15:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1479', 'Taranto', 'ITA', '2016-12-13 11:15:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1480', 'Brescia', 'ITA', '2016-12-13 11:15:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1481', 'Reggio di Calabria', 'ITA', '2016-12-13 11:15:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1482', 'Modena', 'ITA', '2016-12-13 11:15:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1483', 'Prato', 'ITA', '2016-12-13 11:15:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1484', 'Parma', 'ITA', '2016-12-13 11:15:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1485', 'Cagliari', 'ITA', '2016-12-13 11:15:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1486', 'Livorno', 'ITA', '2016-12-13 11:15:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1487', 'Perugia', 'ITA', '2016-12-13 11:15:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1488', 'Foggia', 'ITA', '2016-12-13 11:15:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1489', 'Reggio nellÂ´ Emilia', 'ITA', '2016-12-13 11:15:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1490', 'Salerno', 'ITA', '2016-12-13 11:15:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1491', 'Ravenna', 'ITA', '2016-12-13 11:15:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1492', 'Ferrara', 'ITA', '2016-12-13 11:15:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1493', 'Rimini', 'ITA', '2016-12-13 11:15:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1494', 'Syrakusa', 'ITA', '2016-12-13 11:15:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1495', 'Sassari', 'ITA', '2016-12-13 11:15:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1496', 'Monza', 'ITA', '2016-12-13 11:15:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1497', 'Bergamo', 'ITA', '2016-12-13 11:15:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1498', 'Pescara', 'ITA', '2016-12-13 11:15:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1499', 'Latina', 'ITA', '2016-12-13 11:15:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1500', 'Vicenza', 'ITA', '2016-12-13 11:15:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1501', 'Terni', 'ITA', '2016-12-13 11:15:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1502', 'ForlÃ¬', 'ITA', '2016-12-13 11:15:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1503', 'Trento', 'ITA', '2016-12-13 11:15:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1504', 'Novara', 'ITA', '2016-12-13 11:15:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1505', 'Piacenza', 'ITA', '2016-12-13 11:15:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1506', 'Ancona', 'ITA', '2016-12-13 11:15:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1507', 'Lecce', 'ITA', '2016-12-13 11:15:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1508', 'Bolzano', 'ITA', '2016-12-13 11:15:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1509', 'Catanzaro', 'ITA', '2016-12-13 11:15:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1510', 'La Spezia', 'ITA', '2016-12-13 11:15:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1511', 'Udine', 'ITA', '2016-12-13 11:15:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1512', 'Torre del Greco', 'ITA', '2016-12-13 11:15:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1513', 'Andria', 'ITA', '2016-12-13 11:15:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1514', 'Brindisi', 'ITA', '2016-12-13 11:15:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1515', 'Giugliano in Campania', 'ITA', '2016-12-13 11:15:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1516', 'Pisa', 'ITA', '2016-12-13 11:15:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1517', 'Barletta', 'ITA', '2016-12-13 11:15:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1518', 'Arezzo', 'ITA', '2016-12-13 11:15:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1519', 'Alessandria', 'ITA', '2016-12-13 11:15:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1520', 'Cesena', 'ITA', '2016-12-13 11:15:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1521', 'Pesaro', 'ITA', '2016-12-13 11:15:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1522', 'Dili', 'TMP', '2016-12-13 11:15:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1523', 'Wien', 'AUT', '2016-12-13 11:15:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1524', 'Graz', 'AUT', '2016-12-13 11:15:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1525', 'Linz', 'AUT', '2016-12-13 11:15:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1526', 'Salzburg', 'AUT', '2016-12-13 11:15:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1527', 'Innsbruck', 'AUT', '2016-12-13 11:15:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1528', 'Klagenfurt', 'AUT', '2016-12-13 11:15:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1529', 'Spanish Town', 'JAM', '2016-12-13 11:15:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1530', 'Kingston', 'JAM', '2016-12-13 11:15:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1531', 'Portmore', 'JAM', '2016-12-13 11:15:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1532', 'Tokyo', 'JPN', '2016-12-13 11:15:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1533', 'Jokohama [Yokohama]', 'JPN', '2016-12-13 11:15:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1534', 'Osaka', 'JPN', '2016-12-13 11:15:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1535', 'Nagoya', 'JPN', '2016-12-13 11:15:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1536', 'Sapporo', 'JPN', '2016-12-13 11:15:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1537', 'Kioto', 'JPN', '2016-12-13 11:15:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1538', 'Kobe', 'JPN', '2016-12-13 11:15:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1539', 'Fukuoka', 'JPN', '2016-12-13 11:15:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1540', 'Kawasaki', 'JPN', '2016-12-13 11:15:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1541', 'Hiroshima', 'JPN', '2016-12-13 11:15:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1542', 'Kitakyushu', 'JPN', '2016-12-13 11:15:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1543', 'Sendai', 'JPN', '2016-12-13 11:15:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1544', 'Chiba', 'JPN', '2016-12-13 11:15:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1545', 'Sakai', 'JPN', '2016-12-13 11:15:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1546', 'Kumamoto', 'JPN', '2016-12-13 11:15:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1547', 'Okayama', 'JPN', '2016-12-13 11:15:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1548', 'Sagamihara', 'JPN', '2016-12-13 11:15:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1549', 'Hamamatsu', 'JPN', '2016-12-13 11:15:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1550', 'Kagoshima', 'JPN', '2016-12-13 11:15:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1551', 'Funabashi', 'JPN', '2016-12-13 11:15:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1552', 'Higashiosaka', 'JPN', '2016-12-13 11:15:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1553', 'Hachioji', 'JPN', '2016-12-13 11:15:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1554', 'Niigata', 'JPN', '2016-12-13 11:15:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1555', 'Amagasaki', 'JPN', '2016-12-13 11:15:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1556', 'Himeji', 'JPN', '2016-12-13 11:15:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1557', 'Shizuoka', 'JPN', '2016-12-13 11:15:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1558', 'Urawa', 'JPN', '2016-12-13 11:15:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1559', 'Matsuyama', 'JPN', '2016-12-13 11:15:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1560', 'Matsudo', 'JPN', '2016-12-13 11:15:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1561', 'Kanazawa', 'JPN', '2016-12-13 11:15:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1562', 'Kawaguchi', 'JPN', '2016-12-13 11:15:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1563', 'Ichikawa', 'JPN', '2016-12-13 11:15:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1564', 'Omiya', 'JPN', '2016-12-13 11:15:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1565', 'Utsunomiya', 'JPN', '2016-12-13 11:15:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1566', 'Oita', 'JPN', '2016-12-13 11:15:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1567', 'Nagasaki', 'JPN', '2016-12-13 11:15:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1568', 'Yokosuka', 'JPN', '2016-12-13 11:15:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1569', 'Kurashiki', 'JPN', '2016-12-13 11:15:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1570', 'Gifu', 'JPN', '2016-12-13 11:15:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1571', 'Hirakata', 'JPN', '2016-12-13 11:15:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1572', 'Nishinomiya', 'JPN', '2016-12-13 11:15:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1573', 'Toyonaka', 'JPN', '2016-12-13 11:15:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1574', 'Wakayama', 'JPN', '2016-12-13 11:15:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1575', 'Fukuyama', 'JPN', '2016-12-13 11:15:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1576', 'Fujisawa', 'JPN', '2016-12-13 11:15:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1577', 'Asahikawa', 'JPN', '2016-12-13 11:15:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1578', 'Machida', 'JPN', '2016-12-13 11:15:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1579', 'Nara', 'JPN', '2016-12-13 11:15:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1580', 'Takatsuki', 'JPN', '2016-12-13 11:15:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1581', 'Iwaki', 'JPN', '2016-12-13 11:15:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1582', 'Nagano', 'JPN', '2016-12-13 11:15:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1583', 'Toyohashi', 'JPN', '2016-12-13 11:15:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1584', 'Toyota', 'JPN', '2016-12-13 11:15:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1585', 'Suita', 'JPN', '2016-12-13 11:15:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1586', 'Takamatsu', 'JPN', '2016-12-13 11:15:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1587', 'Koriyama', 'JPN', '2016-12-13 11:15:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1588', 'Okazaki', 'JPN', '2016-12-13 11:15:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1589', 'Kawagoe', 'JPN', '2016-12-13 11:15:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1590', 'Tokorozawa', 'JPN', '2016-12-13 11:15:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1591', 'Toyama', 'JPN', '2016-12-13 11:15:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1592', 'Kochi', 'JPN', '2016-12-13 11:15:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1593', 'Kashiwa', 'JPN', '2016-12-13 11:15:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1594', 'Akita', 'JPN', '2016-12-13 11:15:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1595', 'Miyazaki', 'JPN', '2016-12-13 11:15:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1596', 'Koshigaya', 'JPN', '2016-12-13 11:15:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1597', 'Naha', 'JPN', '2016-12-13 11:15:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1598', 'Aomori', 'JPN', '2016-12-13 11:15:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1599', 'Hakodate', 'JPN', '2016-12-13 11:15:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1600', 'Akashi', 'JPN', '2016-12-13 11:15:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1601', 'Yokkaichi', 'JPN', '2016-12-13 11:15:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1602', 'Fukushima', 'JPN', '2016-12-13 11:15:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1603', 'Morioka', 'JPN', '2016-12-13 11:15:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1604', 'Maebashi', 'JPN', '2016-12-13 11:15:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1605', 'Kasugai', 'JPN', '2016-12-13 11:15:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1606', 'Otsu', 'JPN', '2016-12-13 11:15:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1607', 'Ichihara', 'JPN', '2016-12-13 11:15:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1608', 'Yao', 'JPN', '2016-12-13 11:15:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1609', 'Ichinomiya', 'JPN', '2016-12-13 11:15:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1610', 'Tokushima', 'JPN', '2016-12-13 11:15:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1611', 'Kakogawa', 'JPN', '2016-12-13 11:15:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1612', 'Ibaraki', 'JPN', '2016-12-13 11:15:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1613', 'Neyagawa', 'JPN', '2016-12-13 11:15:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1614', 'Shimonoseki', 'JPN', '2016-12-13 11:15:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1615', 'Yamagata', 'JPN', '2016-12-13 11:15:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1616', 'Fukui', 'JPN', '2016-12-13 11:15:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1617', 'Hiratsuka', 'JPN', '2016-12-13 11:15:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1618', 'Mito', 'JPN', '2016-12-13 11:15:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1619', 'Sasebo', 'JPN', '2016-12-13 11:15:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1620', 'Hachinohe', 'JPN', '2016-12-13 11:15:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1621', 'Takasaki', 'JPN', '2016-12-13 11:15:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1622', 'Shimizu', 'JPN', '2016-12-13 11:15:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1623', 'Kurume', 'JPN', '2016-12-13 11:15:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1624', 'Fuji', 'JPN', '2016-12-13 11:15:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1625', 'Soka', 'JPN', '2016-12-13 11:15:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1626', 'Fuchu', 'JPN', '2016-12-13 11:15:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1627', 'Chigasaki', 'JPN', '2016-12-13 11:15:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1628', 'Atsugi', 'JPN', '2016-12-13 11:15:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1629', 'Numazu', 'JPN', '2016-12-13 11:15:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1630', 'Ageo', 'JPN', '2016-12-13 11:15:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1631', 'Yamato', 'JPN', '2016-12-13 11:15:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1632', 'Matsumoto', 'JPN', '2016-12-13 11:15:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1633', 'Kure', 'JPN', '2016-12-13 11:15:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1634', 'Takarazuka', 'JPN', '2016-12-13 11:15:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1635', 'Kasukabe', 'JPN', '2016-12-13 11:15:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1636', 'Chofu', 'JPN', '2016-12-13 11:15:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1637', 'Odawara', 'JPN', '2016-12-13 11:15:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1638', 'Kofu', 'JPN', '2016-12-13 11:15:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1639', 'Kushiro', 'JPN', '2016-12-13 11:15:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1640', 'Kishiwada', 'JPN', '2016-12-13 11:15:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1641', 'Hitachi', 'JPN', '2016-12-13 11:15:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1642', 'Nagaoka', 'JPN', '2016-12-13 11:15:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1643', 'Itami', 'JPN', '2016-12-13 11:15:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1644', 'Uji', 'JPN', '2016-12-13 11:15:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1645', 'Suzuka', 'JPN', '2016-12-13 11:15:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1646', 'Hirosaki', 'JPN', '2016-12-13 11:15:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1647', 'Ube', 'JPN', '2016-12-13 11:15:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1648', 'Kodaira', 'JPN', '2016-12-13 11:15:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1649', 'Takaoka', 'JPN', '2016-12-13 11:15:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1650', 'Obihiro', 'JPN', '2016-12-13 11:15:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1651', 'Tomakomai', 'JPN', '2016-12-13 11:15:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1652', 'Saga', 'JPN', '2016-12-13 11:15:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1653', 'Sakura', 'JPN', '2016-12-13 11:15:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1654', 'Kamakura', 'JPN', '2016-12-13 11:15:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1655', 'Mitaka', 'JPN', '2016-12-13 11:15:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1656', 'Izumi', 'JPN', '2016-12-13 11:15:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1657', 'Hino', 'JPN', '2016-12-13 11:15:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1658', 'Hadano', 'JPN', '2016-12-13 11:15:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1659', 'Ashikaga', 'JPN', '2016-12-13 11:15:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1660', 'Tsu', 'JPN', '2016-12-13 11:15:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1661', 'Sayama', 'JPN', '2016-12-13 11:15:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1662', 'Yachiyo', 'JPN', '2016-12-13 11:15:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1663', 'Tsukuba', 'JPN', '2016-12-13 11:15:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1664', 'Tachikawa', 'JPN', '2016-12-13 11:15:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1665', 'Kumagaya', 'JPN', '2016-12-13 11:15:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1666', 'Moriguchi', 'JPN', '2016-12-13 11:15:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1667', 'Otaru', 'JPN', '2016-12-13 11:15:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1668', 'Anjo', 'JPN', '2016-12-13 11:15:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1669', 'Narashino', 'JPN', '2016-12-13 11:15:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1670', 'Oyama', 'JPN', '2016-12-13 11:15:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1671', 'Ogaki', 'JPN', '2016-12-13 11:15:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1672', 'Matsue', 'JPN', '2016-12-13 11:15:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1673', 'Kawanishi', 'JPN', '2016-12-13 11:15:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1674', 'Hitachinaka', 'JPN', '2016-12-13 11:15:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1675', 'Niiza', 'JPN', '2016-12-13 11:15:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1676', 'Nagareyama', 'JPN', '2016-12-13 11:15:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1677', 'Tottori', 'JPN', '2016-12-13 11:15:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1678', 'Tama', 'JPN', '2016-12-13 11:15:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1679', 'Iruma', 'JPN', '2016-12-13 11:15:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1680', 'Ota', 'JPN', '2016-12-13 11:15:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1681', 'Omuta', 'JPN', '2016-12-13 11:15:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1682', 'Komaki', 'JPN', '2016-12-13 11:15:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1683', 'Ome', 'JPN', '2016-12-13 11:15:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1684', 'Kadoma', 'JPN', '2016-12-13 11:15:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1685', 'Yamaguchi', 'JPN', '2016-12-13 11:15:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1686', 'Higashimurayama', 'JPN', '2016-12-13 11:15:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1687', 'Yonago', 'JPN', '2016-12-13 11:15:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1688', 'Matsubara', 'JPN', '2016-12-13 11:15:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1689', 'Musashino', 'JPN', '2016-12-13 11:15:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1690', 'Tsuchiura', 'JPN', '2016-12-13 11:15:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1691', 'Joetsu', 'JPN', '2016-12-13 11:15:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1692', 'Miyakonojo', 'JPN', '2016-12-13 11:15:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1693', 'Misato', 'JPN', '2016-12-13 11:15:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1694', 'Kakamigahara', 'JPN', '2016-12-13 11:15:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1695', 'Daito', 'JPN', '2016-12-13 11:15:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1696', 'Seto', 'JPN', '2016-12-13 11:15:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1697', 'Kariya', 'JPN', '2016-12-13 11:15:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1698', 'Urayasu', 'JPN', '2016-12-13 11:15:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1699', 'Beppu', 'JPN', '2016-12-13 11:15:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1700', 'Niihama', 'JPN', '2016-12-13 11:15:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1701', 'Minoo', 'JPN', '2016-12-13 11:15:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1702', 'Fujieda', 'JPN', '2016-12-13 11:15:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1703', 'Abiko', 'JPN', '2016-12-13 11:15:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1704', 'Nobeoka', 'JPN', '2016-12-13 11:15:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1705', 'Tondabayashi', 'JPN', '2016-12-13 11:15:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1706', 'Ueda', 'JPN', '2016-12-13 11:15:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1707', 'Kashihara', 'JPN', '2016-12-13 11:16:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1708', 'Matsusaka', 'JPN', '2016-12-13 11:16:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1709', 'Isesaki', 'JPN', '2016-12-13 11:16:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1710', 'Zama', 'JPN', '2016-12-13 11:16:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1711', 'Kisarazu', 'JPN', '2016-12-13 11:16:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1712', 'Noda', 'JPN', '2016-12-13 11:16:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1713', 'Ishinomaki', 'JPN', '2016-12-13 11:16:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1714', 'Fujinomiya', 'JPN', '2016-12-13 11:16:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1715', 'Kawachinagano', 'JPN', '2016-12-13 11:16:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1716', 'Imabari', 'JPN', '2016-12-13 11:16:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1717', 'Aizuwakamatsu', 'JPN', '2016-12-13 11:16:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1718', 'Higashihiroshima', 'JPN', '2016-12-13 11:16:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1719', 'Habikino', 'JPN', '2016-12-13 11:16:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1720', 'Ebetsu', 'JPN', '2016-12-13 11:16:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1721', 'Hofu', 'JPN', '2016-12-13 11:16:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1722', 'Kiryu', 'JPN', '2016-12-13 11:16:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1723', 'Okinawa', 'JPN', '2016-12-13 11:16:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1724', 'Yaizu', 'JPN', '2016-12-13 11:16:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1725', 'Toyokawa', 'JPN', '2016-12-13 11:16:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1726', 'Ebina', 'JPN', '2016-12-13 11:16:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1727', 'Asaka', 'JPN', '2016-12-13 11:16:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1728', 'Higashikurume', 'JPN', '2016-12-13 11:16:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1729', 'Ikoma', 'JPN', '2016-12-13 11:16:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1730', 'Kitami', 'JPN', '2016-12-13 11:16:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1731', 'Koganei', 'JPN', '2016-12-13 11:16:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1732', 'Iwatsuki', 'JPN', '2016-12-13 11:16:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1733', 'Mishima', 'JPN', '2016-12-13 11:16:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1734', 'Handa', 'JPN', '2016-12-13 11:16:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1735', 'Muroran', 'JPN', '2016-12-13 11:16:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1736', 'Komatsu', 'JPN', '2016-12-13 11:16:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1737', 'Yatsushiro', 'JPN', '2016-12-13 11:16:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1738', 'Iida', 'JPN', '2016-12-13 11:16:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1739', 'Tokuyama', 'JPN', '2016-12-13 11:16:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1740', 'Kokubunji', 'JPN', '2016-12-13 11:16:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1741', 'Akishima', 'JPN', '2016-12-13 11:16:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1742', 'Iwakuni', 'JPN', '2016-12-13 11:16:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1743', 'Kusatsu', 'JPN', '2016-12-13 11:16:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1744', 'Kuwana', 'JPN', '2016-12-13 11:16:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1745', 'Sanda', 'JPN', '2016-12-13 11:16:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1746', 'Hikone', 'JPN', '2016-12-13 11:16:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1747', 'Toda', 'JPN', '2016-12-13 11:16:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1748', 'Tajimi', 'JPN', '2016-12-13 11:16:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1749', 'Ikeda', 'JPN', '2016-12-13 11:16:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1750', 'Fukaya', 'JPN', '2016-12-13 11:16:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1751', 'Ise', 'JPN', '2016-12-13 11:16:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1752', 'Sakata', 'JPN', '2016-12-13 11:16:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1753', 'Kasuga', 'JPN', '2016-12-13 11:16:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1754', 'Kamagaya', 'JPN', '2016-12-13 11:16:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1755', 'Tsuruoka', 'JPN', '2016-12-13 11:16:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1756', 'Hoya', 'JPN', '2016-12-13 11:16:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1757', 'Nishio', 'JPN', '2016-12-13 11:16:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1758', 'Tokai', 'JPN', '2016-12-13 11:16:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1759', 'Inazawa', 'JPN', '2016-12-13 11:16:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1760', 'Sakado', 'JPN', '2016-12-13 11:16:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1761', 'Isehara', 'JPN', '2016-12-13 11:16:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1762', 'Takasago', 'JPN', '2016-12-13 11:16:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1763', 'Fujimi', 'JPN', '2016-12-13 11:16:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1764', 'Urasoe', 'JPN', '2016-12-13 11:16:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1765', 'Yonezawa', 'JPN', '2016-12-13 11:16:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1766', 'Konan', 'JPN', '2016-12-13 11:16:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1767', 'Yamatokoriyama', 'JPN', '2016-12-13 11:16:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1768', 'Maizuru', 'JPN', '2016-12-13 11:16:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1769', 'Onomichi', 'JPN', '2016-12-13 11:16:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1770', 'Higashimatsuyama', 'JPN', '2016-12-13 11:16:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1771', 'Kimitsu', 'JPN', '2016-12-13 11:16:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1772', 'Isahaya', 'JPN', '2016-12-13 11:16:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1773', 'Kanuma', 'JPN', '2016-12-13 11:16:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1774', 'Izumisano', 'JPN', '2016-12-13 11:16:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1775', 'Kameoka', 'JPN', '2016-12-13 11:16:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1776', 'Mobara', 'JPN', '2016-12-13 11:16:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1777', 'Narita', 'JPN', '2016-12-13 11:16:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1778', 'Kashiwazaki', 'JPN', '2016-12-13 11:16:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1779', 'Tsuyama', 'JPN', '2016-12-13 11:16:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1780', 'Sanaa', 'YEM', '2016-12-13 11:16:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1781', 'Aden', 'YEM', '2016-12-13 11:16:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1782', 'Taizz', 'YEM', '2016-12-13 11:16:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1783', 'Hodeida', 'YEM', '2016-12-13 11:16:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1784', 'al-Mukalla', 'YEM', '2016-12-13 11:16:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1785', 'Ibb', 'YEM', '2016-12-13 11:16:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1786', 'Amman', 'JOR', '2016-12-13 11:16:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1787', 'al-Zarqa', 'JOR', '2016-12-13 11:16:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1788', 'Irbid', 'JOR', '2016-12-13 11:16:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1789', 'al-Rusayfa', 'JOR', '2016-12-13 11:16:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1790', 'Wadi al-Sir', 'JOR', '2016-12-13 11:16:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1791', 'Flying Fish Cove', 'CXR', '2016-12-13 11:16:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1792', 'Beograd', 'YUG', '2016-12-13 11:16:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1793', 'Novi Sad', 'YUG', '2016-12-13 11:16:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1794', 'NiÅ¡', 'YUG', '2016-12-13 11:16:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1795', 'PriÅ¡tina', 'YUG', '2016-12-13 11:16:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1796', 'Kragujevac', 'YUG', '2016-12-13 11:16:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1797', 'Podgorica', 'YUG', '2016-12-13 11:16:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1798', 'Subotica', 'YUG', '2016-12-13 11:16:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1799', 'Prizren', 'YUG', '2016-12-13 11:16:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1800', 'Phnom Penh', 'KHM', '2016-12-13 11:16:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1801', 'Battambang', 'KHM', '2016-12-13 11:16:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1802', 'Siem Reap', 'KHM', '2016-12-13 11:16:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1803', 'Douala', 'CMR', '2016-12-13 11:16:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1804', 'YaoundÃ©', 'CMR', '2016-12-13 11:16:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1805', 'Garoua', 'CMR', '2016-12-13 11:16:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1806', 'Maroua', 'CMR', '2016-12-13 11:16:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1807', 'Bamenda', 'CMR', '2016-12-13 11:16:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1808', 'Bafoussam', 'CMR', '2016-12-13 11:16:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1809', 'Nkongsamba', 'CMR', '2016-12-13 11:16:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1810', 'MontrÃ©al', 'CAN', '2016-12-13 11:16:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1811', 'Calgary', 'CAN', '2016-12-13 11:16:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1812', 'Toronto', 'CAN', '2016-12-13 11:16:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1813', 'North York', 'CAN', '2016-12-13 11:16:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1814', 'Winnipeg', 'CAN', '2016-12-13 11:16:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1815', 'Edmonton', 'CAN', '2016-12-13 11:16:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1816', 'Mississauga', 'CAN', '2016-12-13 11:16:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1817', 'Scarborough', 'CAN', '2016-12-13 11:16:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1818', 'Vancouver', 'CAN', '2016-12-13 11:16:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1819', 'Etobicoke', 'CAN', '2016-12-13 11:16:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1820', 'London', 'CAN', '2016-12-13 11:16:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1821', 'Hamilton', 'CAN', '2016-12-13 11:16:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1822', 'Ottawa', 'CAN', '2016-12-13 11:16:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1823', 'Laval', 'CAN', '2016-12-13 11:16:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1824', 'Surrey', 'CAN', '2016-12-13 11:16:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1825', 'Brampton', 'CAN', '2016-12-13 11:16:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1826', 'Windsor', 'CAN', '2016-12-13 11:16:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1827', 'Saskatoon', 'CAN', '2016-12-13 11:16:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1828', 'Kitchener', 'CAN', '2016-12-13 11:16:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1829', 'Markham', 'CAN', '2016-12-13 11:16:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1830', 'Regina', 'CAN', '2016-12-13 11:16:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1831', 'Burnaby', 'CAN', '2016-12-13 11:16:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1832', 'QuÃ©bec', 'CAN', '2016-12-13 11:16:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1833', 'York', 'CAN', '2016-12-13 11:16:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1834', 'Richmond', 'CAN', '2016-12-13 11:16:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1835', 'Vaughan', 'CAN', '2016-12-13 11:16:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1836', 'Burlington', 'CAN', '2016-12-13 11:16:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1837', 'Oshawa', 'CAN', '2016-12-13 11:16:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1838', 'Oakville', 'CAN', '2016-12-13 11:16:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1839', 'Saint Catharines', 'CAN', '2016-12-13 11:16:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1840', 'Longueuil', 'CAN', '2016-12-13 11:16:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1841', 'Richmond Hill', 'CAN', '2016-12-13 11:16:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1842', 'Thunder Bay', 'CAN', '2016-12-13 11:16:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1843', 'Nepean', 'CAN', '2016-12-13 11:16:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1844', 'Cape Breton', 'CAN', '2016-12-13 11:16:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1845', 'East York', 'CAN', '2016-12-13 11:16:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1846', 'Halifax', 'CAN', '2016-12-13 11:16:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1847', 'Cambridge', 'CAN', '2016-12-13 11:16:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1848', 'Gloucester', 'CAN', '2016-12-13 11:16:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1849', 'Abbotsford', 'CAN', '2016-12-13 11:16:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1850', 'Guelph', 'CAN', '2016-12-13 11:16:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1851', 'Saint JohnÂ´s', 'CAN', '2016-12-13 11:16:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1852', 'Coquitlam', 'CAN', '2016-12-13 11:16:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1853', 'Saanich', 'CAN', '2016-12-13 11:16:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1854', 'Gatineau', 'CAN', '2016-12-13 11:16:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1855', 'Delta', 'CAN', '2016-12-13 11:16:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1856', 'Sudbury', 'CAN', '2016-12-13 11:16:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1857', 'Kelowna', 'CAN', '2016-12-13 11:16:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1858', 'Barrie', 'CAN', '2016-12-13 11:16:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1859', 'Praia', 'CPV', '2016-12-13 11:16:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1860', 'Almaty', 'KAZ', '2016-12-13 11:16:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1861', 'Qaraghandy', 'KAZ', '2016-12-13 11:16:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1862', 'Shymkent', 'KAZ', '2016-12-13 11:16:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1863', 'Taraz', 'KAZ', '2016-12-13 11:16:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1864', 'Astana', 'KAZ', '2016-12-13 11:16:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1865', 'Ã–skemen', 'KAZ', '2016-12-13 11:16:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1866', 'Pavlodar', 'KAZ', '2016-12-13 11:16:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1867', 'Semey', 'KAZ', '2016-12-13 11:16:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1868', 'AqtÃ¶be', 'KAZ', '2016-12-13 11:16:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1869', 'Qostanay', 'KAZ', '2016-12-13 11:16:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1870', 'Petropavl', 'KAZ', '2016-12-13 11:16:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1871', 'Oral', 'KAZ', '2016-12-13 11:16:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1872', 'Temirtau', 'KAZ', '2016-12-13 11:16:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1873', 'Qyzylorda', 'KAZ', '2016-12-13 11:16:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1874', 'Aqtau', 'KAZ', '2016-12-13 11:16:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1875', 'Atyrau', 'KAZ', '2016-12-13 11:16:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1876', 'Ekibastuz', 'KAZ', '2016-12-13 11:16:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1877', 'KÃ¶kshetau', 'KAZ', '2016-12-13 11:16:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1878', 'Rudnyy', 'KAZ', '2016-12-13 11:16:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1879', 'Taldyqorghan', 'KAZ', '2016-12-13 11:16:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1880', 'Zhezqazghan', 'KAZ', '2016-12-13 11:16:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1881', 'Nairobi', 'KEN', '2016-12-13 11:16:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1882', 'Mombasa', 'KEN', '2016-12-13 11:16:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1883', 'Kisumu', 'KEN', '2016-12-13 11:16:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1884', 'Nakuru', 'KEN', '2016-12-13 11:16:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1885', 'Machakos', 'KEN', '2016-12-13 11:16:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1886', 'Eldoret', 'KEN', '2016-12-13 11:16:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1887', 'Meru', 'KEN', '2016-12-13 11:16:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1888', 'Nyeri', 'KEN', '2016-12-13 11:16:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1889', 'Bangui', 'CAF', '2016-12-13 11:16:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1890', 'Shanghai', 'CHN', '2016-12-13 11:16:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1891', 'Peking', 'CHN', '2016-12-13 11:16:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1892', 'Chongqing', 'CHN', '2016-12-13 11:16:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1893', 'Tianjin', 'CHN', '2016-12-13 11:16:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1894', 'Wuhan', 'CHN', '2016-12-13 11:16:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1895', 'Harbin', 'CHN', '2016-12-13 11:16:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1896', 'Shenyang', 'CHN', '2016-12-13 11:16:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1897', 'Kanton [Guangzhou]', 'CHN', '2016-12-13 11:16:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1898', 'Chengdu', 'CHN', '2016-12-13 11:16:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1899', 'Nanking [Nanjing]', 'CHN', '2016-12-13 11:16:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1900', 'Changchun', 'CHN', '2016-12-13 11:16:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1901', 'XiÂ´an', 'CHN', '2016-12-13 11:16:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1902', 'Dalian', 'CHN', '2016-12-13 11:16:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1903', 'Qingdao', 'CHN', '2016-12-13 11:16:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1904', 'Jinan', 'CHN', '2016-12-13 11:16:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1905', 'Hangzhou', 'CHN', '2016-12-13 11:16:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1906', 'Zhengzhou', 'CHN', '2016-12-13 11:16:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1907', 'Shijiazhuang', 'CHN', '2016-12-13 11:16:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1908', 'Taiyuan', 'CHN', '2016-12-13 11:16:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1909', 'Kunming', 'CHN', '2016-12-13 11:16:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1910', 'Changsha', 'CHN', '2016-12-13 11:16:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1911', 'Nanchang', 'CHN', '2016-12-13 11:16:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1912', 'Fuzhou', 'CHN', '2016-12-13 11:16:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1913', 'Lanzhou', 'CHN', '2016-12-13 11:16:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1914', 'Guiyang', 'CHN', '2016-12-13 11:16:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1915', 'Ningbo', 'CHN', '2016-12-13 11:16:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1916', 'Hefei', 'CHN', '2016-12-13 11:16:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1917', 'UrumtÅ¡i [ÃœrÃ¼mqi]', 'CHN', '2016-12-13 11:16:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1918', 'Anshan', 'CHN', '2016-12-13 11:16:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1919', 'Fushun', 'CHN', '2016-12-13 11:16:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1920', 'Nanning', 'CHN', '2016-12-13 11:16:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1921', 'Zibo', 'CHN', '2016-12-13 11:16:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1922', 'Qiqihar', 'CHN', '2016-12-13 11:16:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1923', 'Jilin', 'CHN', '2016-12-13 11:16:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1924', 'Tangshan', 'CHN', '2016-12-13 11:16:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1925', 'Baotou', 'CHN', '2016-12-13 11:16:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1926', 'Shenzhen', 'CHN', '2016-12-13 11:16:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1927', 'Hohhot', 'CHN', '2016-12-13 11:16:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1928', 'Handan', 'CHN', '2016-12-13 11:16:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1929', 'Wuxi', 'CHN', '2016-12-13 11:16:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1930', 'Xuzhou', 'CHN', '2016-12-13 11:16:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1931', 'Datong', 'CHN', '2016-12-13 11:16:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1932', 'Yichun', 'CHN', '2016-12-13 11:16:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1933', 'Benxi', 'CHN', '2016-12-13 11:16:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1934', 'Luoyang', 'CHN', '2016-12-13 11:16:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1935', 'Suzhou', 'CHN', '2016-12-13 11:16:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1936', 'Xining', 'CHN', '2016-12-13 11:16:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1937', 'Huainan', 'CHN', '2016-12-13 11:16:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1938', 'Jixi', 'CHN', '2016-12-13 11:16:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1939', 'Daqing', 'CHN', '2016-12-13 11:16:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1940', 'Fuxin', 'CHN', '2016-12-13 11:16:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1941', 'Amoy [Xiamen]', 'CHN', '2016-12-13 11:16:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1942', 'Liuzhou', 'CHN', '2016-12-13 11:16:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1943', 'Shantou', 'CHN', '2016-12-13 11:16:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1944', 'Jinzhou', 'CHN', '2016-12-13 11:16:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1945', 'Mudanjiang', 'CHN', '2016-12-13 11:16:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1946', 'Yinchuan', 'CHN', '2016-12-13 11:16:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1947', 'Changzhou', 'CHN', '2016-12-13 11:16:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1948', 'Zhangjiakou', 'CHN', '2016-12-13 11:16:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1949', 'Dandong', 'CHN', '2016-12-13 11:16:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1950', 'Hegang', 'CHN', '2016-12-13 11:16:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1951', 'Kaifeng', 'CHN', '2016-12-13 11:16:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1952', 'Jiamusi', 'CHN', '2016-12-13 11:16:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1953', 'Liaoyang', 'CHN', '2016-12-13 11:16:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1954', 'Hengyang', 'CHN', '2016-12-13 11:16:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1955', 'Baoding', 'CHN', '2016-12-13 11:16:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1956', 'Hunjiang', 'CHN', '2016-12-13 11:16:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1957', 'Xinxiang', 'CHN', '2016-12-13 11:16:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1958', 'Huangshi', 'CHN', '2016-12-13 11:16:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1959', 'Haikou', 'CHN', '2016-12-13 11:16:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1960', 'Yantai', 'CHN', '2016-12-13 11:16:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1961', 'Bengbu', 'CHN', '2016-12-13 11:16:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1962', 'Xiangtan', 'CHN', '2016-12-13 11:16:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1963', 'Weifang', 'CHN', '2016-12-13 11:16:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1964', 'Wuhu', 'CHN', '2016-12-13 11:16:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1965', 'Pingxiang', 'CHN', '2016-12-13 11:16:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1966', 'Yingkou', 'CHN', '2016-12-13 11:16:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1967', 'Anyang', 'CHN', '2016-12-13 11:16:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1968', 'Panzhihua', 'CHN', '2016-12-13 11:16:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1969', 'Pingdingshan', 'CHN', '2016-12-13 11:16:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1970', 'Xiangfan', 'CHN', '2016-12-13 11:16:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1971', 'Zhuzhou', 'CHN', '2016-12-13 11:16:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1972', 'Jiaozuo', 'CHN', '2016-12-13 11:16:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1973', 'Wenzhou', 'CHN', '2016-12-13 11:16:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1974', 'Zhangjiang', 'CHN', '2016-12-13 11:16:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1975', 'Zigong', 'CHN', '2016-12-13 11:16:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1976', 'Shuangyashan', 'CHN', '2016-12-13 11:16:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1977', 'Zaozhuang', 'CHN', '2016-12-13 11:16:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1978', 'Yakeshi', 'CHN', '2016-12-13 11:16:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1979', 'Yichang', 'CHN', '2016-12-13 11:16:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1980', 'Zhenjiang', 'CHN', '2016-12-13 11:16:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1981', 'Huaibei', 'CHN', '2016-12-13 11:16:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1982', 'Qinhuangdao', 'CHN', '2016-12-13 11:16:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1983', 'Guilin', 'CHN', '2016-12-13 11:16:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1984', 'Liupanshui', 'CHN', '2016-12-13 11:16:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1985', 'Panjin', 'CHN', '2016-12-13 11:16:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1986', 'Yangquan', 'CHN', '2016-12-13 11:16:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1987', 'Jinxi', 'CHN', '2016-12-13 11:16:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1988', 'Liaoyuan', 'CHN', '2016-12-13 11:16:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1989', 'Lianyungang', 'CHN', '2016-12-13 11:16:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1990', 'Xianyang', 'CHN', '2016-12-13 11:16:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1991', 'TaiÂ´an', 'CHN', '2016-12-13 11:16:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1992', 'Chifeng', 'CHN', '2016-12-13 11:16:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1993', 'Shaoguan', 'CHN', '2016-12-13 11:16:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1994', 'Nantong', 'CHN', '2016-12-13 11:16:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1995', 'Leshan', 'CHN', '2016-12-13 11:16:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1996', 'Baoji', 'CHN', '2016-12-13 11:16:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1997', 'Linyi', 'CHN', '2016-12-13 11:16:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1998', 'Tonghua', 'CHN', '2016-12-13 11:16:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('1999', 'Siping', 'CHN', '2016-12-13 11:16:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2000', 'Changzhi', 'CHN', '2016-12-13 11:16:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2001', 'Tengzhou', 'CHN', '2016-12-13 11:16:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2002', 'Chaozhou', 'CHN', '2016-12-13 11:16:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2003', 'Yangzhou', 'CHN', '2016-12-13 11:16:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2004', 'Dongwan', 'CHN', '2016-12-13 11:16:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2005', 'MaÂ´anshan', 'CHN', '2016-12-13 11:16:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2006', 'Foshan', 'CHN', '2016-12-13 11:16:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2007', 'Yueyang', 'CHN', '2016-12-13 11:16:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2008', 'Xingtai', 'CHN', '2016-12-13 11:16:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2009', 'Changde', 'CHN', '2016-12-13 11:16:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2010', 'Shihezi', 'CHN', '2016-12-13 11:16:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2011', 'Yancheng', 'CHN', '2016-12-13 11:16:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2012', 'Jiujiang', 'CHN', '2016-12-13 11:16:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2013', 'Dongying', 'CHN', '2016-12-13 11:16:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2014', 'Shashi', 'CHN', '2016-12-13 11:16:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2015', 'Xintai', 'CHN', '2016-12-13 11:16:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2016', 'Jingdezhen', 'CHN', '2016-12-13 11:16:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2017', 'Tongchuan', 'CHN', '2016-12-13 11:16:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2018', 'Zhongshan', 'CHN', '2016-12-13 11:16:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2019', 'Shiyan', 'CHN', '2016-12-13 11:16:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2020', 'Tieli', 'CHN', '2016-12-13 11:16:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2021', 'Jining', 'CHN', '2016-12-13 11:16:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2022', 'Wuhai', 'CHN', '2016-12-13 11:16:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2023', 'Mianyang', 'CHN', '2016-12-13 11:16:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2024', 'Luzhou', 'CHN', '2016-12-13 11:16:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2025', 'Zunyi', 'CHN', '2016-12-13 11:16:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2026', 'Shizuishan', 'CHN', '2016-12-13 11:16:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2027', 'Neijiang', 'CHN', '2016-12-13 11:16:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2028', 'Tongliao', 'CHN', '2016-12-13 11:16:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2029', 'Tieling', 'CHN', '2016-12-13 11:16:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2030', 'Wafangdian', 'CHN', '2016-12-13 11:16:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2031', 'Anqing', 'CHN', '2016-12-13 11:16:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2032', 'Shaoyang', 'CHN', '2016-12-13 11:16:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2033', 'Laiwu', 'CHN', '2016-12-13 11:16:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2034', 'Chengde', 'CHN', '2016-12-13 11:16:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2035', 'Tianshui', 'CHN', '2016-12-13 11:16:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2036', 'Nanyang', 'CHN', '2016-12-13 11:16:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2037', 'Cangzhou', 'CHN', '2016-12-13 11:16:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2038', 'Yibin', 'CHN', '2016-12-13 11:16:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2039', 'Huaiyin', 'CHN', '2016-12-13 11:16:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2040', 'Dunhua', 'CHN', '2016-12-13 11:16:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2041', 'Yanji', 'CHN', '2016-12-13 11:16:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2042', 'Jiangmen', 'CHN', '2016-12-13 11:16:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2043', 'Tongling', 'CHN', '2016-12-13 11:16:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2044', 'Suihua', 'CHN', '2016-12-13 11:16:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2045', 'Gongziling', 'CHN', '2016-12-13 11:16:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2046', 'Xiantao', 'CHN', '2016-12-13 11:16:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2047', 'Chaoyang', 'CHN', '2016-12-13 11:16:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2048', 'Ganzhou', 'CHN', '2016-12-13 11:16:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2049', 'Huzhou', 'CHN', '2016-12-13 11:16:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2050', 'Baicheng', 'CHN', '2016-12-13 11:16:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2051', 'Shangzi', 'CHN', '2016-12-13 11:16:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2052', 'Yangjiang', 'CHN', '2016-12-13 11:16:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2053', 'Qitaihe', 'CHN', '2016-12-13 11:16:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2054', 'Gejiu', 'CHN', '2016-12-13 11:16:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2055', 'Jiangyin', 'CHN', '2016-12-13 11:16:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2056', 'Hebi', 'CHN', '2016-12-13 11:16:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2057', 'Jiaxing', 'CHN', '2016-12-13 11:16:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2058', 'Wuzhou', 'CHN', '2016-12-13 11:16:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2059', 'Meihekou', 'CHN', '2016-12-13 11:16:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2060', 'Xuchang', 'CHN', '2016-12-13 11:16:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2061', 'Liaocheng', 'CHN', '2016-12-13 11:16:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2062', 'Haicheng', 'CHN', '2016-12-13 11:16:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2063', 'Qianjiang', 'CHN', '2016-12-13 11:16:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2064', 'Baiyin', 'CHN', '2016-12-13 11:16:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2065', 'BeiÂ´an', 'CHN', '2016-12-13 11:16:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2066', 'Yixing', 'CHN', '2016-12-13 11:16:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2067', 'Laizhou', 'CHN', '2016-12-13 11:16:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2068', 'Qaramay', 'CHN', '2016-12-13 11:16:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2069', 'Acheng', 'CHN', '2016-12-13 11:16:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2070', 'Dezhou', 'CHN', '2016-12-13 11:16:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2071', 'Nanping', 'CHN', '2016-12-13 11:16:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2072', 'Zhaoqing', 'CHN', '2016-12-13 11:16:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2073', 'Beipiao', 'CHN', '2016-12-13 11:16:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2074', 'Fengcheng', 'CHN', '2016-12-13 11:16:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2075', 'Fuyu', 'CHN', '2016-12-13 11:16:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2076', 'Xinyang', 'CHN', '2016-12-13 11:16:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2077', 'Dongtai', 'CHN', '2016-12-13 11:16:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2078', 'Yuci', 'CHN', '2016-12-13 11:16:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2079', 'Honghu', 'CHN', '2016-12-13 11:16:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2080', 'Ezhou', 'CHN', '2016-12-13 11:16:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2081', 'Heze', 'CHN', '2016-12-13 11:16:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2082', 'Daxian', 'CHN', '2016-12-13 11:16:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2083', 'Linfen', 'CHN', '2016-12-13 11:16:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2084', 'Tianmen', 'CHN', '2016-12-13 11:16:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2085', 'Yiyang', 'CHN', '2016-12-13 11:16:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2086', 'Quanzhou', 'CHN', '2016-12-13 11:16:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2087', 'Rizhao', 'CHN', '2016-12-13 11:16:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2088', 'Deyang', 'CHN', '2016-12-13 11:16:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2089', 'Guangyuan', 'CHN', '2016-12-13 11:16:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2090', 'Changshu', 'CHN', '2016-12-13 11:16:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2091', 'Zhangzhou', 'CHN', '2016-12-13 11:16:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2092', 'Hailar', 'CHN', '2016-12-13 11:16:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2093', 'Nanchong', 'CHN', '2016-12-13 11:16:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2094', 'Jiutai', 'CHN', '2016-12-13 11:16:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2095', 'Zhaodong', 'CHN', '2016-12-13 11:16:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2096', 'Shaoxing', 'CHN', '2016-12-13 11:16:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2097', 'Fuyang', 'CHN', '2016-12-13 11:16:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2098', 'Maoming', 'CHN', '2016-12-13 11:16:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2099', 'Qujing', 'CHN', '2016-12-13 11:16:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2100', 'Ghulja', 'CHN', '2016-12-13 11:16:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2101', 'Jiaohe', 'CHN', '2016-12-13 11:16:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2102', 'Puyang', 'CHN', '2016-12-13 11:16:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2103', 'Huadian', 'CHN', '2016-12-13 11:16:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2104', 'Jiangyou', 'CHN', '2016-12-13 11:16:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2105', 'Qashqar', 'CHN', '2016-12-13 11:16:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2106', 'Anshun', 'CHN', '2016-12-13 11:16:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2107', 'Fuling', 'CHN', '2016-12-13 11:16:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2108', 'Xinyu', 'CHN', '2016-12-13 11:16:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2109', 'Hanzhong', 'CHN', '2016-12-13 11:16:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2110', 'Danyang', 'CHN', '2016-12-13 11:16:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2111', 'Chenzhou', 'CHN', '2016-12-13 11:16:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2112', 'Xiaogan', 'CHN', '2016-12-13 11:16:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2113', 'Shangqiu', 'CHN', '2016-12-13 11:16:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2114', 'Zhuhai', 'CHN', '2016-12-13 11:16:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2115', 'Qingyuan', 'CHN', '2016-12-13 11:16:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2116', 'Aqsu', 'CHN', '2016-12-13 11:16:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2117', 'Jining', 'CHN', '2016-12-13 11:16:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2118', 'Xiaoshan', 'CHN', '2016-12-13 11:16:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2119', 'Zaoyang', 'CHN', '2016-12-13 11:16:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2120', 'Xinghua', 'CHN', '2016-12-13 11:16:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2121', 'Hami', 'CHN', '2016-12-13 11:16:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2122', 'Huizhou', 'CHN', '2016-12-13 11:16:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2123', 'Jinmen', 'CHN', '2016-12-13 11:16:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2124', 'Sanming', 'CHN', '2016-12-13 11:16:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2125', 'Ulanhot', 'CHN', '2016-12-13 11:16:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2126', 'Korla', 'CHN', '2016-12-13 11:16:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2127', 'Wanxian', 'CHN', '2016-12-13 11:16:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2128', 'RuiÂ´an', 'CHN', '2016-12-13 11:16:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2129', 'Zhoushan', 'CHN', '2016-12-13 11:16:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2130', 'Liangcheng', 'CHN', '2016-12-13 11:16:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2131', 'Jiaozhou', 'CHN', '2016-12-13 11:16:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2132', 'Taizhou', 'CHN', '2016-12-13 11:16:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2133', 'Suzhou', 'CHN', '2016-12-13 11:16:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2134', 'Yichun', 'CHN', '2016-12-13 11:16:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2135', 'Taonan', 'CHN', '2016-12-13 11:16:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2136', 'Pingdu', 'CHN', '2016-12-13 11:16:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2137', 'JiÂ´an', 'CHN', '2016-12-13 11:16:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2138', 'Longkou', 'CHN', '2016-12-13 11:16:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2139', 'Langfang', 'CHN', '2016-12-13 11:16:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2140', 'Zhoukou', 'CHN', '2016-12-13 11:16:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2141', 'Suining', 'CHN', '2016-12-13 11:16:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2142', 'Yulin', 'CHN', '2016-12-13 11:16:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2143', 'Jinhua', 'CHN', '2016-12-13 11:16:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2144', 'LiuÂ´an', 'CHN', '2016-12-13 11:16:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2145', 'Shuangcheng', 'CHN', '2016-12-13 11:16:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2146', 'Suizhou', 'CHN', '2016-12-13 11:16:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2147', 'Ankang', 'CHN', '2016-12-13 11:16:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2148', 'Weinan', 'CHN', '2016-12-13 11:16:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2149', 'Longjing', 'CHN', '2016-12-13 11:16:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2150', 'DaÂ´an', 'CHN', '2016-12-13 11:16:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2151', 'Lengshuijiang', 'CHN', '2016-12-13 11:16:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2152', 'Laiyang', 'CHN', '2016-12-13 11:16:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2153', 'Xianning', 'CHN', '2016-12-13 11:16:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2154', 'Dali', 'CHN', '2016-12-13 11:16:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2155', 'Anda', 'CHN', '2016-12-13 11:16:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2156', 'Jincheng', 'CHN', '2016-12-13 11:16:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2157', 'Longyan', 'CHN', '2016-12-13 11:16:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2158', 'Xichang', 'CHN', '2016-12-13 11:16:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2159', 'Wendeng', 'CHN', '2016-12-13 11:16:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2160', 'Hailun', 'CHN', '2016-12-13 11:16:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2161', 'Binzhou', 'CHN', '2016-12-13 11:16:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2162', 'Linhe', 'CHN', '2016-12-13 11:16:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2163', 'Wuwei', 'CHN', '2016-12-13 11:16:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2164', 'Duyun', 'CHN', '2016-12-13 11:16:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2165', 'Mishan', 'CHN', '2016-12-13 11:16:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2166', 'Shangrao', 'CHN', '2016-12-13 11:16:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2167', 'Changji', 'CHN', '2016-12-13 11:16:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2168', 'Meixian', 'CHN', '2016-12-13 11:16:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2169', 'Yushu', 'CHN', '2016-12-13 11:16:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2170', 'Tiefa', 'CHN', '2016-12-13 11:16:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2171', 'HuaiÂ´an', 'CHN', '2016-12-13 11:16:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2172', 'Leiyang', 'CHN', '2016-12-13 11:16:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2173', 'Zalantun', 'CHN', '2016-12-13 11:16:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2174', 'Weihai', 'CHN', '2016-12-13 11:16:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2175', 'Loudi', 'CHN', '2016-12-13 11:16:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2176', 'Qingzhou', 'CHN', '2016-12-13 11:16:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2177', 'Qidong', 'CHN', '2016-12-13 11:16:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2178', 'Huaihua', 'CHN', '2016-12-13 11:16:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2179', 'Luohe', 'CHN', '2016-12-13 11:16:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2180', 'Chuzhou', 'CHN', '2016-12-13 11:16:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2181', 'Kaiyuan', 'CHN', '2016-12-13 11:16:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2182', 'Linqing', 'CHN', '2016-12-13 11:16:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2183', 'Chaohu', 'CHN', '2016-12-13 11:16:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2184', 'Laohekou', 'CHN', '2016-12-13 11:16:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2185', 'Dujiangyan', 'CHN', '2016-12-13 11:16:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2186', 'Zhumadian', 'CHN', '2016-12-13 11:16:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2187', 'Linchuan', 'CHN', '2016-12-13 11:16:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2188', 'Jiaonan', 'CHN', '2016-12-13 11:16:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2189', 'Sanmenxia', 'CHN', '2016-12-13 11:16:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2190', 'Heyuan', 'CHN', '2016-12-13 11:16:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2191', 'Manzhouli', 'CHN', '2016-12-13 11:16:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2192', 'Lhasa', 'CHN', '2016-12-13 11:16:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2193', 'Lianyuan', 'CHN', '2016-12-13 11:16:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2194', 'Kuytun', 'CHN', '2016-12-13 11:16:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2195', 'Puqi', 'CHN', '2016-12-13 11:16:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2196', 'Hongjiang', 'CHN', '2016-12-13 11:16:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2197', 'Qinzhou', 'CHN', '2016-12-13 11:16:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2198', 'Renqiu', 'CHN', '2016-12-13 11:16:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2199', 'Yuyao', 'CHN', '2016-12-13 11:16:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2200', 'Guigang', 'CHN', '2016-12-13 11:16:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2201', 'Kaili', 'CHN', '2016-12-13 11:16:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2202', 'YanÂ´an', 'CHN', '2016-12-13 11:16:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2203', 'Beihai', 'CHN', '2016-12-13 11:16:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2204', 'Xuangzhou', 'CHN', '2016-12-13 11:16:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2205', 'Quzhou', 'CHN', '2016-12-13 11:16:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2206', 'YongÂ´an', 'CHN', '2016-12-13 11:16:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2207', 'Zixing', 'CHN', '2016-12-13 11:16:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2208', 'Liyang', 'CHN', '2016-12-13 11:16:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2209', 'Yizheng', 'CHN', '2016-12-13 11:16:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2210', 'Yumen', 'CHN', '2016-12-13 11:16:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2211', 'Liling', 'CHN', '2016-12-13 11:16:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2212', 'Yuncheng', 'CHN', '2016-12-13 11:16:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2213', 'Shanwei', 'CHN', '2016-12-13 11:16:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2214', 'Cixi', 'CHN', '2016-12-13 11:16:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2215', 'Yuanjiang', 'CHN', '2016-12-13 11:16:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2216', 'Bozhou', 'CHN', '2016-12-13 11:16:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2217', 'Jinchang', 'CHN', '2016-12-13 11:16:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2218', 'FuÂ´an', 'CHN', '2016-12-13 11:16:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2219', 'Suqian', 'CHN', '2016-12-13 11:16:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2220', 'Shishou', 'CHN', '2016-12-13 11:16:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2221', 'Hengshui', 'CHN', '2016-12-13 11:16:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2222', 'Danjiangkou', 'CHN', '2016-12-13 11:16:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2223', 'Fujin', 'CHN', '2016-12-13 11:16:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2224', 'Sanya', 'CHN', '2016-12-13 11:16:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2225', 'Guangshui', 'CHN', '2016-12-13 11:16:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2226', 'Huangshan', 'CHN', '2016-12-13 11:16:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2227', 'Xingcheng', 'CHN', '2016-12-13 11:16:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2228', 'Zhucheng', 'CHN', '2016-12-13 11:16:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2229', 'Kunshan', 'CHN', '2016-12-13 11:16:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2230', 'Haining', 'CHN', '2016-12-13 11:16:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2231', 'Pingliang', 'CHN', '2016-12-13 11:16:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2232', 'Fuqing', 'CHN', '2016-12-13 11:16:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2233', 'Xinzhou', 'CHN', '2016-12-13 11:16:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2234', 'Jieyang', 'CHN', '2016-12-13 11:16:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2235', 'Zhangjiagang', 'CHN', '2016-12-13 11:16:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2236', 'Tong Xian', 'CHN', '2016-12-13 11:16:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2237', 'YaÂ´an', 'CHN', '2016-12-13 11:16:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2238', 'Jinzhou', 'CHN', '2016-12-13 11:16:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2239', 'Emeishan', 'CHN', '2016-12-13 11:16:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2240', 'Enshi', 'CHN', '2016-12-13 11:16:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2241', 'Bose', 'CHN', '2016-12-13 11:16:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2242', 'Yuzhou', 'CHN', '2016-12-13 11:16:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2243', 'Kaiyuan', 'CHN', '2016-12-13 11:16:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2244', 'Tumen', 'CHN', '2016-12-13 11:16:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2245', 'Putian', 'CHN', '2016-12-13 11:16:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2246', 'Linhai', 'CHN', '2016-12-13 11:16:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2247', 'Xilin Hot', 'CHN', '2016-12-13 11:16:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2248', 'Shaowu', 'CHN', '2016-12-13 11:16:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2249', 'Junan', 'CHN', '2016-12-13 11:16:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2250', 'Huaying', 'CHN', '2016-12-13 11:16:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2251', 'Pingyi', 'CHN', '2016-12-13 11:16:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2252', 'Huangyan', 'CHN', '2016-12-13 11:16:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2253', 'Bishkek', 'KGZ', '2016-12-13 11:16:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2254', 'Osh', 'KGZ', '2016-12-13 11:16:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2255', 'Bikenibeu', 'KIR', '2016-12-13 11:16:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2256', 'Bairiki', 'KIR', '2016-12-13 11:16:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2257', 'Bogotá D.C.', 'COL', '2016-12-13 11:32:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2258', 'Cali', 'COL', '2016-12-13 11:16:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2259', 'Medellín', 'COL', '2016-12-13 11:32:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2260', 'Barranquilla', 'COL', '2016-12-13 11:16:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2261', 'Cartagena', 'COL', '2016-12-13 11:16:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2262', 'Cúcuta', 'COL', '2016-12-13 11:32:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2263', 'Bucaramanga', 'COL', '2016-12-13 11:16:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2264', 'Ibague', 'COL', '2016-12-13 11:32:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2265', 'Pereira', 'COL', '2016-12-13 11:16:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2266', 'Santa Marta', 'COL', '2016-12-13 11:16:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2267', 'Manizales', 'COL', '2016-12-13 11:16:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2268', 'Bello', 'COL', '2016-12-13 11:16:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2269', 'Pasto', 'COL', '2016-12-13 11:16:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2270', 'Neiva', 'COL', '2016-12-13 11:16:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2271', 'Soledad', 'COL', '2016-12-13 11:16:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2272', 'Armenia', 'COL', '2016-12-13 11:16:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2273', 'Villavicencio', 'COL', '2016-12-13 11:16:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2274', 'Soacha', 'COL', '2016-12-13 11:16:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2275', 'Valledupar', 'COL', '2016-12-13 11:16:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2276', 'Montería', 'COL', '2016-12-13 11:32:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2277', 'Itagui', 'COL', '2016-12-13 11:32:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2278', 'Palmira', 'COL', '2016-12-13 11:16:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2279', 'Buenaventura', 'COL', '2016-12-13 11:16:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2280', 'Floridablanca', 'COL', '2016-12-13 11:16:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2281', 'Sincelejo', 'COL', '2016-12-13 11:16:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2282', 'Popayán', 'COL', '2016-12-13 11:33:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2283', 'Barrancabermeja', 'COL', '2016-12-13 11:16:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2284', 'Dos Quebradas', 'COL', '2016-12-13 11:16:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2285', 'Tuluá', 'COL', '2016-12-13 11:33:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2286', 'Envigado', 'COL', '2016-12-13 11:16:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2287', 'Cartago', 'COL', '2016-12-13 11:16:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2288', 'Girardot', 'COL', '2016-12-13 11:16:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2289', 'Buga', 'COL', '2016-12-13 11:16:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2290', 'Tunja', 'COL', '2016-12-13 11:16:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2291', 'Florencia', 'COL', '2016-12-13 11:16:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2292', 'Maicao', 'COL', '2016-12-13 11:16:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2293', 'Sogamoso', 'COL', '2016-12-13 11:16:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2294', 'Giron', 'COL', '2016-12-13 11:16:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2295', 'Moroni', 'COM', '2016-12-13 11:16:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2296', 'Brazzaville', 'COG', '2016-12-13 11:16:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2297', 'Pointe-Noire', 'COG', '2016-12-13 11:16:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2298', 'Kinshasa', 'COD', '2016-12-13 11:16:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2299', 'Lubumbashi', 'COD', '2016-12-13 11:16:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2300', 'Mbuji-Mayi', 'COD', '2016-12-13 11:16:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2301', 'Kolwezi', 'COD', '2016-12-13 11:16:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2302', 'Kisangani', 'COD', '2016-12-13 11:16:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2303', 'Kananga', 'COD', '2016-12-13 11:16:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2304', 'Likasi', 'COD', '2016-12-13 11:16:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2305', 'Bukavu', 'COD', '2016-12-13 11:16:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2306', 'Kikwit', 'COD', '2016-12-13 11:16:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2307', 'Tshikapa', 'COD', '2016-12-13 11:16:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2308', 'Matadi', 'COD', '2016-12-13 11:16:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2309', 'Mbandaka', 'COD', '2016-12-13 11:16:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2310', 'Mwene-Ditu', 'COD', '2016-12-13 11:16:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2311', 'Boma', 'COD', '2016-12-13 11:16:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2312', 'Uvira', 'COD', '2016-12-13 11:16:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2313', 'Butembo', 'COD', '2016-12-13 11:16:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2314', 'Goma', 'COD', '2016-12-13 11:16:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2315', 'Kalemie', 'COD', '2016-12-13 11:16:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2316', 'Bantam', 'CCK', '2016-12-13 11:16:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2317', 'West Island', 'CCK', '2016-12-13 11:16:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2318', 'Pyongyang', 'PRK', '2016-12-13 11:16:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2319', 'Hamhung', 'PRK', '2016-12-13 11:16:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2320', 'Chongjin', 'PRK', '2016-12-13 11:16:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2321', 'Nampo', 'PRK', '2016-12-13 11:16:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2322', 'Sinuiju', 'PRK', '2016-12-13 11:16:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2323', 'Wonsan', 'PRK', '2016-12-13 11:16:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2324', 'Phyongsong', 'PRK', '2016-12-13 11:16:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2325', 'Sariwon', 'PRK', '2016-12-13 11:16:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2326', 'Haeju', 'PRK', '2016-12-13 11:16:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2327', 'Kanggye', 'PRK', '2016-12-13 11:16:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2328', 'Kimchaek', 'PRK', '2016-12-13 11:16:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2329', 'Hyesan', 'PRK', '2016-12-13 11:16:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2330', 'Kaesong', 'PRK', '2016-12-13 11:16:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2331', 'Seoul', 'KOR', '2016-12-13 11:16:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2332', 'Pusan', 'KOR', '2016-12-13 11:16:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2333', 'Inchon', 'KOR', '2016-12-13 11:16:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2334', 'Taegu', 'KOR', '2016-12-13 11:16:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2335', 'Taejon', 'KOR', '2016-12-13 11:16:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2336', 'Kwangju', 'KOR', '2016-12-13 11:16:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2337', 'Ulsan', 'KOR', '2016-12-13 11:16:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2338', 'Songnam', 'KOR', '2016-12-13 11:16:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2339', 'Puchon', 'KOR', '2016-12-13 11:16:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2340', 'Suwon', 'KOR', '2016-12-13 11:16:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2341', 'Anyang', 'KOR', '2016-12-13 11:16:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2342', 'Chonju', 'KOR', '2016-12-13 11:16:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2343', 'Chongju', 'KOR', '2016-12-13 11:16:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2344', 'Koyang', 'KOR', '2016-12-13 11:16:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2345', 'Ansan', 'KOR', '2016-12-13 11:16:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2346', 'Pohang', 'KOR', '2016-12-13 11:16:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2347', 'Chang-won', 'KOR', '2016-12-13 11:16:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2348', 'Masan', 'KOR', '2016-12-13 11:16:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2349', 'Kwangmyong', 'KOR', '2016-12-13 11:16:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2350', 'Chonan', 'KOR', '2016-12-13 11:16:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2351', 'Chinju', 'KOR', '2016-12-13 11:16:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2352', 'Iksan', 'KOR', '2016-12-13 11:16:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2353', 'Pyongtaek', 'KOR', '2016-12-13 11:16:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2354', 'Kumi', 'KOR', '2016-12-13 11:16:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2355', 'Uijongbu', 'KOR', '2016-12-13 11:16:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2356', 'Kyongju', 'KOR', '2016-12-13 11:16:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2357', 'Kunsan', 'KOR', '2016-12-13 11:16:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2358', 'Cheju', 'KOR', '2016-12-13 11:16:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2359', 'Kimhae', 'KOR', '2016-12-13 11:16:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2360', 'Sunchon', 'KOR', '2016-12-13 11:16:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2361', 'Mokpo', 'KOR', '2016-12-13 11:16:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2362', 'Yong-in', 'KOR', '2016-12-13 11:16:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2363', 'Wonju', 'KOR', '2016-12-13 11:16:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2364', 'Kunpo', 'KOR', '2016-12-13 11:16:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2365', 'Chunchon', 'KOR', '2016-12-13 11:16:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2366', 'Namyangju', 'KOR', '2016-12-13 11:16:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2367', 'Kangnung', 'KOR', '2016-12-13 11:16:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2368', 'Chungju', 'KOR', '2016-12-13 11:16:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2369', 'Andong', 'KOR', '2016-12-13 11:16:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2370', 'Yosu', 'KOR', '2016-12-13 11:16:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2371', 'Kyongsan', 'KOR', '2016-12-13 11:16:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2372', 'Paju', 'KOR', '2016-12-13 11:16:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2373', 'Yangsan', 'KOR', '2016-12-13 11:16:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2374', 'Ichon', 'KOR', '2016-12-13 11:16:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2375', 'Asan', 'KOR', '2016-12-13 11:16:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2376', 'Koje', 'KOR', '2016-12-13 11:16:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2377', 'Kimchon', 'KOR', '2016-12-13 11:16:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2378', 'Nonsan', 'KOR', '2016-12-13 11:16:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2379', 'Kuri', 'KOR', '2016-12-13 11:16:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2380', 'Chong-up', 'KOR', '2016-12-13 11:16:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2381', 'Chechon', 'KOR', '2016-12-13 11:16:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2382', 'Sosan', 'KOR', '2016-12-13 11:16:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2383', 'Shihung', 'KOR', '2016-12-13 11:16:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2384', 'Tong-yong', 'KOR', '2016-12-13 11:16:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2385', 'Kongju', 'KOR', '2016-12-13 11:16:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2386', 'Yongju', 'KOR', '2016-12-13 11:16:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2387', 'Chinhae', 'KOR', '2016-12-13 11:16:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2388', 'Sangju', 'KOR', '2016-12-13 11:16:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2389', 'Poryong', 'KOR', '2016-12-13 11:16:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2390', 'Kwang-yang', 'KOR', '2016-12-13 11:16:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2391', 'Miryang', 'KOR', '2016-12-13 11:16:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2392', 'Hanam', 'KOR', '2016-12-13 11:16:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2393', 'Kimje', 'KOR', '2016-12-13 11:16:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2394', 'Yongchon', 'KOR', '2016-12-13 11:16:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2395', 'Sachon', 'KOR', '2016-12-13 11:16:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2396', 'Uiwang', 'KOR', '2016-12-13 11:16:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2397', 'Naju', 'KOR', '2016-12-13 11:16:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2398', 'Namwon', 'KOR', '2016-12-13 11:16:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2399', 'Tonghae', 'KOR', '2016-12-13 11:16:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2400', 'Mun-gyong', 'KOR', '2016-12-13 11:16:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2401', 'Athenai', 'GRC', '2016-12-13 11:17:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2402', 'Thessaloniki', 'GRC', '2016-12-13 11:17:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2403', 'Pireus', 'GRC', '2016-12-13 11:17:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2404', 'Patras', 'GRC', '2016-12-13 11:17:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2405', 'Peristerion', 'GRC', '2016-12-13 11:17:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2406', 'Herakleion', 'GRC', '2016-12-13 11:17:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2407', 'Kallithea', 'GRC', '2016-12-13 11:17:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2408', 'Larisa', 'GRC', '2016-12-13 11:17:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2409', 'Zagreb', 'HRV', '2016-12-13 11:17:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2410', 'Split', 'HRV', '2016-12-13 11:17:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2411', 'Rijeka', 'HRV', '2016-12-13 11:17:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2412', 'Osijek', 'HRV', '2016-12-13 11:17:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2413', 'La Habana', 'CUB', '2016-12-13 11:17:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2414', 'Santiago de Cuba', 'CUB', '2016-12-13 11:17:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2415', 'CamagÃ¼ey', 'CUB', '2016-12-13 11:17:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2416', 'HolguÃ­n', 'CUB', '2016-12-13 11:17:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2417', 'Santa Clara', 'CUB', '2016-12-13 11:17:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2418', 'GuantÃ¡namo', 'CUB', '2016-12-13 11:17:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2419', 'Pinar del RÃ­o', 'CUB', '2016-12-13 11:17:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2420', 'Bayamo', 'CUB', '2016-12-13 11:17:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2421', 'Cienfuegos', 'CUB', '2016-12-13 11:17:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2422', 'Victoria de las Tunas', 'CUB', '2016-12-13 11:17:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2423', 'Matanzas', 'CUB', '2016-12-13 11:17:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2424', 'Manzanillo', 'CUB', '2016-12-13 11:17:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2425', 'Sancti-SpÃ­ritus', 'CUB', '2016-12-13 11:17:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2426', 'Ciego de Ãvila', 'CUB', '2016-12-13 11:17:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2427', 'al-Salimiya', 'KWT', '2016-12-13 11:17:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2428', 'Jalib al-Shuyukh', 'KWT', '2016-12-13 11:17:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2429', 'Kuwait', 'KWT', '2016-12-13 11:17:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2430', 'Nicosia', 'CYP', '2016-12-13 11:17:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2431', 'Limassol', 'CYP', '2016-12-13 11:17:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2432', 'Vientiane', 'LAO', '2016-12-13 11:17:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2433', 'Savannakhet', 'LAO', '2016-12-13 11:17:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2434', 'Riga', 'LVA', '2016-12-13 11:17:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2435', 'Daugavpils', 'LVA', '2016-12-13 11:17:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2436', 'Liepaja', 'LVA', '2016-12-13 11:17:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2437', 'Maseru', 'LSO', '2016-12-13 11:17:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2438', 'Beirut', 'LBN', '2016-12-13 11:17:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2439', 'Tripoli', 'LBN', '2016-12-13 11:17:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2440', 'Monrovia', 'LBR', '2016-12-13 11:17:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2441', 'Tripoli', 'LBY', '2016-12-13 11:17:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2442', 'Bengasi', 'LBY', '2016-12-13 11:17:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2443', 'Misrata', 'LBY', '2016-12-13 11:17:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2444', 'al-Zawiya', 'LBY', '2016-12-13 11:17:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2445', 'Schaan', 'LIE', '2016-12-13 11:17:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2446', 'Vaduz', 'LIE', '2016-12-13 11:17:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2447', 'Vilnius', 'LTU', '2016-12-13 11:17:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2448', 'Kaunas', 'LTU', '2016-12-13 11:17:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2449', 'Klaipeda', 'LTU', '2016-12-13 11:17:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2450', 'Å iauliai', 'LTU', '2016-12-13 11:17:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2451', 'Panevezys', 'LTU', '2016-12-13 11:17:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2452', 'Luxembourg [Luxemburg/LÃ«tzebuerg]', 'LUX', '2016-12-13 11:17:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2453', 'El-AaiÃºn', 'ESH', '2016-12-13 11:17:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2454', 'Macao', 'MAC', '2016-12-13 11:17:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2455', 'Antananarivo', 'MDG', '2016-12-13 11:17:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2456', 'Toamasina', 'MDG', '2016-12-13 11:17:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2457', 'AntsirabÃ©', 'MDG', '2016-12-13 11:17:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2458', 'Mahajanga', 'MDG', '2016-12-13 11:17:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2459', 'Fianarantsoa', 'MDG', '2016-12-13 11:17:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2460', 'Skopje', 'MKD', '2016-12-13 11:17:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2461', 'Blantyre', 'MWI', '2016-12-13 11:17:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2462', 'Lilongwe', 'MWI', '2016-12-13 11:17:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2463', 'Male', 'MDV', '2016-12-13 11:17:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2464', 'Kuala Lumpur', 'MYS', '2016-12-13 11:17:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2465', 'Ipoh', 'MYS', '2016-12-13 11:17:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2466', 'Johor Baharu', 'MYS', '2016-12-13 11:17:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2467', 'Petaling Jaya', 'MYS', '2016-12-13 11:17:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2468', 'Kelang', 'MYS', '2016-12-13 11:17:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2469', 'Kuala Terengganu', 'MYS', '2016-12-13 11:17:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2470', 'Pinang', 'MYS', '2016-12-13 11:17:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2471', 'Kota Bharu', 'MYS', '2016-12-13 11:17:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2472', 'Kuantan', 'MYS', '2016-12-13 11:17:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2473', 'Taiping', 'MYS', '2016-12-13 11:17:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2474', 'Seremban', 'MYS', '2016-12-13 11:17:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2475', 'Kuching', 'MYS', '2016-12-13 11:17:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2476', 'Sibu', 'MYS', '2016-12-13 11:17:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2477', 'Sandakan', 'MYS', '2016-12-13 11:17:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2478', 'Alor Setar', 'MYS', '2016-12-13 11:17:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2479', 'Selayang Baru', 'MYS', '2016-12-13 11:17:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2480', 'Sungai Petani', 'MYS', '2016-12-13 11:17:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2481', 'Shah Alam', 'MYS', '2016-12-13 11:17:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2482', 'Bamako', 'MLI', '2016-12-13 11:17:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2483', 'Birkirkara', 'MLT', '2016-12-13 11:17:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2484', 'Valletta', 'MLT', '2016-12-13 11:17:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2485', 'Casablanca', 'MAR', '2016-12-13 11:17:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2486', 'Rabat', 'MAR', '2016-12-13 11:17:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2487', 'Marrakech', 'MAR', '2016-12-13 11:17:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2488', 'FÃ¨s', 'MAR', '2016-12-13 11:17:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2489', 'Tanger', 'MAR', '2016-12-13 11:17:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2490', 'SalÃ©', 'MAR', '2016-12-13 11:17:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2491', 'MeknÃ¨s', 'MAR', '2016-12-13 11:17:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2492', 'Oujda', 'MAR', '2016-12-13 11:17:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2493', 'KÃ©nitra', 'MAR', '2016-12-13 11:17:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2494', 'TÃ©touan', 'MAR', '2016-12-13 11:17:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2495', 'Safi', 'MAR', '2016-12-13 11:17:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2496', 'Agadir', 'MAR', '2016-12-13 11:17:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2497', 'Mohammedia', 'MAR', '2016-12-13 11:17:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2498', 'Khouribga', 'MAR', '2016-12-13 11:17:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2499', 'Beni-Mellal', 'MAR', '2016-12-13 11:17:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2500', 'TÃ©mara', 'MAR', '2016-12-13 11:17:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2501', 'El Jadida', 'MAR', '2016-12-13 11:17:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2502', 'Nador', 'MAR', '2016-12-13 11:17:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2503', 'Ksar el Kebir', 'MAR', '2016-12-13 11:17:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2504', 'Settat', 'MAR', '2016-12-13 11:17:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2505', 'Taza', 'MAR', '2016-12-13 11:17:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2506', 'El Araich', 'MAR', '2016-12-13 11:17:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2507', 'Dalap-Uliga-Darrit', 'MHL', '2016-12-13 11:17:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2508', 'Fort-de-France', 'MTQ', '2016-12-13 11:17:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2509', 'Nouakchott', 'MRT', '2016-12-13 11:17:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2510', 'NouÃ¢dhibou', 'MRT', '2016-12-13 11:17:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2511', 'Port-Louis', 'MUS', '2016-12-13 11:17:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2512', 'Beau Bassin-Rose Hill', 'MUS', '2016-12-13 11:17:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2513', 'Vacoas-Phoenix', 'MUS', '2016-12-13 11:17:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2514', 'Mamoutzou', 'MYT', '2016-12-13 11:17:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2515', 'Ciudad de MÃ©xico', 'MEX', '2016-12-13 11:17:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2516', 'Guadalajara', 'MEX', '2016-12-13 11:17:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2517', 'Ecatepec de Morelos', 'MEX', '2016-12-13 11:17:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2518', 'Puebla', 'MEX', '2016-12-13 11:17:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2519', 'NezahualcÃ³yotl', 'MEX', '2016-12-13 11:17:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2520', 'JuÃ¡rez', 'MEX', '2016-12-13 11:17:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2521', 'Tijuana', 'MEX', '2016-12-13 11:17:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2522', 'LeÃ³n', 'MEX', '2016-12-13 11:17:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2523', 'Monterrey', 'MEX', '2016-12-13 11:17:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2524', 'Zapopan', 'MEX', '2016-12-13 11:17:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2525', 'Naucalpan de JuÃ¡rez', 'MEX', '2016-12-13 11:17:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2526', 'Mexicali', 'MEX', '2016-12-13 11:17:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2527', 'CuliacÃ¡n', 'MEX', '2016-12-13 11:17:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2528', 'Acapulco de JuÃ¡rez', 'MEX', '2016-12-13 11:17:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2529', 'Tlalnepantla de Baz', 'MEX', '2016-12-13 11:17:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2530', 'MÃ©rida', 'MEX', '2016-12-13 11:17:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2531', 'Chihuahua', 'MEX', '2016-12-13 11:17:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2532', 'San Luis PotosÃ­', 'MEX', '2016-12-13 11:17:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2533', 'Guadalupe', 'MEX', '2016-12-13 11:17:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2534', 'Toluca', 'MEX', '2016-12-13 11:17:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2535', 'Aguascalientes', 'MEX', '2016-12-13 11:17:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2536', 'QuerÃ©taro', 'MEX', '2016-12-13 11:17:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2537', 'Morelia', 'MEX', '2016-12-13 11:17:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2538', 'Hermosillo', 'MEX', '2016-12-13 11:17:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2539', 'Saltillo', 'MEX', '2016-12-13 11:17:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2540', 'TorreÃ³n', 'MEX', '2016-12-13 11:17:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2541', 'Centro (Villahermosa)', 'MEX', '2016-12-13 11:17:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2542', 'San NicolÃ¡s de los Garza', 'MEX', '2016-12-13 11:17:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2543', 'Durango', 'MEX', '2016-12-13 11:17:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2544', 'ChimalhuacÃ¡n', 'MEX', '2016-12-13 11:17:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2545', 'Tlaquepaque', 'MEX', '2016-12-13 11:17:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2546', 'AtizapÃ¡n de Zaragoza', 'MEX', '2016-12-13 11:17:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2547', 'Veracruz', 'MEX', '2016-12-13 11:17:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2548', 'CuautitlÃ¡n Izcalli', 'MEX', '2016-12-13 11:17:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2549', 'Irapuato', 'MEX', '2016-12-13 11:17:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2550', 'Tuxtla GutiÃ©rrez', 'MEX', '2016-12-13 11:17:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2551', 'TultitlÃ¡n', 'MEX', '2016-12-13 11:17:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2552', 'Reynosa', 'MEX', '2016-12-13 11:17:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2553', 'Benito JuÃ¡rez', 'MEX', '2016-12-13 11:17:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2554', 'Matamoros', 'MEX', '2016-12-13 11:17:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2555', 'Xalapa', 'MEX', '2016-12-13 11:17:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2556', 'Celaya', 'MEX', '2016-12-13 11:17:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2557', 'MazatlÃ¡n', 'MEX', '2016-12-13 11:17:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2558', 'Ensenada', 'MEX', '2016-12-13 11:17:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2559', 'Ahome', 'MEX', '2016-12-13 11:17:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2560', 'Cajeme', 'MEX', '2016-12-13 11:17:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2561', 'Cuernavaca', 'MEX', '2016-12-13 11:17:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2562', 'TonalÃ¡', 'MEX', '2016-12-13 11:17:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2563', 'Valle de Chalco Solidaridad', 'MEX', '2016-12-13 11:17:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2564', 'Nuevo Laredo', 'MEX', '2016-12-13 11:17:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2565', 'Tepic', 'MEX', '2016-12-13 11:17:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2566', 'Tampico', 'MEX', '2016-12-13 11:17:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2567', 'Ixtapaluca', 'MEX', '2016-12-13 11:17:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2568', 'Apodaca', 'MEX', '2016-12-13 11:17:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2569', 'Guasave', 'MEX', '2016-12-13 11:17:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2570', 'GÃ³mez Palacio', 'MEX', '2016-12-13 11:17:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2571', 'Tapachula', 'MEX', '2016-12-13 11:17:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2572', 'NicolÃ¡s Romero', 'MEX', '2016-12-13 11:17:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2573', 'Coatzacoalcos', 'MEX', '2016-12-13 11:17:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2574', 'Uruapan', 'MEX', '2016-12-13 11:17:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2575', 'Victoria', 'MEX', '2016-12-13 11:17:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2576', 'Oaxaca de JuÃ¡rez', 'MEX', '2016-12-13 11:17:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2577', 'Coacalco de BerriozÃ¡bal', 'MEX', '2016-12-13 11:17:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2578', 'Pachuca de Soto', 'MEX', '2016-12-13 11:17:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2579', 'General Escobedo', 'MEX', '2016-12-13 11:17:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2580', 'Salamanca', 'MEX', '2016-12-13 11:17:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2581', 'Santa Catarina', 'MEX', '2016-12-13 11:17:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2582', 'TehuacÃ¡n', 'MEX', '2016-12-13 11:17:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2583', 'Chalco', 'MEX', '2016-12-13 11:17:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2584', 'CÃ¡rdenas', 'MEX', '2016-12-13 11:17:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2585', 'Campeche', 'MEX', '2016-12-13 11:17:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2586', 'La Paz', 'MEX', '2016-12-13 11:17:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2587', 'OthÃ³n P. Blanco (Chetumal)', 'MEX', '2016-12-13 11:17:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2588', 'Texcoco', 'MEX', '2016-12-13 11:17:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2589', 'La Paz', 'MEX', '2016-12-13 11:17:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2590', 'Metepec', 'MEX', '2016-12-13 11:17:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2591', 'Monclova', 'MEX', '2016-12-13 11:17:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2592', 'Huixquilucan', 'MEX', '2016-12-13 11:17:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2593', 'Chilpancingo de los Bravo', 'MEX', '2016-12-13 11:17:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2594', 'Puerto Vallarta', 'MEX', '2016-12-13 11:17:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2595', 'Fresnillo', 'MEX', '2016-12-13 11:17:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2596', 'Ciudad Madero', 'MEX', '2016-12-13 11:17:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2597', 'Soledad de Graciano SÃ¡nchez', 'MEX', '2016-12-13 11:17:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2598', 'San Juan del RÃ­o', 'MEX', '2016-12-13 11:17:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2599', 'San Felipe del Progreso', 'MEX', '2016-12-13 11:17:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2600', 'CÃ³rdoba', 'MEX', '2016-12-13 11:17:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2601', 'TecÃ¡mac', 'MEX', '2016-12-13 11:17:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2602', 'Ocosingo', 'MEX', '2016-12-13 11:17:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2603', 'Carmen', 'MEX', '2016-12-13 11:17:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2604', 'LÃ¡zaro CÃ¡rdenas', 'MEX', '2016-12-13 11:17:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2605', 'Jiutepec', 'MEX', '2016-12-13 11:17:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2606', 'Papantla', 'MEX', '2016-12-13 11:17:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2607', 'Comalcalco', 'MEX', '2016-12-13 11:17:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2608', 'Zamora', 'MEX', '2016-12-13 11:17:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2609', 'Nogales', 'MEX', '2016-12-13 11:17:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2610', 'Huimanguillo', 'MEX', '2016-12-13 11:17:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2611', 'Cuautla', 'MEX', '2016-12-13 11:17:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2612', 'MinatitlÃ¡n', 'MEX', '2016-12-13 11:17:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2613', 'Poza Rica de Hidalgo', 'MEX', '2016-12-13 11:17:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2614', 'Ciudad Valles', 'MEX', '2016-12-13 11:17:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2615', 'Navolato', 'MEX', '2016-12-13 11:17:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2616', 'San Luis RÃ­o Colorado', 'MEX', '2016-12-13 11:17:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2617', 'PÃ©njamo', 'MEX', '2016-12-13 11:17:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2618', 'San AndrÃ©s Tuxtla', 'MEX', '2016-12-13 11:17:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2619', 'Guanajuato', 'MEX', '2016-12-13 11:17:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2620', 'Navojoa', 'MEX', '2016-12-13 11:17:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2621', 'ZitÃ¡cuaro', 'MEX', '2016-12-13 11:17:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2622', 'Boca del RÃ­o', 'MEX', '2016-12-13 11:17:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2623', 'Allende', 'MEX', '2016-12-13 11:17:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2624', 'Silao', 'MEX', '2016-12-13 11:17:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2625', 'Macuspana', 'MEX', '2016-12-13 11:17:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2626', 'San Juan Bautista Tuxtepec', 'MEX', '2016-12-13 11:17:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2627', 'San CristÃ³bal de las Casas', 'MEX', '2016-12-13 11:17:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2628', 'Valle de Santiago', 'MEX', '2016-12-13 11:17:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2629', 'Guaymas', 'MEX', '2016-12-13 11:17:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2630', 'Colima', 'MEX', '2016-12-13 11:17:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2631', 'Dolores Hidalgo', 'MEX', '2016-12-13 11:17:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2632', 'Lagos de Moreno', 'MEX', '2016-12-13 11:17:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2633', 'Piedras Negras', 'MEX', '2016-12-13 11:17:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2634', 'Altamira', 'MEX', '2016-12-13 11:17:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2635', 'TÃºxpam', 'MEX', '2016-12-13 11:17:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2636', 'San Pedro Garza GarcÃ­a', 'MEX', '2016-12-13 11:17:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2637', 'CuauhtÃ©moc', 'MEX', '2016-12-13 11:17:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2638', 'Manzanillo', 'MEX', '2016-12-13 11:17:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2639', 'Iguala de la Independencia', 'MEX', '2016-12-13 11:17:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2640', 'Zacatecas', 'MEX', '2016-12-13 11:17:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2641', 'Tlajomulco de ZÃºÃ±iga', 'MEX', '2016-12-13 11:17:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2642', 'Tulancingo de Bravo', 'MEX', '2016-12-13 11:17:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2643', 'Zinacantepec', 'MEX', '2016-12-13 11:17:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2644', 'San MartÃ­n Texmelucan', 'MEX', '2016-12-13 11:17:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2645', 'TepatitlÃ¡n de Morelos', 'MEX', '2016-12-13 11:17:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2646', 'MartÃ­nez de la Torre', 'MEX', '2016-12-13 11:17:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2647', 'Orizaba', 'MEX', '2016-12-13 11:17:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2648', 'ApatzingÃ¡n', 'MEX', '2016-12-13 11:17:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2649', 'Atlixco', 'MEX', '2016-12-13 11:17:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2650', 'Delicias', 'MEX', '2016-12-13 11:17:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2651', 'Ixtlahuaca', 'MEX', '2016-12-13 11:17:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2652', 'El Mante', 'MEX', '2016-12-13 11:17:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2653', 'Lerdo', 'MEX', '2016-12-13 11:17:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2654', 'Almoloya de JuÃ¡rez', 'MEX', '2016-12-13 11:17:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2655', 'AcÃ¡mbaro', 'MEX', '2016-12-13 11:17:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2656', 'AcuÃ±a', 'MEX', '2016-12-13 11:17:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2657', 'Guadalupe', 'MEX', '2016-12-13 11:17:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2658', 'Huejutla de Reyes', 'MEX', '2016-12-13 11:17:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2659', 'Hidalgo', 'MEX', '2016-12-13 11:17:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2660', 'Los Cabos', 'MEX', '2016-12-13 11:17:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2661', 'ComitÃ¡n de DomÃ­nguez', 'MEX', '2016-12-13 11:17:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2662', 'CunduacÃ¡n', 'MEX', '2016-12-13 11:17:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2663', 'RÃ­o Bravo', 'MEX', '2016-12-13 11:17:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2664', 'Temapache', 'MEX', '2016-12-13 11:17:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2665', 'Chilapa de Alvarez', 'MEX', '2016-12-13 11:17:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2666', 'Hidalgo del Parral', 'MEX', '2016-12-13 11:17:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2667', 'San Francisco del RincÃ³n', 'MEX', '2016-12-13 11:17:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2668', 'Taxco de AlarcÃ³n', 'MEX', '2016-12-13 11:17:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2669', 'Zumpango', 'MEX', '2016-12-13 11:17:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2670', 'San Pedro Cholula', 'MEX', '2016-12-13 11:17:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2671', 'Lerma', 'MEX', '2016-12-13 11:17:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2672', 'TecomÃ¡n', 'MEX', '2016-12-13 11:17:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2673', 'Las Margaritas', 'MEX', '2016-12-13 11:17:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2674', 'Cosoleacaque', 'MEX', '2016-12-13 11:17:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2675', 'San Luis de la Paz', 'MEX', '2016-12-13 11:17:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2676', 'JosÃ© Azueta', 'MEX', '2016-12-13 11:17:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2677', 'Santiago Ixcuintla', 'MEX', '2016-12-13 11:17:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2678', 'San Felipe', 'MEX', '2016-12-13 11:17:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2679', 'Tejupilco', 'MEX', '2016-12-13 11:17:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2680', 'Tantoyuca', 'MEX', '2016-12-13 11:17:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2681', 'Salvatierra', 'MEX', '2016-12-13 11:17:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2682', 'Tultepec', 'MEX', '2016-12-13 11:17:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2683', 'Temixco', 'MEX', '2016-12-13 11:17:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2684', 'Matamoros', 'MEX', '2016-12-13 11:17:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2685', 'PÃ¡nuco', 'MEX', '2016-12-13 11:17:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2686', 'El Fuerte', 'MEX', '2016-12-13 11:17:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2687', 'Tierra Blanca', 'MEX', '2016-12-13 11:17:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2688', 'Weno', 'FSM', '2016-12-13 11:17:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2689', 'Palikir', 'FSM', '2016-12-13 11:17:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2690', 'Chisinau', 'MDA', '2016-12-13 11:17:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2691', 'Tiraspol', 'MDA', '2016-12-13 11:17:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2692', 'Balti', 'MDA', '2016-12-13 11:17:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2693', 'Bender (TÃ®ghina)', 'MDA', '2016-12-13 11:17:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2694', 'Monte-Carlo', 'MCO', '2016-12-13 11:17:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2695', 'Monaco-Ville', 'MCO', '2016-12-13 11:17:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2696', 'Ulan Bator', 'MNG', '2016-12-13 11:17:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2697', 'Plymouth', 'MSR', '2016-12-13 11:17:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2698', 'Maputo', 'MOZ', '2016-12-13 11:17:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2699', 'Matola', 'MOZ', '2016-12-13 11:17:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2700', 'Beira', 'MOZ', '2016-12-13 11:17:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2701', 'Nampula', 'MOZ', '2016-12-13 11:17:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2702', 'Chimoio', 'MOZ', '2016-12-13 11:17:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2703', 'NaÃ§ala-Porto', 'MOZ', '2016-12-13 11:17:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2704', 'Quelimane', 'MOZ', '2016-12-13 11:17:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2705', 'Mocuba', 'MOZ', '2016-12-13 11:17:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2706', 'Tete', 'MOZ', '2016-12-13 11:17:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2707', 'Xai-Xai', 'MOZ', '2016-12-13 11:17:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2708', 'Gurue', 'MOZ', '2016-12-13 11:17:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2709', 'Maxixe', 'MOZ', '2016-12-13 11:17:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2710', 'Rangoon (Yangon)', 'MMR', '2016-12-13 11:17:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2711', 'Mandalay', 'MMR', '2016-12-13 11:17:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2712', 'Moulmein (Mawlamyine)', 'MMR', '2016-12-13 11:17:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2713', 'Pegu (Bago)', 'MMR', '2016-12-13 11:17:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2714', 'Bassein (Pathein)', 'MMR', '2016-12-13 11:17:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2715', 'Monywa', 'MMR', '2016-12-13 11:17:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2716', 'Sittwe (Akyab)', 'MMR', '2016-12-13 11:17:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2717', 'Taunggyi (Taunggye)', 'MMR', '2016-12-13 11:17:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2718', 'Meikhtila', 'MMR', '2016-12-13 11:17:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2719', 'Mergui (Myeik)', 'MMR', '2016-12-13 11:17:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2720', 'Lashio (Lasho)', 'MMR', '2016-12-13 11:17:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2721', 'Prome (Pyay)', 'MMR', '2016-12-13 11:17:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2722', 'Henzada (Hinthada)', 'MMR', '2016-12-13 11:17:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2723', 'Myingyan', 'MMR', '2016-12-13 11:17:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2724', 'Tavoy (Dawei)', 'MMR', '2016-12-13 11:17:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2725', 'Pagakku (Pakokku)', 'MMR', '2016-12-13 11:17:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2726', 'Windhoek', 'NAM', '2016-12-13 11:17:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2727', 'Yangor', 'NRU', '2016-12-13 11:17:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2728', 'Yaren', 'NRU', '2016-12-13 11:17:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2729', 'Kathmandu', 'NPL', '2016-12-13 11:17:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2730', 'Biratnagar', 'NPL', '2016-12-13 11:17:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2731', 'Pokhara', 'NPL', '2016-12-13 11:17:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2732', 'Lalitapur', 'NPL', '2016-12-13 11:17:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2733', 'Birgunj', 'NPL', '2016-12-13 11:17:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2734', 'Managua', 'NIC', '2016-12-13 11:17:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2735', 'LeÃ³n', 'NIC', '2016-12-13 11:17:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2736', 'Chinandega', 'NIC', '2016-12-13 11:17:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2737', 'Masaya', 'NIC', '2016-12-13 11:17:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2738', 'Niamey', 'NER', '2016-12-13 11:17:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2739', 'Zinder', 'NER', '2016-12-13 11:17:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2740', 'Maradi', 'NER', '2016-12-13 11:17:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2741', 'Lagos', 'NGA', '2016-12-13 11:17:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2742', 'Ibadan', 'NGA', '2016-12-13 11:17:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2743', 'Ogbomosho', 'NGA', '2016-12-13 11:17:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2744', 'Kano', 'NGA', '2016-12-13 11:17:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2745', 'Oshogbo', 'NGA', '2016-12-13 11:17:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2746', 'Ilorin', 'NGA', '2016-12-13 11:17:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2747', 'Abeokuta', 'NGA', '2016-12-13 11:17:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2748', 'Port Harcourt', 'NGA', '2016-12-13 11:17:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2749', 'Zaria', 'NGA', '2016-12-13 11:17:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2750', 'Ilesha', 'NGA', '2016-12-13 11:17:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2751', 'Onitsha', 'NGA', '2016-12-13 11:17:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2752', 'Iwo', 'NGA', '2016-12-13 11:17:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2753', 'Ado-Ekiti', 'NGA', '2016-12-13 11:17:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2754', 'Abuja', 'NGA', '2016-12-13 11:17:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2755', 'Kaduna', 'NGA', '2016-12-13 11:17:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2756', 'Mushin', 'NGA', '2016-12-13 11:17:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2757', 'Maiduguri', 'NGA', '2016-12-13 11:17:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2758', 'Enugu', 'NGA', '2016-12-13 11:17:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2759', 'Ede', 'NGA', '2016-12-13 11:17:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2760', 'Aba', 'NGA', '2016-12-13 11:17:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2761', 'Ife', 'NGA', '2016-12-13 11:17:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2762', 'Ila', 'NGA', '2016-12-13 11:17:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2763', 'Oyo', 'NGA', '2016-12-13 11:17:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2764', 'Ikerre', 'NGA', '2016-12-13 11:17:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2765', 'Benin City', 'NGA', '2016-12-13 11:17:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2766', 'Iseyin', 'NGA', '2016-12-13 11:17:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2767', 'Katsina', 'NGA', '2016-12-13 11:17:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2768', 'Jos', 'NGA', '2016-12-13 11:17:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2769', 'Sokoto', 'NGA', '2016-12-13 11:17:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2770', 'Ilobu', 'NGA', '2016-12-13 11:17:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2771', 'Offa', 'NGA', '2016-12-13 11:17:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2772', 'Ikorodu', 'NGA', '2016-12-13 11:17:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2773', 'Ilawe-Ekiti', 'NGA', '2016-12-13 11:17:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2774', 'Owo', 'NGA', '2016-12-13 11:17:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2775', 'Ikirun', 'NGA', '2016-12-13 11:17:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2776', 'Shaki', 'NGA', '2016-12-13 11:17:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2777', 'Calabar', 'NGA', '2016-12-13 11:17:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2778', 'Ondo', 'NGA', '2016-12-13 11:17:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2779', 'Akure', 'NGA', '2016-12-13 11:17:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2780', 'Gusau', 'NGA', '2016-12-13 11:17:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2781', 'Ijebu-Ode', 'NGA', '2016-12-13 11:17:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2782', 'Effon-Alaiye', 'NGA', '2016-12-13 11:17:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2783', 'Kumo', 'NGA', '2016-12-13 11:17:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2784', 'Shomolu', 'NGA', '2016-12-13 11:17:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2785', 'Oka-Akoko', 'NGA', '2016-12-13 11:17:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2786', 'Ikare', 'NGA', '2016-12-13 11:17:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2787', 'Sapele', 'NGA', '2016-12-13 11:17:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2788', 'Deba Habe', 'NGA', '2016-12-13 11:17:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2789', 'Minna', 'NGA', '2016-12-13 11:17:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2790', 'Warri', 'NGA', '2016-12-13 11:17:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2791', 'Bida', 'NGA', '2016-12-13 11:17:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2792', 'Ikire', 'NGA', '2016-12-13 11:17:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2793', 'Makurdi', 'NGA', '2016-12-13 11:17:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2794', 'Lafia', 'NGA', '2016-12-13 11:17:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2795', 'Inisa', 'NGA', '2016-12-13 11:17:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2796', 'Shagamu', 'NGA', '2016-12-13 11:17:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2797', 'Awka', 'NGA', '2016-12-13 11:17:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2798', 'Gombe', 'NGA', '2016-12-13 11:17:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2799', 'Igboho', 'NGA', '2016-12-13 11:17:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2800', 'Ejigbo', 'NGA', '2016-12-13 11:17:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2801', 'Agege', 'NGA', '2016-12-13 11:17:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2802', 'Ise-Ekiti', 'NGA', '2016-12-13 11:17:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2803', 'Ugep', 'NGA', '2016-12-13 11:17:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2804', 'Epe', 'NGA', '2016-12-13 11:17:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2805', 'Alofi', 'NIU', '2016-12-13 11:17:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2806', 'Kingston', 'NFK', '2016-12-13 11:17:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2807', 'Oslo', 'NOR', '2016-12-13 11:17:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2808', 'Bergen', 'NOR', '2016-12-13 11:17:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2809', 'Trondheim', 'NOR', '2016-12-13 11:17:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2810', 'Stavanger', 'NOR', '2016-12-13 11:17:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2811', 'BÃ¦rum', 'NOR', '2016-12-13 11:17:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2812', 'Abidjan', 'CIV', '2016-12-13 11:17:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2813', 'BouakÃ©', 'CIV', '2016-12-13 11:17:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2814', 'Yamoussoukro', 'CIV', '2016-12-13 11:17:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2815', 'Daloa', 'CIV', '2016-12-13 11:17:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2816', 'Korhogo', 'CIV', '2016-12-13 11:17:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2817', 'al-Sib', 'OMN', '2016-12-13 11:17:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2818', 'Salala', 'OMN', '2016-12-13 11:17:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2819', 'Bawshar', 'OMN', '2016-12-13 11:17:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2820', 'Suhar', 'OMN', '2016-12-13 11:17:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2821', 'Masqat', 'OMN', '2016-12-13 11:17:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2822', 'Karachi', 'PAK', '2016-12-13 11:17:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2823', 'Lahore', 'PAK', '2016-12-13 11:17:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2824', 'Faisalabad', 'PAK', '2016-12-13 11:17:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2825', 'Rawalpindi', 'PAK', '2016-12-13 11:17:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2826', 'Multan', 'PAK', '2016-12-13 11:17:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2827', 'Hyderabad', 'PAK', '2016-12-13 11:17:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2828', 'Gujranwala', 'PAK', '2016-12-13 11:17:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2829', 'Peshawar', 'PAK', '2016-12-13 11:17:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2830', 'Quetta', 'PAK', '2016-12-13 11:17:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2831', 'Islamabad', 'PAK', '2016-12-13 11:17:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2832', 'Sargodha', 'PAK', '2016-12-13 11:17:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2833', 'Sialkot', 'PAK', '2016-12-13 11:17:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2834', 'Bahawalpur', 'PAK', '2016-12-13 11:17:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2835', 'Sukkur', 'PAK', '2016-12-13 11:17:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2836', 'Jhang', 'PAK', '2016-12-13 11:17:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2837', 'Sheikhupura', 'PAK', '2016-12-13 11:17:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2838', 'Larkana', 'PAK', '2016-12-13 11:17:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2839', 'Gujrat', 'PAK', '2016-12-13 11:17:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2840', 'Mardan', 'PAK', '2016-12-13 11:17:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2841', 'Kasur', 'PAK', '2016-12-13 11:17:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2842', 'Rahim Yar Khan', 'PAK', '2016-12-13 11:17:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2843', 'Sahiwal', 'PAK', '2016-12-13 11:17:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2844', 'Okara', 'PAK', '2016-12-13 11:17:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2845', 'Wah', 'PAK', '2016-12-13 11:17:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2846', 'Dera Ghazi Khan', 'PAK', '2016-12-13 11:17:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2847', 'Mirpur Khas', 'PAK', '2016-12-13 11:17:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2848', 'Nawabshah', 'PAK', '2016-12-13 11:17:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2849', 'Mingora', 'PAK', '2016-12-13 11:17:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2850', 'Chiniot', 'PAK', '2016-12-13 11:17:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2851', 'Kamoke', 'PAK', '2016-12-13 11:17:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2852', 'Mandi Burewala', 'PAK', '2016-12-13 11:17:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2853', 'Jhelum', 'PAK', '2016-12-13 11:17:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2854', 'Sadiqabad', 'PAK', '2016-12-13 11:17:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2855', 'Jacobabad', 'PAK', '2016-12-13 11:17:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2856', 'Shikarpur', 'PAK', '2016-12-13 11:17:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2857', 'Khanewal', 'PAK', '2016-12-13 11:17:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2858', 'Hafizabad', 'PAK', '2016-12-13 11:17:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2859', 'Kohat', 'PAK', '2016-12-13 11:17:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2860', 'Muzaffargarh', 'PAK', '2016-12-13 11:17:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2861', 'Khanpur', 'PAK', '2016-12-13 11:17:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2862', 'Gojra', 'PAK', '2016-12-13 11:17:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2863', 'Bahawalnagar', 'PAK', '2016-12-13 11:17:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2864', 'Muridke', 'PAK', '2016-12-13 11:17:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2865', 'Pak Pattan', 'PAK', '2016-12-13 11:17:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2866', 'Abottabad', 'PAK', '2016-12-13 11:17:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2867', 'Tando Adam', 'PAK', '2016-12-13 11:17:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2868', 'Jaranwala', 'PAK', '2016-12-13 11:17:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2869', 'Khairpur', 'PAK', '2016-12-13 11:17:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2870', 'Chishtian Mandi', 'PAK', '2016-12-13 11:17:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2871', 'Daska', 'PAK', '2016-12-13 11:17:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2872', 'Dadu', 'PAK', '2016-12-13 11:17:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2873', 'Mandi Bahauddin', 'PAK', '2016-12-13 11:17:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2874', 'Ahmadpur East', 'PAK', '2016-12-13 11:17:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2875', 'Kamalia', 'PAK', '2016-12-13 11:17:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2876', 'Khuzdar', 'PAK', '2016-12-13 11:17:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2877', 'Vihari', 'PAK', '2016-12-13 11:17:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2878', 'Dera Ismail Khan', 'PAK', '2016-12-13 11:17:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2879', 'Wazirabad', 'PAK', '2016-12-13 11:17:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2880', 'Nowshera', 'PAK', '2016-12-13 11:17:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2881', 'Koror', 'PLW', '2016-12-13 11:17:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2882', 'Ciudad de PanamÃ¡', 'PAN', '2016-12-13 11:17:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2883', 'San Miguelito', 'PAN', '2016-12-13 11:17:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2884', 'Port Moresby', 'PNG', '2016-12-13 11:17:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2885', 'AsunciÃ³n', 'PRY', '2016-12-13 11:17:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2886', 'Ciudad del Este', 'PRY', '2016-12-13 11:17:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2887', 'San Lorenzo', 'PRY', '2016-12-13 11:17:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2888', 'LambarÃ©', 'PRY', '2016-12-13 11:17:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2889', 'Fernando de la Mora', 'PRY', '2016-12-13 11:17:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2890', 'Lima', 'PER', '2016-12-13 11:17:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2891', 'Arequipa', 'PER', '2016-12-13 11:17:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2892', 'Trujillo', 'PER', '2016-12-13 11:17:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2893', 'Chiclayo', 'PER', '2016-12-13 11:17:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2894', 'Callao', 'PER', '2016-12-13 11:17:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2895', 'Iquitos', 'PER', '2016-12-13 11:17:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2896', 'Chimbote', 'PER', '2016-12-13 11:17:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2897', 'Huancayo', 'PER', '2016-12-13 11:17:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2898', 'Piura', 'PER', '2016-12-13 11:17:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2899', 'Cusco', 'PER', '2016-12-13 11:17:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2900', 'Pucallpa', 'PER', '2016-12-13 11:17:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2901', 'Tacna', 'PER', '2016-12-13 11:17:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2902', 'Ica', 'PER', '2016-12-13 11:17:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2903', 'Sullana', 'PER', '2016-12-13 11:17:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2904', 'Juliaca', 'PER', '2016-12-13 11:17:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2905', 'HuÃ¡nuco', 'PER', '2016-12-13 11:17:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2906', 'Ayacucho', 'PER', '2016-12-13 11:17:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2907', 'Chincha Alta', 'PER', '2016-12-13 11:17:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2908', 'Cajamarca', 'PER', '2016-12-13 11:17:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2909', 'Puno', 'PER', '2016-12-13 11:17:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2910', 'Ventanilla', 'PER', '2016-12-13 11:17:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2911', 'Castilla', 'PER', '2016-12-13 11:17:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2912', 'Adamstown', 'PCN', '2016-12-13 11:17:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2913', 'Garapan', 'MNP', '2016-12-13 11:17:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2914', 'Lisboa', 'PRT', '2016-12-13 11:17:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2915', 'Porto', 'PRT', '2016-12-13 11:17:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2916', 'Amadora', 'PRT', '2016-12-13 11:17:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2917', 'CoÃ­mbra', 'PRT', '2016-12-13 11:17:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2918', 'Braga', 'PRT', '2016-12-13 11:17:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2919', 'San Juan', 'PRI', '2016-12-13 11:17:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2920', 'BayamÃ³n', 'PRI', '2016-12-13 11:17:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2921', 'Ponce', 'PRI', '2016-12-13 11:17:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2922', 'Carolina', 'PRI', '2016-12-13 11:17:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2923', 'Caguas', 'PRI', '2016-12-13 11:17:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2924', 'Arecibo', 'PRI', '2016-12-13 11:17:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2925', 'Guaynabo', 'PRI', '2016-12-13 11:17:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2926', 'MayagÃ¼ez', 'PRI', '2016-12-13 11:17:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2927', 'Toa Baja', 'PRI', '2016-12-13 11:17:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2928', 'Warszawa', 'POL', '2016-12-13 11:17:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2929', 'LÃ³dz', 'POL', '2016-12-13 11:17:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2930', 'KrakÃ³w', 'POL', '2016-12-13 11:17:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2931', 'Wroclaw', 'POL', '2016-12-13 11:17:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2932', 'Poznan', 'POL', '2016-12-13 11:17:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2933', 'Gdansk', 'POL', '2016-12-13 11:17:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2934', 'Szczecin', 'POL', '2016-12-13 11:17:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2935', 'Bydgoszcz', 'POL', '2016-12-13 11:17:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2936', 'Lublin', 'POL', '2016-12-13 11:17:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2937', 'Katowice', 'POL', '2016-12-13 11:17:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2938', 'Bialystok', 'POL', '2016-12-13 11:17:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2939', 'Czestochowa', 'POL', '2016-12-13 11:17:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2940', 'Gdynia', 'POL', '2016-12-13 11:17:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2941', 'Sosnowiec', 'POL', '2016-12-13 11:17:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2942', 'Radom', 'POL', '2016-12-13 11:17:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2943', 'Kielce', 'POL', '2016-12-13 11:17:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2944', 'Gliwice', 'POL', '2016-12-13 11:17:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2945', 'Torun', 'POL', '2016-12-13 11:17:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2946', 'Bytom', 'POL', '2016-12-13 11:17:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2947', 'Zabrze', 'POL', '2016-12-13 11:17:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2948', 'Bielsko-Biala', 'POL', '2016-12-13 11:17:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2949', 'Olsztyn', 'POL', '2016-12-13 11:17:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2950', 'RzeszÃ³w', 'POL', '2016-12-13 11:17:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2951', 'Ruda Slaska', 'POL', '2016-12-13 11:17:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2952', 'Rybnik', 'POL', '2016-12-13 11:17:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2953', 'Walbrzych', 'POL', '2016-12-13 11:17:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2954', 'Tychy', 'POL', '2016-12-13 11:17:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2955', 'Dabrowa GÃ³rnicza', 'POL', '2016-12-13 11:17:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2956', 'Plock', 'POL', '2016-12-13 11:17:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2957', 'Elblag', 'POL', '2016-12-13 11:17:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2958', 'Opole', 'POL', '2016-12-13 11:17:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2959', 'GorzÃ³w Wielkopolski', 'POL', '2016-12-13 11:17:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2960', 'Wloclawek', 'POL', '2016-12-13 11:17:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2961', 'ChorzÃ³w', 'POL', '2016-12-13 11:17:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2962', 'TarnÃ³w', 'POL', '2016-12-13 11:17:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2963', 'Zielona GÃ³ra', 'POL', '2016-12-13 11:17:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2964', 'Koszalin', 'POL', '2016-12-13 11:17:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2965', 'Legnica', 'POL', '2016-12-13 11:17:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2966', 'Kalisz', 'POL', '2016-12-13 11:17:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2967', 'Grudziadz', 'POL', '2016-12-13 11:17:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2968', 'Slupsk', 'POL', '2016-12-13 11:17:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2969', 'Jastrzebie-ZdrÃ³j', 'POL', '2016-12-13 11:17:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2970', 'Jaworzno', 'POL', '2016-12-13 11:17:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2971', 'Jelenia GÃ³ra', 'POL', '2016-12-13 11:17:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2972', 'Malabo', 'GNQ', '2016-12-13 11:17:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2973', 'Doha', 'QAT', '2016-12-13 11:17:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2974', 'Paris', 'FRA', '2016-12-13 11:17:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2975', 'Marseille', 'FRA', '2016-12-13 11:17:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2976', 'Lyon', 'FRA', '2016-12-13 11:17:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2977', 'Toulouse', 'FRA', '2016-12-13 11:17:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2978', 'Nice', 'FRA', '2016-12-13 11:17:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2979', 'Nantes', 'FRA', '2016-12-13 11:17:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2980', 'Strasbourg', 'FRA', '2016-12-13 11:17:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2981', 'Montpellier', 'FRA', '2016-12-13 11:17:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2982', 'Bordeaux', 'FRA', '2016-12-13 11:17:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2983', 'Rennes', 'FRA', '2016-12-13 11:17:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2984', 'Le Havre', 'FRA', '2016-12-13 11:17:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2985', 'Reims', 'FRA', '2016-12-13 11:17:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2986', 'Lille', 'FRA', '2016-12-13 11:17:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2987', 'St-Ã‰tienne', 'FRA', '2016-12-13 11:17:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2988', 'Toulon', 'FRA', '2016-12-13 11:17:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2989', 'Grenoble', 'FRA', '2016-12-13 11:17:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2990', 'Angers', 'FRA', '2016-12-13 11:17:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2991', 'Dijon', 'FRA', '2016-12-13 11:17:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2992', 'Brest', 'FRA', '2016-12-13 11:17:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2993', 'Le Mans', 'FRA', '2016-12-13 11:17:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2994', 'Clermont-Ferrand', 'FRA', '2016-12-13 11:17:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2995', 'Amiens', 'FRA', '2016-12-13 11:17:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2996', 'Aix-en-Provence', 'FRA', '2016-12-13 11:17:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2997', 'Limoges', 'FRA', '2016-12-13 11:17:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2998', 'NÃ®mes', 'FRA', '2016-12-13 11:17:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('2999', 'Tours', 'FRA', '2016-12-13 11:17:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3000', 'Villeurbanne', 'FRA', '2016-12-13 11:17:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3001', 'Metz', 'FRA', '2016-12-13 11:17:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3002', 'BesanÃ§on', 'FRA', '2016-12-13 11:17:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3003', 'Caen', 'FRA', '2016-12-13 11:17:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3004', 'OrlÃ©ans', 'FRA', '2016-12-13 11:17:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3005', 'Mulhouse', 'FRA', '2016-12-13 11:17:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3006', 'Rouen', 'FRA', '2016-12-13 11:17:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3007', 'Boulogne-Billancourt', 'FRA', '2016-12-13 11:17:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3008', 'Perpignan', 'FRA', '2016-12-13 11:17:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3009', 'Nancy', 'FRA', '2016-12-13 11:17:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3010', 'Roubaix', 'FRA', '2016-12-13 11:17:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3011', 'Argenteuil', 'FRA', '2016-12-13 11:17:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3012', 'Tourcoing', 'FRA', '2016-12-13 11:17:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3013', 'Montreuil', 'FRA', '2016-12-13 11:17:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3014', 'Cayenne', 'GUF', '2016-12-13 11:17:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3015', 'Faaa', 'PYF', '2016-12-13 11:17:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3016', 'Papeete', 'PYF', '2016-12-13 11:17:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3017', 'Saint-Denis', 'REU', '2016-12-13 11:17:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3018', 'Bucuresti', 'ROM', '2016-12-13 11:17:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3019', 'Iasi', 'ROM', '2016-12-13 11:17:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3020', 'Constanta', 'ROM', '2016-12-13 11:17:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3021', 'Cluj-Napoca', 'ROM', '2016-12-13 11:17:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3022', 'Galati', 'ROM', '2016-12-13 11:17:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3023', 'Timisoara', 'ROM', '2016-12-13 11:17:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3024', 'Brasov', 'ROM', '2016-12-13 11:17:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3025', 'Craiova', 'ROM', '2016-12-13 11:18:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3026', 'Ploiesti', 'ROM', '2016-12-13 11:18:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3027', 'Braila', 'ROM', '2016-12-13 11:18:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3028', 'Oradea', 'ROM', '2016-12-13 11:18:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3029', 'Bacau', 'ROM', '2016-12-13 11:18:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3030', 'Pitesti', 'ROM', '2016-12-13 11:18:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3031', 'Arad', 'ROM', '2016-12-13 11:18:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3032', 'Sibiu', 'ROM', '2016-12-13 11:18:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3033', 'TÃ¢rgu Mures', 'ROM', '2016-12-13 11:18:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3034', 'Baia Mare', 'ROM', '2016-12-13 11:18:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3035', 'Buzau', 'ROM', '2016-12-13 11:18:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3036', 'Satu Mare', 'ROM', '2016-12-13 11:18:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3037', 'Botosani', 'ROM', '2016-12-13 11:18:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3038', 'Piatra Neamt', 'ROM', '2016-12-13 11:18:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3039', 'RÃ¢mnicu VÃ¢lcea', 'ROM', '2016-12-13 11:18:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3040', 'Suceava', 'ROM', '2016-12-13 11:18:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3041', 'Drobeta-Turnu Severin', 'ROM', '2016-12-13 11:18:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3042', 'TÃ¢rgoviste', 'ROM', '2016-12-13 11:18:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3043', 'Focsani', 'ROM', '2016-12-13 11:18:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3044', 'TÃ¢rgu Jiu', 'ROM', '2016-12-13 11:18:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3045', 'Tulcea', 'ROM', '2016-12-13 11:18:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3046', 'Resita', 'ROM', '2016-12-13 11:18:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3047', 'Kigali', 'RWA', '2016-12-13 11:18:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3048', 'Stockholm', 'SWE', '2016-12-13 11:18:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3049', 'Gothenburg [GÃ¶teborg]', 'SWE', '2016-12-13 11:18:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3050', 'MalmÃ¶', 'SWE', '2016-12-13 11:18:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3051', 'Uppsala', 'SWE', '2016-12-13 11:18:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3052', 'LinkÃ¶ping', 'SWE', '2016-12-13 11:18:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3053', 'VÃ¤sterÃ¥s', 'SWE', '2016-12-13 11:18:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3054', 'Ã–rebro', 'SWE', '2016-12-13 11:18:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3055', 'NorrkÃ¶ping', 'SWE', '2016-12-13 11:18:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3056', 'Helsingborg', 'SWE', '2016-12-13 11:18:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3057', 'JÃ¶nkÃ¶ping', 'SWE', '2016-12-13 11:18:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3058', 'UmeÃ¥', 'SWE', '2016-12-13 11:18:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3059', 'Lund', 'SWE', '2016-12-13 11:18:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3060', 'BorÃ¥s', 'SWE', '2016-12-13 11:18:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3061', 'Sundsvall', 'SWE', '2016-12-13 11:18:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3062', 'GÃ¤vle', 'SWE', '2016-12-13 11:18:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3063', 'Jamestown', 'SHN', '2016-12-13 11:18:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3064', 'Basseterre', 'KNA', '2016-12-13 11:18:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3065', 'Castries', 'LCA', '2016-12-13 11:18:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3066', 'Kingstown', 'VCT', '2016-12-13 11:18:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3067', 'Saint-Pierre', 'SPM', '2016-12-13 11:18:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3068', 'Berlin', 'DEU', '2016-12-13 11:18:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3069', 'Hamburg', 'DEU', '2016-12-13 11:18:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3070', 'Munich [MÃ¼nchen]', 'DEU', '2016-12-13 11:18:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3071', 'KÃ¶ln', 'DEU', '2016-12-13 11:18:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3072', 'Frankfurt am Main', 'DEU', '2016-12-13 11:18:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3073', 'Essen', 'DEU', '2016-12-13 11:18:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3074', 'Dortmund', 'DEU', '2016-12-13 11:18:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3075', 'Stuttgart', 'DEU', '2016-12-13 11:18:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3076', 'DÃ¼sseldorf', 'DEU', '2016-12-13 11:18:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3077', 'Bremen', 'DEU', '2016-12-13 11:18:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3078', 'Duisburg', 'DEU', '2016-12-13 11:18:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3079', 'Hannover', 'DEU', '2016-12-13 11:18:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3080', 'Leipzig', 'DEU', '2016-12-13 11:18:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3081', 'NÃ¼rnberg', 'DEU', '2016-12-13 11:18:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3082', 'Dresden', 'DEU', '2016-12-13 11:18:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3083', 'Bochum', 'DEU', '2016-12-13 11:18:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3084', 'Wuppertal', 'DEU', '2016-12-13 11:18:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3085', 'Bielefeld', 'DEU', '2016-12-13 11:18:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3086', 'Mannheim', 'DEU', '2016-12-13 11:18:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3087', 'Bonn', 'DEU', '2016-12-13 11:18:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3088', 'Gelsenkirchen', 'DEU', '2016-12-13 11:18:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3089', 'Karlsruhe', 'DEU', '2016-12-13 11:18:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3090', 'Wiesbaden', 'DEU', '2016-12-13 11:18:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3091', 'MÃ¼nster', 'DEU', '2016-12-13 11:18:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3092', 'MÃ¶nchengladbach', 'DEU', '2016-12-13 11:18:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3093', 'Chemnitz', 'DEU', '2016-12-13 11:18:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3094', 'Augsburg', 'DEU', '2016-12-13 11:18:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3095', 'Halle/Saale', 'DEU', '2016-12-13 11:18:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3096', 'Braunschweig', 'DEU', '2016-12-13 11:18:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3097', 'Aachen', 'DEU', '2016-12-13 11:18:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3098', 'Krefeld', 'DEU', '2016-12-13 11:18:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3099', 'Magdeburg', 'DEU', '2016-12-13 11:18:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3100', 'Kiel', 'DEU', '2016-12-13 11:18:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3101', 'Oberhausen', 'DEU', '2016-12-13 11:18:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3102', 'LÃ¼beck', 'DEU', '2016-12-13 11:18:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3103', 'Hagen', 'DEU', '2016-12-13 11:18:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3104', 'Rostock', 'DEU', '2016-12-13 11:18:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3105', 'Freiburg im Breisgau', 'DEU', '2016-12-13 11:18:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3106', 'Erfurt', 'DEU', '2016-12-13 11:18:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3107', 'Kassel', 'DEU', '2016-12-13 11:18:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3108', 'SaarbrÃ¼cken', 'DEU', '2016-12-13 11:18:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3109', 'Mainz', 'DEU', '2016-12-13 11:18:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3110', 'Hamm', 'DEU', '2016-12-13 11:18:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3111', 'Herne', 'DEU', '2016-12-13 11:18:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3112', 'MÃ¼lheim an der Ruhr', 'DEU', '2016-12-13 11:18:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3113', 'Solingen', 'DEU', '2016-12-13 11:18:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3114', 'OsnabrÃ¼ck', 'DEU', '2016-12-13 11:18:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3115', 'Ludwigshafen am Rhein', 'DEU', '2016-12-13 11:18:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3116', 'Leverkusen', 'DEU', '2016-12-13 11:18:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3117', 'Oldenburg', 'DEU', '2016-12-13 11:18:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3118', 'Neuss', 'DEU', '2016-12-13 11:18:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3119', 'Heidelberg', 'DEU', '2016-12-13 11:18:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3120', 'Darmstadt', 'DEU', '2016-12-13 11:18:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3121', 'Paderborn', 'DEU', '2016-12-13 11:18:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3122', 'Potsdam', 'DEU', '2016-12-13 11:18:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3123', 'WÃ¼rzburg', 'DEU', '2016-12-13 11:18:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3124', 'Regensburg', 'DEU', '2016-12-13 11:18:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3125', 'Recklinghausen', 'DEU', '2016-12-13 11:18:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3126', 'GÃ¶ttingen', 'DEU', '2016-12-13 11:18:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3127', 'Bremerhaven', 'DEU', '2016-12-13 11:18:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3128', 'Wolfsburg', 'DEU', '2016-12-13 11:18:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3129', 'Bottrop', 'DEU', '2016-12-13 11:18:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3130', 'Remscheid', 'DEU', '2016-12-13 11:18:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3131', 'Heilbronn', 'DEU', '2016-12-13 11:18:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3132', 'Pforzheim', 'DEU', '2016-12-13 11:18:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3133', 'Offenbach am Main', 'DEU', '2016-12-13 11:18:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3134', 'Ulm', 'DEU', '2016-12-13 11:18:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3135', 'Ingolstadt', 'DEU', '2016-12-13 11:18:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3136', 'Gera', 'DEU', '2016-12-13 11:18:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3137', 'Salzgitter', 'DEU', '2016-12-13 11:18:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3138', 'Cottbus', 'DEU', '2016-12-13 11:18:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3139', 'Reutlingen', 'DEU', '2016-12-13 11:18:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3140', 'FÃ¼rth', 'DEU', '2016-12-13 11:18:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3141', 'Siegen', 'DEU', '2016-12-13 11:18:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3142', 'Koblenz', 'DEU', '2016-12-13 11:18:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3143', 'Moers', 'DEU', '2016-12-13 11:18:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3144', 'Bergisch Gladbach', 'DEU', '2016-12-13 11:18:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3145', 'Zwickau', 'DEU', '2016-12-13 11:18:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3146', 'Hildesheim', 'DEU', '2016-12-13 11:18:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3147', 'Witten', 'DEU', '2016-12-13 11:18:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3148', 'Schwerin', 'DEU', '2016-12-13 11:18:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3149', 'Erlangen', 'DEU', '2016-12-13 11:18:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3150', 'Kaiserslautern', 'DEU', '2016-12-13 11:18:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3151', 'Trier', 'DEU', '2016-12-13 11:18:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3152', 'Jena', 'DEU', '2016-12-13 11:18:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3153', 'Iserlohn', 'DEU', '2016-12-13 11:18:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3154', 'GÃ¼tersloh', 'DEU', '2016-12-13 11:18:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3155', 'Marl', 'DEU', '2016-12-13 11:18:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3156', 'LÃ¼nen', 'DEU', '2016-12-13 11:18:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3157', 'DÃ¼ren', 'DEU', '2016-12-13 11:18:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3158', 'Ratingen', 'DEU', '2016-12-13 11:18:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3159', 'Velbert', 'DEU', '2016-12-13 11:18:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3160', 'Esslingen am Neckar', 'DEU', '2016-12-13 11:18:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3161', 'Honiara', 'SLB', '2016-12-13 11:18:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3162', 'Lusaka', 'ZMB', '2016-12-13 11:18:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3163', 'Ndola', 'ZMB', '2016-12-13 11:18:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3164', 'Kitwe', 'ZMB', '2016-12-13 11:18:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3165', 'Kabwe', 'ZMB', '2016-12-13 11:18:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3166', 'Chingola', 'ZMB', '2016-12-13 11:18:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3167', 'Mufulira', 'ZMB', '2016-12-13 11:18:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3168', 'Luanshya', 'ZMB', '2016-12-13 11:18:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3169', 'Apia', 'WSM', '2016-12-13 11:18:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3170', 'Serravalle', 'SMR', '2016-12-13 11:18:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3171', 'San Marino', 'SMR', '2016-12-13 11:18:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3172', 'SÃ£o TomÃ©', 'STP', '2016-12-13 11:18:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3173', 'Riyadh', 'SAU', '2016-12-13 11:18:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3174', 'Jedda', 'SAU', '2016-12-13 11:18:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3175', 'Mekka', 'SAU', '2016-12-13 11:18:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3176', 'Medina', 'SAU', '2016-12-13 11:18:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3177', 'al-Dammam', 'SAU', '2016-12-13 11:18:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3178', 'al-Taif', 'SAU', '2016-12-13 11:18:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3179', 'Tabuk', 'SAU', '2016-12-13 11:18:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3180', 'Burayda', 'SAU', '2016-12-13 11:18:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3181', 'al-Hufuf', 'SAU', '2016-12-13 11:18:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3182', 'al-Mubarraz', 'SAU', '2016-12-13 11:18:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3183', 'Khamis Mushayt', 'SAU', '2016-12-13 11:18:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3184', 'Hail', 'SAU', '2016-12-13 11:18:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3185', 'al-Kharj', 'SAU', '2016-12-13 11:18:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3186', 'al-Khubar', 'SAU', '2016-12-13 11:18:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3187', 'Jubayl', 'SAU', '2016-12-13 11:18:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3188', 'Hafar al-Batin', 'SAU', '2016-12-13 11:18:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3189', 'al-Tuqba', 'SAU', '2016-12-13 11:18:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3190', 'Yanbu', 'SAU', '2016-12-13 11:18:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3191', 'Abha', 'SAU', '2016-12-13 11:18:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3192', 'AraÂ´ar', 'SAU', '2016-12-13 11:18:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3193', 'al-Qatif', 'SAU', '2016-12-13 11:18:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3194', 'al-Hawiya', 'SAU', '2016-12-13 11:18:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3195', 'Unayza', 'SAU', '2016-12-13 11:18:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3196', 'Najran', 'SAU', '2016-12-13 11:18:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3197', 'Pikine', 'SEN', '2016-12-13 11:18:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3198', 'Dakar', 'SEN', '2016-12-13 11:18:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3199', 'ThiÃ¨s', 'SEN', '2016-12-13 11:18:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3200', 'Kaolack', 'SEN', '2016-12-13 11:18:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3201', 'Ziguinchor', 'SEN', '2016-12-13 11:18:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3202', 'Rufisque', 'SEN', '2016-12-13 11:18:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3203', 'Saint-Louis', 'SEN', '2016-12-13 11:18:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3204', 'Mbour', 'SEN', '2016-12-13 11:18:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3205', 'Diourbel', 'SEN', '2016-12-13 11:18:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3206', 'Victoria', 'SYC', '2016-12-13 11:18:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3207', 'Freetown', 'SLE', '2016-12-13 11:18:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3208', 'Singapore', 'SGP', '2016-12-13 11:18:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3209', 'Bratislava', 'SVK', '2016-12-13 11:18:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3210', 'KoÅ¡ice', 'SVK', '2016-12-13 11:18:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3211', 'PreÅ¡ov', 'SVK', '2016-12-13 11:18:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3212', 'Ljubljana', 'SVN', '2016-12-13 11:18:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3213', 'Maribor', 'SVN', '2016-12-13 11:18:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3214', 'Mogadishu', 'SOM', '2016-12-13 11:18:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3215', 'Hargeysa', 'SOM', '2016-12-13 11:18:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3216', 'Kismaayo', 'SOM', '2016-12-13 11:18:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3217', 'Colombo', 'LKA', '2016-12-13 11:18:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3218', 'Dehiwala', 'LKA', '2016-12-13 11:18:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3219', 'Moratuwa', 'LKA', '2016-12-13 11:18:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3220', 'Jaffna', 'LKA', '2016-12-13 11:18:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3221', 'Kandy', 'LKA', '2016-12-13 11:18:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3222', 'Sri Jayawardenepura Kotte', 'LKA', '2016-12-13 11:18:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3223', 'Negombo', 'LKA', '2016-12-13 11:18:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3224', 'Omdurman', 'SDN', '2016-12-13 11:18:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3225', 'Khartum', 'SDN', '2016-12-13 11:18:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3226', 'Sharq al-Nil', 'SDN', '2016-12-13 11:18:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3227', 'Port Sudan', 'SDN', '2016-12-13 11:18:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3228', 'Kassala', 'SDN', '2016-12-13 11:18:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3229', 'Obeid', 'SDN', '2016-12-13 11:18:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3230', 'Nyala', 'SDN', '2016-12-13 11:18:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3231', 'Wad Madani', 'SDN', '2016-12-13 11:18:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3232', 'al-Qadarif', 'SDN', '2016-12-13 11:18:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3233', 'Kusti', 'SDN', '2016-12-13 11:18:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3234', 'al-Fashir', 'SDN', '2016-12-13 11:18:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3235', 'Juba', 'SDN', '2016-12-13 11:18:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3236', 'Helsinki [Helsingfors]', 'FIN', '2016-12-13 11:18:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3237', 'Espoo', 'FIN', '2016-12-13 11:18:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3238', 'Tampere', 'FIN', '2016-12-13 11:18:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3239', 'Vantaa', 'FIN', '2016-12-13 11:18:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3240', 'Turku [Ã…bo]', 'FIN', '2016-12-13 11:18:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3241', 'Oulu', 'FIN', '2016-12-13 11:18:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3242', 'Lahti', 'FIN', '2016-12-13 11:18:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3243', 'Paramaribo', 'SUR', '2016-12-13 11:18:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3244', 'Mbabane', 'SWZ', '2016-12-13 11:18:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3245', 'ZÃ¼rich', 'CHE', '2016-12-13 11:18:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3246', 'Geneve', 'CHE', '2016-12-13 11:18:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3247', 'Basel', 'CHE', '2016-12-13 11:18:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3248', 'Bern', 'CHE', '2016-12-13 11:18:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3249', 'Lausanne', 'CHE', '2016-12-13 11:18:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3250', 'Damascus', 'SYR', '2016-12-13 11:18:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3251', 'Aleppo', 'SYR', '2016-12-13 11:18:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3252', 'Hims', 'SYR', '2016-12-13 11:18:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3253', 'Hama', 'SYR', '2016-12-13 11:18:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3254', 'Latakia', 'SYR', '2016-12-13 11:18:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3255', 'al-Qamishliya', 'SYR', '2016-12-13 11:18:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3256', 'Dayr al-Zawr', 'SYR', '2016-12-13 11:18:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3257', 'Jaramana', 'SYR', '2016-12-13 11:18:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3258', 'Duma', 'SYR', '2016-12-13 11:18:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3259', 'al-Raqqa', 'SYR', '2016-12-13 11:18:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3260', 'Idlib', 'SYR', '2016-12-13 11:18:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3261', 'Dushanbe', 'TJK', '2016-12-13 11:18:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3262', 'Khujand', 'TJK', '2016-12-13 11:18:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3263', 'Taipei', 'TWN', '2016-12-13 11:18:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3264', 'Kaohsiung', 'TWN', '2016-12-13 11:18:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3265', 'Taichung', 'TWN', '2016-12-13 11:18:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3266', 'Tainan', 'TWN', '2016-12-13 11:18:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3267', 'Panchiao', 'TWN', '2016-12-13 11:18:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3268', 'Chungho', 'TWN', '2016-12-13 11:18:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3269', 'Keelung (Chilung)', 'TWN', '2016-12-13 11:18:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3270', 'Sanchung', 'TWN', '2016-12-13 11:18:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3271', 'Hsinchuang', 'TWN', '2016-12-13 11:18:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3272', 'Hsinchu', 'TWN', '2016-12-13 11:18:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3273', 'Chungli', 'TWN', '2016-12-13 11:18:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3274', 'Fengshan', 'TWN', '2016-12-13 11:18:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3275', 'Taoyuan', 'TWN', '2016-12-13 11:18:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3276', 'Chiayi', 'TWN', '2016-12-13 11:18:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3277', 'Hsintien', 'TWN', '2016-12-13 11:18:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3278', 'Changhwa', 'TWN', '2016-12-13 11:18:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3279', 'Yungho', 'TWN', '2016-12-13 11:18:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3280', 'Tucheng', 'TWN', '2016-12-13 11:18:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3281', 'Pingtung', 'TWN', '2016-12-13 11:18:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3282', 'Yungkang', 'TWN', '2016-12-13 11:18:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3283', 'Pingchen', 'TWN', '2016-12-13 11:18:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3284', 'Tali', 'TWN', '2016-12-13 11:18:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3285', 'Taiping', 'TWN', '2016-12-13 11:18:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3286', 'Pate', 'TWN', '2016-12-13 11:18:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3287', 'Fengyuan', 'TWN', '2016-12-13 11:18:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3288', 'Luchou', 'TWN', '2016-12-13 11:18:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3289', 'Hsichuh', 'TWN', '2016-12-13 11:18:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3290', 'Shulin', 'TWN', '2016-12-13 11:18:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3291', 'Yuanlin', 'TWN', '2016-12-13 11:18:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3292', 'Yangmei', 'TWN', '2016-12-13 11:18:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3293', 'Taliao', 'TWN', '2016-12-13 11:18:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3294', 'Kueishan', 'TWN', '2016-12-13 11:18:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3295', 'Tanshui', 'TWN', '2016-12-13 11:18:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3296', 'Taitung', 'TWN', '2016-12-13 11:18:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3297', 'Hualien', 'TWN', '2016-12-13 11:18:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3298', 'Nantou', 'TWN', '2016-12-13 11:18:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3299', 'Lungtan', 'TWN', '2016-12-13 11:18:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3300', 'Touliu', 'TWN', '2016-12-13 11:18:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3301', 'Tsaotun', 'TWN', '2016-12-13 11:18:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3302', 'Kangshan', 'TWN', '2016-12-13 11:18:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3303', 'Ilan', 'TWN', '2016-12-13 11:18:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3304', 'Miaoli', 'TWN', '2016-12-13 11:18:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3305', 'Dar es Salaam', 'TZA', '2016-12-13 11:18:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3306', 'Dodoma', 'TZA', '2016-12-13 11:18:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3307', 'Mwanza', 'TZA', '2016-12-13 11:18:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3308', 'Zanzibar', 'TZA', '2016-12-13 11:18:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3309', 'Tanga', 'TZA', '2016-12-13 11:18:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3310', 'Mbeya', 'TZA', '2016-12-13 11:18:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3311', 'Morogoro', 'TZA', '2016-12-13 11:18:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3312', 'Arusha', 'TZA', '2016-12-13 11:18:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3313', 'Moshi', 'TZA', '2016-12-13 11:18:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3314', 'Tabora', 'TZA', '2016-12-13 11:18:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3315', 'KÃ¸benhavn', 'DNK', '2016-12-13 11:18:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3316', 'Ã…rhus', 'DNK', '2016-12-13 11:18:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3317', 'Odense', 'DNK', '2016-12-13 11:18:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3318', 'Aalborg', 'DNK', '2016-12-13 11:18:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3319', 'Frederiksberg', 'DNK', '2016-12-13 11:18:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3320', 'Bangkok', 'THA', '2016-12-13 11:18:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3321', 'Nonthaburi', 'THA', '2016-12-13 11:18:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3322', 'Nakhon Ratchasima', 'THA', '2016-12-13 11:18:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3323', 'Chiang Mai', 'THA', '2016-12-13 11:18:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3324', 'Udon Thani', 'THA', '2016-12-13 11:18:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3325', 'Hat Yai', 'THA', '2016-12-13 11:18:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3326', 'Khon Kaen', 'THA', '2016-12-13 11:18:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3327', 'Pak Kret', 'THA', '2016-12-13 11:18:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3328', 'Nakhon Sawan', 'THA', '2016-12-13 11:18:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3329', 'Ubon Ratchathani', 'THA', '2016-12-13 11:18:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3330', 'Songkhla', 'THA', '2016-12-13 11:18:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3331', 'Nakhon Pathom', 'THA', '2016-12-13 11:18:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3332', 'LomÃ©', 'TGO', '2016-12-13 11:18:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3333', 'Fakaofo', 'TKL', '2016-12-13 11:18:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3334', 'NukuÂ´alofa', 'TON', '2016-12-13 11:18:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3335', 'Chaguanas', 'TTO', '2016-12-13 11:18:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3336', 'Port-of-Spain', 'TTO', '2016-12-13 11:18:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3337', 'NÂ´DjamÃ©na', 'TCD', '2016-12-13 11:18:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3338', 'Moundou', 'TCD', '2016-12-13 11:18:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3339', 'Praha', 'CZE', '2016-12-13 11:18:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3340', 'Brno', 'CZE', '2016-12-13 11:18:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3341', 'Ostrava', 'CZE', '2016-12-13 11:18:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3342', 'Plzen', 'CZE', '2016-12-13 11:18:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3343', 'Olomouc', 'CZE', '2016-12-13 11:18:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3344', 'Liberec', 'CZE', '2016-12-13 11:18:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3345', 'CeskÃ© Budejovice', 'CZE', '2016-12-13 11:18:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3346', 'Hradec KrÃ¡lovÃ©', 'CZE', '2016-12-13 11:18:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3347', 'ÃšstÃ­ nad Labem', 'CZE', '2016-12-13 11:18:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3348', 'Pardubice', 'CZE', '2016-12-13 11:18:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3349', 'Tunis', 'TUN', '2016-12-13 11:18:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3350', 'Sfax', 'TUN', '2016-12-13 11:18:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3351', 'Ariana', 'TUN', '2016-12-13 11:18:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3352', 'Ettadhamen', 'TUN', '2016-12-13 11:18:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3353', 'Sousse', 'TUN', '2016-12-13 11:18:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3354', 'Kairouan', 'TUN', '2016-12-13 11:18:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3355', 'Biserta', 'TUN', '2016-12-13 11:18:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3356', 'GabÃ¨s', 'TUN', '2016-12-13 11:18:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3357', 'Istanbul', 'TUR', '2016-12-13 11:18:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3358', 'Ankara', 'TUR', '2016-12-13 11:18:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3359', 'Izmir', 'TUR', '2016-12-13 11:18:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3360', 'Adana', 'TUR', '2016-12-13 11:18:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3361', 'Bursa', 'TUR', '2016-12-13 11:18:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3362', 'Gaziantep', 'TUR', '2016-12-13 11:18:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3363', 'Konya', 'TUR', '2016-12-13 11:18:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3364', 'Mersin (IÃ§el)', 'TUR', '2016-12-13 11:18:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3365', 'Antalya', 'TUR', '2016-12-13 11:18:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3366', 'Diyarbakir', 'TUR', '2016-12-13 11:18:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3367', 'Kayseri', 'TUR', '2016-12-13 11:18:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3368', 'Eskisehir', 'TUR', '2016-12-13 11:18:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3369', 'Sanliurfa', 'TUR', '2016-12-13 11:18:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3370', 'Samsun', 'TUR', '2016-12-13 11:18:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3371', 'Malatya', 'TUR', '2016-12-13 11:18:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3372', 'Gebze', 'TUR', '2016-12-13 11:18:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3373', 'Denizli', 'TUR', '2016-12-13 11:18:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3374', 'Sivas', 'TUR', '2016-12-13 11:18:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3375', 'Erzurum', 'TUR', '2016-12-13 11:18:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3376', 'Tarsus', 'TUR', '2016-12-13 11:18:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3377', 'Kahramanmaras', 'TUR', '2016-12-13 11:18:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3378', 'ElÃ¢zig', 'TUR', '2016-12-13 11:18:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3379', 'Van', 'TUR', '2016-12-13 11:18:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3380', 'Sultanbeyli', 'TUR', '2016-12-13 11:18:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3381', 'Izmit (Kocaeli)', 'TUR', '2016-12-13 11:18:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3382', 'Manisa', 'TUR', '2016-12-13 11:18:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3383', 'Batman', 'TUR', '2016-12-13 11:18:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3384', 'Balikesir', 'TUR', '2016-12-13 11:18:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3385', 'Sakarya (Adapazari)', 'TUR', '2016-12-13 11:18:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3386', 'Iskenderun', 'TUR', '2016-12-13 11:18:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3387', 'Osmaniye', 'TUR', '2016-12-13 11:18:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3388', 'Ã‡orum', 'TUR', '2016-12-13 11:18:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3389', 'KÃ¼tahya', 'TUR', '2016-12-13 11:18:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3390', 'Hatay (Antakya)', 'TUR', '2016-12-13 11:18:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3391', 'Kirikkale', 'TUR', '2016-12-13 11:18:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3392', 'Adiyaman', 'TUR', '2016-12-13 11:18:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3393', 'Trabzon', 'TUR', '2016-12-13 11:18:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3394', 'Ordu', 'TUR', '2016-12-13 11:18:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3395', 'Aydin', 'TUR', '2016-12-13 11:18:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3396', 'Usak', 'TUR', '2016-12-13 11:18:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3397', 'Edirne', 'TUR', '2016-12-13 11:18:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3398', 'Ã‡orlu', 'TUR', '2016-12-13 11:18:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3399', 'Isparta', 'TUR', '2016-12-13 11:18:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3400', 'KarabÃ¼k', 'TUR', '2016-12-13 11:18:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3401', 'Kilis', 'TUR', '2016-12-13 11:18:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3402', 'Alanya', 'TUR', '2016-12-13 11:18:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3403', 'Kiziltepe', 'TUR', '2016-12-13 11:18:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3404', 'Zonguldak', 'TUR', '2016-12-13 11:18:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3405', 'Siirt', 'TUR', '2016-12-13 11:18:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3406', 'Viransehir', 'TUR', '2016-12-13 11:18:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3407', 'Tekirdag', 'TUR', '2016-12-13 11:18:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3408', 'Karaman', 'TUR', '2016-12-13 11:18:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3409', 'Afyon', 'TUR', '2016-12-13 11:18:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3410', 'Aksaray', 'TUR', '2016-12-13 11:18:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3411', 'Ceyhan', 'TUR', '2016-12-13 11:18:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3412', 'Erzincan', 'TUR', '2016-12-13 11:18:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3413', 'Bismil', 'TUR', '2016-12-13 11:18:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3414', 'Nazilli', 'TUR', '2016-12-13 11:18:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3415', 'Tokat', 'TUR', '2016-12-13 11:18:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3416', 'Kars', 'TUR', '2016-12-13 11:18:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3417', 'InegÃ¶l', 'TUR', '2016-12-13 11:18:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3418', 'Bandirma', 'TUR', '2016-12-13 11:18:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3419', 'Ashgabat', 'TKM', '2016-12-13 11:18:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3420', 'ChÃ¤rjew', 'TKM', '2016-12-13 11:18:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3421', 'Dashhowuz', 'TKM', '2016-12-13 11:18:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3422', 'Mary', 'TKM', '2016-12-13 11:18:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3423', 'Cockburn Town', 'TCA', '2016-12-13 11:18:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3424', 'Funafuti', 'TUV', '2016-12-13 11:18:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3425', 'Kampala', 'UGA', '2016-12-13 11:18:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3426', 'Kyiv', 'UKR', '2016-12-13 11:18:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3427', 'Harkova [Harkiv]', 'UKR', '2016-12-13 11:18:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3428', 'Dnipropetrovsk', 'UKR', '2016-12-13 11:18:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3429', 'Donetsk', 'UKR', '2016-12-13 11:18:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3430', 'Odesa', 'UKR', '2016-12-13 11:18:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3431', 'Zaporizzja', 'UKR', '2016-12-13 11:18:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3432', 'Lviv', 'UKR', '2016-12-13 11:18:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3433', 'Kryvyi Rig', 'UKR', '2016-12-13 11:18:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3434', 'Mykolajiv', 'UKR', '2016-12-13 11:18:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3435', 'Mariupol', 'UKR', '2016-12-13 11:18:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3436', 'Lugansk', 'UKR', '2016-12-13 11:18:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3437', 'Vinnytsja', 'UKR', '2016-12-13 11:18:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3438', 'Makijivka', 'UKR', '2016-12-13 11:18:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3439', 'Herson', 'UKR', '2016-12-13 11:18:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3440', 'Sevastopol', 'UKR', '2016-12-13 11:18:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3441', 'Simferopol', 'UKR', '2016-12-13 11:18:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3442', 'Pultava [Poltava]', 'UKR', '2016-12-13 11:18:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3443', 'TÅ¡ernigiv', 'UKR', '2016-12-13 11:18:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3444', 'TÅ¡erkasy', 'UKR', '2016-12-13 11:18:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3445', 'Gorlivka', 'UKR', '2016-12-13 11:18:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3446', 'Zytomyr', 'UKR', '2016-12-13 11:18:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3447', 'Sumy', 'UKR', '2016-12-13 11:18:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3448', 'Dniprodzerzynsk', 'UKR', '2016-12-13 11:18:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3449', 'Kirovograd', 'UKR', '2016-12-13 11:18:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3450', 'Hmelnytskyi', 'UKR', '2016-12-13 11:18:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3451', 'TÅ¡ernivtsi', 'UKR', '2016-12-13 11:18:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3452', 'Rivne', 'UKR', '2016-12-13 11:18:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3453', 'KrementÅ¡uk', 'UKR', '2016-12-13 11:18:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3454', 'Ivano-Frankivsk', 'UKR', '2016-12-13 11:18:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3455', 'Ternopil', 'UKR', '2016-12-13 11:18:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3456', 'Lutsk', 'UKR', '2016-12-13 11:18:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3457', 'Bila Tserkva', 'UKR', '2016-12-13 11:18:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3458', 'Kramatorsk', 'UKR', '2016-12-13 11:18:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3459', 'Melitopol', 'UKR', '2016-12-13 11:18:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3460', 'KertÅ¡', 'UKR', '2016-12-13 11:18:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3461', 'Nikopol', 'UKR', '2016-12-13 11:18:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3462', 'Berdjansk', 'UKR', '2016-12-13 11:18:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3463', 'Pavlograd', 'UKR', '2016-12-13 11:18:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3464', 'Sjeverodonetsk', 'UKR', '2016-12-13 11:18:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3465', 'Slovjansk', 'UKR', '2016-12-13 11:18:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3466', 'Uzgorod', 'UKR', '2016-12-13 11:18:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3467', 'AltÅ¡evsk', 'UKR', '2016-12-13 11:18:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3468', 'LysytÅ¡ansk', 'UKR', '2016-12-13 11:18:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3469', 'Jevpatorija', 'UKR', '2016-12-13 11:18:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3470', 'Kamjanets-Podilskyi', 'UKR', '2016-12-13 11:18:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3471', 'Jenakijeve', 'UKR', '2016-12-13 11:18:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3472', 'Krasnyi LutÅ¡', 'UKR', '2016-12-13 11:18:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3473', 'Stahanov', 'UKR', '2016-12-13 11:18:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3474', 'Oleksandrija', 'UKR', '2016-12-13 11:18:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3475', 'Konotop', 'UKR', '2016-12-13 11:18:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3476', 'Kostjantynivka', 'UKR', '2016-12-13 11:18:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3477', 'BerdytÅ¡iv', 'UKR', '2016-12-13 11:18:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3478', 'Izmajil', 'UKR', '2016-12-13 11:18:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3479', 'Å ostka', 'UKR', '2016-12-13 11:18:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3480', 'Uman', 'UKR', '2016-12-13 11:18:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3481', 'Brovary', 'UKR', '2016-12-13 11:18:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3482', 'MukatÅ¡eve', 'UKR', '2016-12-13 11:18:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3483', 'Budapest', 'HUN', '2016-12-13 11:18:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3484', 'Debrecen', 'HUN', '2016-12-13 11:18:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3485', 'Miskolc', 'HUN', '2016-12-13 11:18:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3486', 'Szeged', 'HUN', '2016-12-13 11:18:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3487', 'PÃ©cs', 'HUN', '2016-12-13 11:18:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3488', 'GyÃ¶r', 'HUN', '2016-12-13 11:18:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3489', 'NyiregyhÃ¡za', 'HUN', '2016-12-13 11:18:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3490', 'KecskemÃ©t', 'HUN', '2016-12-13 11:18:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3491', 'SzÃ©kesfehÃ©rvÃ¡r', 'HUN', '2016-12-13 11:18:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3492', 'Montevideo', 'URY', '2016-12-13 11:18:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3493', 'NoumÃ©a', 'NCL', '2016-12-13 11:18:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3494', 'Auckland', 'NZL', '2016-12-13 11:18:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3495', 'Christchurch', 'NZL', '2016-12-13 11:18:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3496', 'Manukau', 'NZL', '2016-12-13 11:18:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3497', 'North Shore', 'NZL', '2016-12-13 11:18:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3498', 'Waitakere', 'NZL', '2016-12-13 11:18:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3499', 'Wellington', 'NZL', '2016-12-13 11:18:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3500', 'Dunedin', 'NZL', '2016-12-13 11:18:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3501', 'Hamilton', 'NZL', '2016-12-13 11:18:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3502', 'Lower Hutt', 'NZL', '2016-12-13 11:18:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3503', 'Toskent', 'UZB', '2016-12-13 11:18:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3504', 'Namangan', 'UZB', '2016-12-13 11:18:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3505', 'Samarkand', 'UZB', '2016-12-13 11:18:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3506', 'Andijon', 'UZB', '2016-12-13 11:18:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3507', 'Buhoro', 'UZB', '2016-12-13 11:18:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3508', 'Karsi', 'UZB', '2016-12-13 11:18:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3509', 'Nukus', 'UZB', '2016-12-13 11:18:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3510', 'KÃ¼kon', 'UZB', '2016-12-13 11:18:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3511', 'Fargona', 'UZB', '2016-12-13 11:18:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3512', 'Circik', 'UZB', '2016-12-13 11:18:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3513', 'Margilon', 'UZB', '2016-12-13 11:18:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3514', 'Ãœrgenc', 'UZB', '2016-12-13 11:18:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3515', 'Angren', 'UZB', '2016-12-13 11:18:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3516', 'Cizah', 'UZB', '2016-12-13 11:18:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3517', 'Navoi', 'UZB', '2016-12-13 11:18:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3518', 'Olmalik', 'UZB', '2016-12-13 11:18:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3519', 'Termiz', 'UZB', '2016-12-13 11:18:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3520', 'Minsk', 'BLR', '2016-12-13 11:18:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3521', 'Gomel', 'BLR', '2016-12-13 11:18:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3522', 'Mogiljov', 'BLR', '2016-12-13 11:18:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3523', 'Vitebsk', 'BLR', '2016-12-13 11:18:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3524', 'Grodno', 'BLR', '2016-12-13 11:18:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3525', 'Brest', 'BLR', '2016-12-13 11:18:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3526', 'Bobruisk', 'BLR', '2016-12-13 11:18:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3527', 'BaranovitÅ¡i', 'BLR', '2016-12-13 11:18:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3528', 'Borisov', 'BLR', '2016-12-13 11:18:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3529', 'Pinsk', 'BLR', '2016-12-13 11:18:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3530', 'OrÅ¡a', 'BLR', '2016-12-13 11:18:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3531', 'Mozyr', 'BLR', '2016-12-13 11:18:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3532', 'Novopolotsk', 'BLR', '2016-12-13 11:18:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3533', 'Lida', 'BLR', '2016-12-13 11:18:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3534', 'Soligorsk', 'BLR', '2016-12-13 11:18:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3535', 'MolodetÅ¡no', 'BLR', '2016-12-13 11:18:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3536', 'Mata-Utu', 'WLF', '2016-12-13 11:18:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3537', 'Port-Vila', 'VUT', '2016-12-13 11:18:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3538', 'CittÃ  del Vaticano', 'VAT', '2016-12-13 11:18:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3539', 'Caracas', 'VEN', '2016-12-13 11:18:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3540', 'MaracaÃ­bo', 'VEN', '2016-12-13 11:18:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3541', 'Barquisimeto', 'VEN', '2016-12-13 11:18:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3542', 'Valencia', 'VEN', '2016-12-13 11:18:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3543', 'Ciudad Guayana', 'VEN', '2016-12-13 11:18:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3544', 'Petare', 'VEN', '2016-12-13 11:18:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3545', 'Maracay', 'VEN', '2016-12-13 11:18:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3546', 'Barcelona', 'VEN', '2016-12-13 11:18:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3547', 'MaturÃ­n', 'VEN', '2016-12-13 11:18:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3548', 'San CristÃ³bal', 'VEN', '2016-12-13 11:18:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3549', 'Ciudad BolÃ­var', 'VEN', '2016-12-13 11:18:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3550', 'CumanÃ¡', 'VEN', '2016-12-13 11:18:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3551', 'MÃ©rida', 'VEN', '2016-12-13 11:18:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3552', 'Cabimas', 'VEN', '2016-12-13 11:18:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3553', 'Barinas', 'VEN', '2016-12-13 11:18:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3554', 'Turmero', 'VEN', '2016-12-13 11:18:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3555', 'Baruta', 'VEN', '2016-12-13 11:18:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3556', 'Puerto Cabello', 'VEN', '2016-12-13 11:18:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3557', 'Santa Ana de Coro', 'VEN', '2016-12-13 11:18:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3558', 'Los Teques', 'VEN', '2016-12-13 11:18:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3559', 'Punto Fijo', 'VEN', '2016-12-13 11:18:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3560', 'Guarenas', 'VEN', '2016-12-13 11:18:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3561', 'Acarigua', 'VEN', '2016-12-13 11:18:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3562', 'Puerto La Cruz', 'VEN', '2016-12-13 11:18:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3563', 'Ciudad Losada', 'VEN', '2016-12-13 11:18:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3564', 'Guacara', 'VEN', '2016-12-13 11:18:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3565', 'Valera', 'VEN', '2016-12-13 11:18:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3566', 'Guanare', 'VEN', '2016-12-13 11:18:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3567', 'CarÃºpano', 'VEN', '2016-12-13 11:18:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3568', 'Catia La Mar', 'VEN', '2016-12-13 11:18:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3569', 'El Tigre', 'VEN', '2016-12-13 11:18:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3570', 'Guatire', 'VEN', '2016-12-13 11:18:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3571', 'Calabozo', 'VEN', '2016-12-13 11:18:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3572', 'Pozuelos', 'VEN', '2016-12-13 11:18:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3573', 'Ciudad Ojeda', 'VEN', '2016-12-13 11:18:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3574', 'Ocumare del Tuy', 'VEN', '2016-12-13 11:18:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3575', 'Valle de la Pascua', 'VEN', '2016-12-13 11:18:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3576', 'Araure', 'VEN', '2016-12-13 11:18:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3577', 'San Fernando de Apure', 'VEN', '2016-12-13 11:18:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3578', 'San Felipe', 'VEN', '2016-12-13 11:18:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3579', 'El LimÃ³n', 'VEN', '2016-12-13 11:18:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3580', 'Moscow', 'RUS', '2016-12-13 11:18:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3581', 'St Petersburg', 'RUS', '2016-12-13 11:18:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3582', 'Novosibirsk', 'RUS', '2016-12-13 11:18:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3583', 'Nizni Novgorod', 'RUS', '2016-12-13 11:18:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3584', 'Jekaterinburg', 'RUS', '2016-12-13 11:18:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3585', 'Samara', 'RUS', '2016-12-13 11:18:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3586', 'Omsk', 'RUS', '2016-12-13 11:18:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3587', 'Kazan', 'RUS', '2016-12-13 11:18:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3588', 'Ufa', 'RUS', '2016-12-13 11:18:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3589', 'TÅ¡eljabinsk', 'RUS', '2016-12-13 11:18:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3590', 'Rostov-na-Donu', 'RUS', '2016-12-13 11:18:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3591', 'Perm', 'RUS', '2016-12-13 11:18:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3592', 'Volgograd', 'RUS', '2016-12-13 11:18:48', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3593', 'Voronez', 'RUS', '2016-12-13 11:18:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3594', 'Krasnojarsk', 'RUS', '2016-12-13 11:18:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3595', 'Saratov', 'RUS', '2016-12-13 11:18:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3596', 'Toljatti', 'RUS', '2016-12-13 11:18:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3597', 'Uljanovsk', 'RUS', '2016-12-13 11:18:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3598', 'Izevsk', 'RUS', '2016-12-13 11:18:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3599', 'Krasnodar', 'RUS', '2016-12-13 11:18:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3600', 'Jaroslavl', 'RUS', '2016-12-13 11:18:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3601', 'Habarovsk', 'RUS', '2016-12-13 11:18:49', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3602', 'Vladivostok', 'RUS', '2016-12-13 11:18:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3603', 'Irkutsk', 'RUS', '2016-12-13 11:18:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3604', 'Barnaul', 'RUS', '2016-12-13 11:18:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3605', 'Novokuznetsk', 'RUS', '2016-12-13 11:18:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3606', 'Penza', 'RUS', '2016-12-13 11:18:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3607', 'Rjazan', 'RUS', '2016-12-13 11:18:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3608', 'Orenburg', 'RUS', '2016-12-13 11:18:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3609', 'Lipetsk', 'RUS', '2016-12-13 11:18:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3610', 'Nabereznyje TÅ¡elny', 'RUS', '2016-12-13 11:18:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3611', 'Tula', 'RUS', '2016-12-13 11:18:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3612', 'Tjumen', 'RUS', '2016-12-13 11:18:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3613', 'Kemerovo', 'RUS', '2016-12-13 11:18:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3614', 'Astrahan', 'RUS', '2016-12-13 11:18:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3615', 'Tomsk', 'RUS', '2016-12-13 11:18:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3616', 'Kirov', 'RUS', '2016-12-13 11:18:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3617', 'Ivanovo', 'RUS', '2016-12-13 11:18:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3618', 'TÅ¡eboksary', 'RUS', '2016-12-13 11:18:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3619', 'Brjansk', 'RUS', '2016-12-13 11:18:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3620', 'Tver', 'RUS', '2016-12-13 11:18:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3621', 'Kursk', 'RUS', '2016-12-13 11:18:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3622', 'Magnitogorsk', 'RUS', '2016-12-13 11:18:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3623', 'Kaliningrad', 'RUS', '2016-12-13 11:18:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3624', 'Nizni Tagil', 'RUS', '2016-12-13 11:18:51', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3625', 'Murmansk', 'RUS', '2016-12-13 11:18:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3626', 'Ulan-Ude', 'RUS', '2016-12-13 11:18:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3627', 'Kurgan', 'RUS', '2016-12-13 11:18:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3628', 'Arkangeli', 'RUS', '2016-12-13 11:18:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3629', 'SotÅ¡i', 'RUS', '2016-12-13 11:18:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3630', 'Smolensk', 'RUS', '2016-12-13 11:18:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3631', 'Orjol', 'RUS', '2016-12-13 11:18:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3632', 'Stavropol', 'RUS', '2016-12-13 11:18:52', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3633', 'Belgorod', 'RUS', '2016-12-13 11:18:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3634', 'Kaluga', 'RUS', '2016-12-13 11:18:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3635', 'Vladimir', 'RUS', '2016-12-13 11:18:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3636', 'MahatÅ¡kala', 'RUS', '2016-12-13 11:18:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3637', 'TÅ¡erepovets', 'RUS', '2016-12-13 11:18:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3638', 'Saransk', 'RUS', '2016-12-13 11:18:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3639', 'Tambov', 'RUS', '2016-12-13 11:18:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3640', 'Vladikavkaz', 'RUS', '2016-12-13 11:18:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3641', 'TÅ¡ita', 'RUS', '2016-12-13 11:18:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3642', 'Vologda', 'RUS', '2016-12-13 11:18:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3643', 'Veliki Novgorod', 'RUS', '2016-12-13 11:18:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3644', 'Komsomolsk-na-Amure', 'RUS', '2016-12-13 11:18:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3645', 'Kostroma', 'RUS', '2016-12-13 11:18:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3646', 'Volzski', 'RUS', '2016-12-13 11:18:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3647', 'Taganrog', 'RUS', '2016-12-13 11:18:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3648', 'Petroskoi', 'RUS', '2016-12-13 11:18:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3649', 'Bratsk', 'RUS', '2016-12-13 11:18:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3650', 'Dzerzinsk', 'RUS', '2016-12-13 11:18:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3651', 'Surgut', 'RUS', '2016-12-13 11:18:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3652', 'Orsk', 'RUS', '2016-12-13 11:18:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3653', 'Sterlitamak', 'RUS', '2016-12-13 11:18:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3654', 'Angarsk', 'RUS', '2016-12-13 11:18:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3655', 'JoÅ¡kar-Ola', 'RUS', '2016-12-13 11:18:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3656', 'Rybinsk', 'RUS', '2016-12-13 11:18:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3657', 'Prokopjevsk', 'RUS', '2016-12-13 11:18:55', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3658', 'Niznevartovsk', 'RUS', '2016-12-13 11:18:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3659', 'NaltÅ¡ik', 'RUS', '2016-12-13 11:18:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3660', 'Syktyvkar', 'RUS', '2016-12-13 11:18:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3661', 'Severodvinsk', 'RUS', '2016-12-13 11:18:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3662', 'Bijsk', 'RUS', '2016-12-13 11:18:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3663', 'Niznekamsk', 'RUS', '2016-12-13 11:18:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3664', 'BlagoveÅ¡tÅ¡ensk', 'RUS', '2016-12-13 11:18:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3665', 'Å ahty', 'RUS', '2016-12-13 11:18:56', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3666', 'Staryi Oskol', 'RUS', '2016-12-13 11:18:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3667', 'Zelenograd', 'RUS', '2016-12-13 11:18:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3668', 'Balakovo', 'RUS', '2016-12-13 11:18:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3669', 'Novorossijsk', 'RUS', '2016-12-13 11:18:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3670', 'Pihkova', 'RUS', '2016-12-13 11:18:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3671', 'Zlatoust', 'RUS', '2016-12-13 11:18:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3672', 'Jakutsk', 'RUS', '2016-12-13 11:18:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3673', 'Podolsk', 'RUS', '2016-12-13 11:18:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3674', 'Petropavlovsk-KamtÅ¡atski', 'RUS', '2016-12-13 11:18:57', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3675', 'Kamensk-Uralski', 'RUS', '2016-12-13 11:18:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3676', 'Engels', 'RUS', '2016-12-13 11:18:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3677', 'Syzran', 'RUS', '2016-12-13 11:18:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3678', 'Grozny', 'RUS', '2016-12-13 11:18:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3679', 'NovotÅ¡erkassk', 'RUS', '2016-12-13 11:18:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3680', 'Berezniki', 'RUS', '2016-12-13 11:18:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3681', 'Juzno-Sahalinsk', 'RUS', '2016-12-13 11:18:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3682', 'Volgodonsk', 'RUS', '2016-12-13 11:18:58', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3683', 'Abakan', 'RUS', '2016-12-13 11:18:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3684', 'Maikop', 'RUS', '2016-12-13 11:18:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3685', 'Miass', 'RUS', '2016-12-13 11:18:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3686', 'Armavir', 'RUS', '2016-12-13 11:18:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3687', 'Ljubertsy', 'RUS', '2016-12-13 11:18:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3688', 'Rubtsovsk', 'RUS', '2016-12-13 11:18:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3689', 'Kovrov', 'RUS', '2016-12-13 11:18:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3690', 'Nahodka', 'RUS', '2016-12-13 11:18:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3691', 'Ussurijsk', 'RUS', '2016-12-13 11:18:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3692', 'Salavat', 'RUS', '2016-12-13 11:18:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3693', 'MytiÅ¡tÅ¡i', 'RUS', '2016-12-13 11:18:59', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3694', 'Kolomna', 'RUS', '2016-12-13 11:19:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3695', 'Elektrostal', 'RUS', '2016-12-13 11:19:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3696', 'Murom', 'RUS', '2016-12-13 11:19:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3697', 'Kolpino', 'RUS', '2016-12-13 11:19:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3698', 'Norilsk', 'RUS', '2016-12-13 11:19:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3699', 'Almetjevsk', 'RUS', '2016-12-13 11:19:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3700', 'Novomoskovsk', 'RUS', '2016-12-13 11:19:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3701', 'Dimitrovgrad', 'RUS', '2016-12-13 11:19:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3702', 'Pervouralsk', 'RUS', '2016-12-13 11:19:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3703', 'Himki', 'RUS', '2016-12-13 11:19:00', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3704', 'BalaÅ¡iha', 'RUS', '2016-12-13 11:19:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3705', 'Nevinnomyssk', 'RUS', '2016-12-13 11:19:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3706', 'Pjatigorsk', 'RUS', '2016-12-13 11:19:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3707', 'Korolev', 'RUS', '2016-12-13 11:19:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3708', 'Serpuhov', 'RUS', '2016-12-13 11:19:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3709', 'Odintsovo', 'RUS', '2016-12-13 11:19:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3710', 'Orehovo-Zujevo', 'RUS', '2016-12-13 11:19:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3711', 'KamyÅ¡in', 'RUS', '2016-12-13 11:19:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3712', 'NovotÅ¡eboksarsk', 'RUS', '2016-12-13 11:19:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3713', 'TÅ¡erkessk', 'RUS', '2016-12-13 11:19:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3714', 'AtÅ¡insk', 'RUS', '2016-12-13 11:19:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3715', 'Magadan', 'RUS', '2016-12-13 11:19:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3716', 'MitÅ¡urinsk', 'RUS', '2016-12-13 11:19:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3717', 'Kislovodsk', 'RUS', '2016-12-13 11:19:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3718', 'Jelets', 'RUS', '2016-12-13 11:19:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3719', 'Seversk', 'RUS', '2016-12-13 11:19:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3720', 'Noginsk', 'RUS', '2016-12-13 11:19:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3721', 'Velikije Luki', 'RUS', '2016-12-13 11:19:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3722', 'NovokuibyÅ¡evsk', 'RUS', '2016-12-13 11:19:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3723', 'Neftekamsk', 'RUS', '2016-12-13 11:19:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3724', 'Leninsk-Kuznetski', 'RUS', '2016-12-13 11:19:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3725', 'Oktjabrski', 'RUS', '2016-12-13 11:19:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3726', 'Sergijev Posad', 'RUS', '2016-12-13 11:19:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3727', 'Arzamas', 'RUS', '2016-12-13 11:19:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3728', 'Kiseljovsk', 'RUS', '2016-12-13 11:19:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3729', 'Novotroitsk', 'RUS', '2016-12-13 11:19:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3730', 'Obninsk', 'RUS', '2016-12-13 11:19:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3731', 'Kansk', 'RUS', '2016-12-13 11:19:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3732', 'Glazov', 'RUS', '2016-12-13 11:19:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3733', 'Solikamsk', 'RUS', '2016-12-13 11:19:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3734', 'Sarapul', 'RUS', '2016-12-13 11:19:03', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3735', 'Ust-Ilimsk', 'RUS', '2016-12-13 11:19:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3736', 'Å tÅ¡olkovo', 'RUS', '2016-12-13 11:19:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3737', 'MezduretÅ¡ensk', 'RUS', '2016-12-13 11:19:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3738', 'Usolje-Sibirskoje', 'RUS', '2016-12-13 11:19:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3739', 'Elista', 'RUS', '2016-12-13 11:19:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3740', 'NovoÅ¡ahtinsk', 'RUS', '2016-12-13 11:19:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3741', 'Votkinsk', 'RUS', '2016-12-13 11:19:04', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3742', 'Kyzyl', 'RUS', '2016-12-13 11:19:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3743', 'Serov', 'RUS', '2016-12-13 11:19:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3744', 'Zelenodolsk', 'RUS', '2016-12-13 11:19:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3745', 'Zeleznodoroznyi', 'RUS', '2016-12-13 11:19:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3746', 'KineÅ¡ma', 'RUS', '2016-12-13 11:19:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3747', 'Kuznetsk', 'RUS', '2016-12-13 11:19:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3748', 'Uhta', 'RUS', '2016-12-13 11:19:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3749', 'Jessentuki', 'RUS', '2016-12-13 11:19:05', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3750', 'Tobolsk', 'RUS', '2016-12-13 11:19:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3751', 'Neftejugansk', 'RUS', '2016-12-13 11:19:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3752', 'Bataisk', 'RUS', '2016-12-13 11:19:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3753', 'Nojabrsk', 'RUS', '2016-12-13 11:19:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3754', 'BalaÅ¡ov', 'RUS', '2016-12-13 11:19:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3755', 'Zeleznogorsk', 'RUS', '2016-12-13 11:19:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3756', 'Zukovski', 'RUS', '2016-12-13 11:19:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3757', 'Anzero-Sudzensk', 'RUS', '2016-12-13 11:19:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3758', 'Bugulma', 'RUS', '2016-12-13 11:19:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3759', 'Zeleznogorsk', 'RUS', '2016-12-13 11:19:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3760', 'Novouralsk', 'RUS', '2016-12-13 11:19:07', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3761', 'PuÅ¡kin', 'RUS', '2016-12-13 11:19:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3762', 'Vorkuta', 'RUS', '2016-12-13 11:19:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3763', 'Derbent', 'RUS', '2016-12-13 11:19:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3764', 'Kirovo-TÅ¡epetsk', 'RUS', '2016-12-13 11:19:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3765', 'Krasnogorsk', 'RUS', '2016-12-13 11:19:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3766', 'Klin', 'RUS', '2016-12-13 11:19:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3767', 'TÅ¡aikovski', 'RUS', '2016-12-13 11:19:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3768', 'Novyi Urengoi', 'RUS', '2016-12-13 11:19:08', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3769', 'Ho Chi Minh City', 'VNM', '2016-12-13 11:19:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3770', 'Hanoi', 'VNM', '2016-12-13 11:19:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3771', 'Haiphong', 'VNM', '2016-12-13 11:19:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3772', 'Da Nang', 'VNM', '2016-12-13 11:19:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3773', 'BiÃªn Hoa', 'VNM', '2016-12-13 11:19:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3774', 'Nha Trang', 'VNM', '2016-12-13 11:19:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3775', 'Hue', 'VNM', '2016-12-13 11:19:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3776', 'Can Tho', 'VNM', '2016-12-13 11:19:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3777', 'Cam Pha', 'VNM', '2016-12-13 11:19:09', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3778', 'Nam Dinh', 'VNM', '2016-12-13 11:19:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3779', 'Quy Nhon', 'VNM', '2016-12-13 11:19:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3780', 'Vung Tau', 'VNM', '2016-12-13 11:19:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3781', 'Rach Gia', 'VNM', '2016-12-13 11:19:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3782', 'Long Xuyen', 'VNM', '2016-12-13 11:19:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3783', 'Thai Nguyen', 'VNM', '2016-12-13 11:19:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3784', 'Hong Gai', 'VNM', '2016-12-13 11:19:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3785', 'Phan ThiÃªt', 'VNM', '2016-12-13 11:19:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3786', 'Cam Ranh', 'VNM', '2016-12-13 11:19:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3787', 'Vinh', 'VNM', '2016-12-13 11:19:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3788', 'My Tho', 'VNM', '2016-12-13 11:19:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3789', 'Da Lat', 'VNM', '2016-12-13 11:19:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3790', 'Buon Ma Thuot', 'VNM', '2016-12-13 11:19:10', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3791', 'Tallinn', 'EST', '2016-12-13 11:19:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3792', 'Tartu', 'EST', '2016-12-13 11:19:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3793', 'New York', 'USA', '2016-12-13 11:19:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3794', 'Los Angeles', 'USA', '2016-12-13 11:19:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3795', 'Chicago', 'USA', '2016-12-13 11:19:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3796', 'Houston', 'USA', '2016-12-13 11:19:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3797', 'Philadelphia', 'USA', '2016-12-13 11:19:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3798', 'Phoenix', 'USA', '2016-12-13 11:19:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3799', 'San Diego', 'USA', '2016-12-13 11:19:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3800', 'Dallas', 'USA', '2016-12-13 11:19:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3801', 'San Antonio', 'USA', '2016-12-13 11:19:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3802', 'Detroit', 'USA', '2016-12-13 11:19:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3803', 'San Jose', 'USA', '2016-12-13 11:19:11', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3804', 'Indianapolis', 'USA', '2016-12-13 11:19:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3805', 'San Francisco', 'USA', '2016-12-13 11:19:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3806', 'Jacksonville', 'USA', '2016-12-13 11:19:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3807', 'Columbus', 'USA', '2016-12-13 11:19:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3808', 'Austin', 'USA', '2016-12-13 11:19:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3809', 'Baltimore', 'USA', '2016-12-13 11:19:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3810', 'Memphis', 'USA', '2016-12-13 11:19:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3811', 'Milwaukee', 'USA', '2016-12-13 11:19:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3812', 'Boston', 'USA', '2016-12-13 11:19:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3813', 'Washington', 'USA', '2016-12-13 11:19:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3814', 'Nashville-Davidson', 'USA', '2016-12-13 11:19:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3815', 'El Paso', 'USA', '2016-12-13 11:19:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3816', 'Seattle', 'USA', '2016-12-13 11:19:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3817', 'Denver', 'USA', '2016-12-13 11:19:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3818', 'Charlotte', 'USA', '2016-12-13 11:19:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3819', 'Fort Worth', 'USA', '2016-12-13 11:19:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3820', 'Portland', 'USA', '2016-12-13 11:19:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3821', 'Oklahoma City', 'USA', '2016-12-13 11:19:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3822', 'Tucson', 'USA', '2016-12-13 11:19:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3823', 'New Orleans', 'USA', '2016-12-13 11:19:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3824', 'Las Vegas', 'USA', '2016-12-13 11:19:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3825', 'Cleveland', 'USA', '2016-12-13 11:19:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3826', 'Long Beach', 'USA', '2016-12-13 11:19:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3827', 'Albuquerque', 'USA', '2016-12-13 11:19:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3828', 'Kansas City', 'USA', '2016-12-13 11:19:13', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3829', 'Fresno', 'USA', '2016-12-13 11:19:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3830', 'Virginia Beach', 'USA', '2016-12-13 11:19:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3831', 'Atlanta', 'USA', '2016-12-13 11:19:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3832', 'Sacramento', 'USA', '2016-12-13 11:19:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3833', 'Oakland', 'USA', '2016-12-13 11:19:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3834', 'Mesa', 'USA', '2016-12-13 11:19:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3835', 'Tulsa', 'USA', '2016-12-13 11:19:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3836', 'Omaha', 'USA', '2016-12-13 11:19:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3837', 'Minneapolis', 'USA', '2016-12-13 11:19:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3838', 'Honolulu', 'USA', '2016-12-13 11:19:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3839', 'Miami', 'USA', '2016-12-13 11:19:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3840', 'Colorado Springs', 'USA', '2016-12-13 11:19:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3841', 'Saint Louis', 'USA', '2016-12-13 11:19:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3842', 'Wichita', 'USA', '2016-12-13 11:19:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3843', 'Santa Ana', 'USA', '2016-12-13 11:19:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3844', 'Pittsburgh', 'USA', '2016-12-13 11:19:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3845', 'Arlington', 'USA', '2016-12-13 11:19:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3846', 'Cincinnati', 'USA', '2016-12-13 11:19:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3847', 'Anaheim', 'USA', '2016-12-13 11:19:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3848', 'Toledo', 'USA', '2016-12-13 11:19:15', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3849', 'Tampa', 'USA', '2016-12-13 11:19:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3850', 'Buffalo', 'USA', '2016-12-13 11:19:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3851', 'Saint Paul', 'USA', '2016-12-13 11:19:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3852', 'Corpus Christi', 'USA', '2016-12-13 11:19:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3853', 'Aurora', 'USA', '2016-12-13 11:19:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3854', 'Raleigh', 'USA', '2016-12-13 11:19:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3855', 'Newark', 'USA', '2016-12-13 11:19:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3856', 'Lexington-Fayette', 'USA', '2016-12-13 11:19:16', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3857', 'Anchorage', 'USA', '2016-12-13 11:19:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3858', 'Louisville', 'USA', '2016-12-13 11:19:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3859', 'Riverside', 'USA', '2016-12-13 11:19:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3860', 'Saint Petersburg', 'USA', '2016-12-13 11:19:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3861', 'Bakersfield', 'USA', '2016-12-13 11:19:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3862', 'Stockton', 'USA', '2016-12-13 11:19:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3863', 'Birmingham', 'USA', '2016-12-13 11:19:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3864', 'Jersey City', 'USA', '2016-12-13 11:19:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3865', 'Norfolk', 'USA', '2016-12-13 11:19:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3866', 'Baton Rouge', 'USA', '2016-12-13 11:19:17', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3867', 'Hialeah', 'USA', '2016-12-13 11:19:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3868', 'Lincoln', 'USA', '2016-12-13 11:19:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3869', 'Greensboro', 'USA', '2016-12-13 11:19:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3870', 'Plano', 'USA', '2016-12-13 11:19:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3871', 'Rochester', 'USA', '2016-12-13 11:19:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3872', 'Glendale', 'USA', '2016-12-13 11:19:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3873', 'Akron', 'USA', '2016-12-13 11:19:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3874', 'Garland', 'USA', '2016-12-13 11:19:18', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3875', 'Madison', 'USA', '2016-12-13 11:19:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3876', 'Fort Wayne', 'USA', '2016-12-13 11:19:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3877', 'Fremont', 'USA', '2016-12-13 11:19:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3878', 'Scottsdale', 'USA', '2016-12-13 11:19:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3879', 'Montgomery', 'USA', '2016-12-13 11:19:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3880', 'Shreveport', 'USA', '2016-12-13 11:19:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3881', 'Augusta-Richmond County', 'USA', '2016-12-13 11:19:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3882', 'Lubbock', 'USA', '2016-12-13 11:19:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3883', 'Chesapeake', 'USA', '2016-12-13 11:19:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3884', 'Mobile', 'USA', '2016-12-13 11:19:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3885', 'Des Moines', 'USA', '2016-12-13 11:19:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3886', 'Grand Rapids', 'USA', '2016-12-13 11:19:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3887', 'Richmond', 'USA', '2016-12-13 11:19:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3888', 'Yonkers', 'USA', '2016-12-13 11:19:19', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3889', 'Spokane', 'USA', '2016-12-13 11:19:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3890', 'Glendale', 'USA', '2016-12-13 11:19:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3891', 'Tacoma', 'USA', '2016-12-13 11:19:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3892', 'Irving', 'USA', '2016-12-13 11:19:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3893', 'Huntington Beach', 'USA', '2016-12-13 11:19:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3894', 'Modesto', 'USA', '2016-12-13 11:19:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3895', 'Durham', 'USA', '2016-12-13 11:19:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3896', 'Columbus', 'USA', '2016-12-13 11:19:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3897', 'Orlando', 'USA', '2016-12-13 11:19:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3898', 'Boise City', 'USA', '2016-12-13 11:19:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3899', 'Winston-Salem', 'USA', '2016-12-13 11:19:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3900', 'San Bernardino', 'USA', '2016-12-13 11:19:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3901', 'Jackson', 'USA', '2016-12-13 11:19:20', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3902', 'Little Rock', 'USA', '2016-12-13 11:19:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3903', 'Salt Lake City', 'USA', '2016-12-13 11:19:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3904', 'Reno', 'USA', '2016-12-13 11:19:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3905', 'Newport News', 'USA', '2016-12-13 11:19:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3906', 'Chandler', 'USA', '2016-12-13 11:19:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3907', 'Laredo', 'USA', '2016-12-13 11:19:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3908', 'Henderson', 'USA', '2016-12-13 11:19:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3909', 'Arlington', 'USA', '2016-12-13 11:19:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3910', 'Knoxville', 'USA', '2016-12-13 11:19:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3911', 'Amarillo', 'USA', '2016-12-13 11:19:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3912', 'Providence', 'USA', '2016-12-13 11:19:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3913', 'Chula Vista', 'USA', '2016-12-13 11:19:21', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3914', 'Worcester', 'USA', '2016-12-13 11:19:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3915', 'Oxnard', 'USA', '2016-12-13 11:19:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3916', 'Dayton', 'USA', '2016-12-13 11:19:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3917', 'Garden Grove', 'USA', '2016-12-13 11:19:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3918', 'Oceanside', 'USA', '2016-12-13 11:19:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3919', 'Tempe', 'USA', '2016-12-13 11:19:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3920', 'Huntsville', 'USA', '2016-12-13 11:19:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3921', 'Ontario', 'USA', '2016-12-13 11:19:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3922', 'Chattanooga', 'USA', '2016-12-13 11:19:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3923', 'Fort Lauderdale', 'USA', '2016-12-13 11:19:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3924', 'Springfield', 'USA', '2016-12-13 11:19:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3925', 'Springfield', 'USA', '2016-12-13 11:19:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3926', 'Santa Clarita', 'USA', '2016-12-13 11:19:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3927', 'Salinas', 'USA', '2016-12-13 11:19:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3928', 'Tallahassee', 'USA', '2016-12-13 11:19:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3929', 'Rockford', 'USA', '2016-12-13 11:19:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3930', 'Pomona', 'USA', '2016-12-13 11:19:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3931', 'Metairie', 'USA', '2016-12-13 11:19:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3932', 'Paterson', 'USA', '2016-12-13 11:19:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3933', 'Overland Park', 'USA', '2016-12-13 11:19:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3934', 'Santa Rosa', 'USA', '2016-12-13 11:19:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3935', 'Syracuse', 'USA', '2016-12-13 11:19:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3936', 'Kansas City', 'USA', '2016-12-13 11:19:23', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3937', 'Hampton', 'USA', '2016-12-13 11:19:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3938', 'Lakewood', 'USA', '2016-12-13 11:19:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3939', 'Vancouver', 'USA', '2016-12-13 11:19:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3940', 'Irvine', 'USA', '2016-12-13 11:19:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3941', 'Aurora', 'USA', '2016-12-13 11:19:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3942', 'Moreno Valley', 'USA', '2016-12-13 11:19:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3943', 'Pasadena', 'USA', '2016-12-13 11:19:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3944', 'Hayward', 'USA', '2016-12-13 11:19:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3945', 'Brownsville', 'USA', '2016-12-13 11:19:24', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3946', 'Bridgeport', 'USA', '2016-12-13 11:19:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3947', 'Hollywood', 'USA', '2016-12-13 11:19:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3948', 'Warren', 'USA', '2016-12-13 11:19:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3949', 'Torrance', 'USA', '2016-12-13 11:19:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3950', 'Eugene', 'USA', '2016-12-13 11:19:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3951', 'Pembroke Pines', 'USA', '2016-12-13 11:19:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3952', 'Salem', 'USA', '2016-12-13 11:19:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3953', 'Pasadena', 'USA', '2016-12-13 11:19:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3954', 'Escondido', 'USA', '2016-12-13 11:19:25', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3955', 'Sunnyvale', 'USA', '2016-12-13 11:19:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3956', 'Savannah', 'USA', '2016-12-13 11:19:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3957', 'Fontana', 'USA', '2016-12-13 11:19:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3958', 'Orange', 'USA', '2016-12-13 11:19:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3959', 'Naperville', 'USA', '2016-12-13 11:19:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3960', 'Alexandria', 'USA', '2016-12-13 11:19:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3961', 'Rancho Cucamonga', 'USA', '2016-12-13 11:19:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3962', 'Grand Prairie', 'USA', '2016-12-13 11:19:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3963', 'East Los Angeles', 'USA', '2016-12-13 11:19:26', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3964', 'Fullerton', 'USA', '2016-12-13 11:19:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3965', 'Corona', 'USA', '2016-12-13 11:19:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3966', 'Flint', 'USA', '2016-12-13 11:19:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3967', 'Paradise', 'USA', '2016-12-13 11:19:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3968', 'Mesquite', 'USA', '2016-12-13 11:19:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3969', 'Sterling Heights', 'USA', '2016-12-13 11:19:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3970', 'Sioux Falls', 'USA', '2016-12-13 11:19:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3971', 'New Haven', 'USA', '2016-12-13 11:19:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3972', 'Topeka', 'USA', '2016-12-13 11:19:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3973', 'Concord', 'USA', '2016-12-13 11:19:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3974', 'Evansville', 'USA', '2016-12-13 11:19:27', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3975', 'Hartford', 'USA', '2016-12-13 11:19:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3976', 'Fayetteville', 'USA', '2016-12-13 11:19:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3977', 'Cedar Rapids', 'USA', '2016-12-13 11:19:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3978', 'Elizabeth', 'USA', '2016-12-13 11:19:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3979', 'Lansing', 'USA', '2016-12-13 11:19:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3980', 'Lancaster', 'USA', '2016-12-13 11:19:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3981', 'Fort Collins', 'USA', '2016-12-13 11:19:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3982', 'Coral Springs', 'USA', '2016-12-13 11:19:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3983', 'Stamford', 'USA', '2016-12-13 11:19:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3984', 'Thousand Oaks', 'USA', '2016-12-13 11:19:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3985', 'Vallejo', 'USA', '2016-12-13 11:19:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3986', 'Palmdale', 'USA', '2016-12-13 11:19:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3987', 'Columbia', 'USA', '2016-12-13 11:19:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3988', 'El Monte', 'USA', '2016-12-13 11:19:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3989', 'Abilene', 'USA', '2016-12-13 11:19:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3990', 'North Las Vegas', 'USA', '2016-12-13 11:19:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3991', 'Ann Arbor', 'USA', '2016-12-13 11:19:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3992', 'Beaumont', 'USA', '2016-12-13 11:19:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3993', 'Waco', 'USA', '2016-12-13 11:19:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3994', 'Macon', 'USA', '2016-12-13 11:19:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3995', 'Independence', 'USA', '2016-12-13 11:19:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3996', 'Peoria', 'USA', '2016-12-13 11:19:29', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3997', 'Inglewood', 'USA', '2016-12-13 11:19:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3998', 'Springfield', 'USA', '2016-12-13 11:19:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('3999', 'Simi Valley', 'USA', '2016-12-13 11:19:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4000', 'Lafayette', 'USA', '2016-12-13 11:19:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4001', 'Gilbert', 'USA', '2016-12-13 11:19:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4002', 'Carrollton', 'USA', '2016-12-13 11:19:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4003', 'Bellevue', 'USA', '2016-12-13 11:19:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4004', 'West Valley City', 'USA', '2016-12-13 11:19:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4005', 'Clarksville', 'USA', '2016-12-13 11:19:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4006', 'Costa Mesa', 'USA', '2016-12-13 11:19:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4007', 'Peoria', 'USA', '2016-12-13 11:19:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4008', 'South Bend', 'USA', '2016-12-13 11:19:30', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4009', 'Downey', 'USA', '2016-12-13 11:19:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4010', 'Waterbury', 'USA', '2016-12-13 11:19:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4011', 'Manchester', 'USA', '2016-12-13 11:19:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4012', 'Allentown', 'USA', '2016-12-13 11:19:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4013', 'McAllen', 'USA', '2016-12-13 11:19:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4014', 'Joliet', 'USA', '2016-12-13 11:19:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4015', 'Lowell', 'USA', '2016-12-13 11:19:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4016', 'Provo', 'USA', '2016-12-13 11:19:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4017', 'West Covina', 'USA', '2016-12-13 11:19:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4018', 'Wichita Falls', 'USA', '2016-12-13 11:19:31', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4019', 'Erie', 'USA', '2016-12-13 11:19:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4020', 'Daly City', 'USA', '2016-12-13 11:19:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4021', 'Citrus Heights', 'USA', '2016-12-13 11:19:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4022', 'Norwalk', 'USA', '2016-12-13 11:19:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4023', 'Gary', 'USA', '2016-12-13 11:19:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4024', 'Berkeley', 'USA', '2016-12-13 11:19:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4025', 'Santa Clara', 'USA', '2016-12-13 11:19:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4026', 'Green Bay', 'USA', '2016-12-13 11:19:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4027', 'Cape Coral', 'USA', '2016-12-13 11:19:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4028', 'Arvada', 'USA', '2016-12-13 11:19:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4029', 'Pueblo', 'USA', '2016-12-13 11:19:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4030', 'Sandy', 'USA', '2016-12-13 11:19:32', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4031', 'Athens-Clarke County', 'USA', '2016-12-13 11:19:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4032', 'Cambridge', 'USA', '2016-12-13 11:19:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4033', 'Westminster', 'USA', '2016-12-13 11:19:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4034', 'San Buenaventura', 'USA', '2016-12-13 11:19:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4035', 'Portsmouth', 'USA', '2016-12-13 11:19:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4036', 'Livonia', 'USA', '2016-12-13 11:19:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4037', 'Burbank', 'USA', '2016-12-13 11:19:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4038', 'Clearwater', 'USA', '2016-12-13 11:19:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4039', 'Midland', 'USA', '2016-12-13 11:19:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4040', 'Davenport', 'USA', '2016-12-13 11:19:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4041', 'Mission Viejo', 'USA', '2016-12-13 11:19:33', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4042', 'Miami Beach', 'USA', '2016-12-13 11:19:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4043', 'Sunrise Manor', 'USA', '2016-12-13 11:19:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4044', 'New Bedford', 'USA', '2016-12-13 11:19:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4045', 'El Cajon', 'USA', '2016-12-13 11:19:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4046', 'Norman', 'USA', '2016-12-13 11:19:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4047', 'Richmond', 'USA', '2016-12-13 11:19:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4048', 'Albany', 'USA', '2016-12-13 11:19:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4049', 'Brockton', 'USA', '2016-12-13 11:19:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4050', 'Roanoke', 'USA', '2016-12-13 11:19:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4051', 'Billings', 'USA', '2016-12-13 11:19:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4052', 'Compton', 'USA', '2016-12-13 11:19:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4053', 'Gainesville', 'USA', '2016-12-13 11:19:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4054', 'Fairfield', 'USA', '2016-12-13 11:19:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4055', 'Arden-Arcade', 'USA', '2016-12-13 11:19:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4056', 'San Mateo', 'USA', '2016-12-13 11:19:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4057', 'Visalia', 'USA', '2016-12-13 11:19:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4058', 'Boulder', 'USA', '2016-12-13 11:19:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4059', 'Cary', 'USA', '2016-12-13 11:19:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4060', 'Santa Monica', 'USA', '2016-12-13 11:19:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4061', 'Fall River', 'USA', '2016-12-13 11:19:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4062', 'Kenosha', 'USA', '2016-12-13 11:19:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4063', 'Elgin', 'USA', '2016-12-13 11:19:35', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4064', 'Odessa', 'USA', '2016-12-13 11:19:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4065', 'Carson', 'USA', '2016-12-13 11:19:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4066', 'Charleston', 'USA', '2016-12-13 11:19:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4067', 'Charlotte Amalie', 'VIR', '2016-12-13 11:19:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4068', 'Harare', 'ZWE', '2016-12-13 11:19:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4069', 'Bulawayo', 'ZWE', '2016-12-13 11:19:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4070', 'Chitungwiza', 'ZWE', '2016-12-13 11:19:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4071', 'Mount Darwin', 'ZWE', '2016-12-13 11:19:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4072', 'Mutare', 'ZWE', '2016-12-13 11:19:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4073', 'Gweru', 'ZWE', '2016-12-13 11:19:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4074', 'Gaza', 'PSE', '2016-12-13 11:19:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4075', 'Khan Yunis', 'PSE', '2016-12-13 11:19:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4076', 'Hebron', 'PSE', '2016-12-13 11:19:36', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4077', 'Jabaliya', 'PSE', '2016-12-13 11:19:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4078', 'Nablus', 'PSE', '2016-12-13 11:19:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4079', 'Rafah', 'PSE', '2016-12-13 11:19:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4080', 'St. Thomas', 'VGB', '2016-12-13 11:19:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4081', 'St. Croix', 'VGB', '2016-12-13 11:19:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4082', 'ColÃ³n', 'PAN', '2016-12-13 11:19:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4087', 'Aguazul', 'COL', '2016-12-13 11:19:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4088', 'Espinal', 'COL', '2016-12-13 11:19:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4089', 'La Unión', 'COL', '2016-12-13 11:34:06', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4090', 'TulcÃ¡n', 'ECU', '2016-12-13 11:19:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4091', 'Ipiales', 'COL', '2016-12-13 11:19:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4092', 'Villa Hermosa', 'MEX', '2016-12-13 11:19:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4093', 'Cancun', 'MEX', '2016-12-13 11:19:37', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4493', 'Olocuilta', 'SLV', '2016-12-13 11:19:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4494', 'General Escobedo', 'MEX', '2016-12-13 11:19:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4495', 'Riohacha', 'COL', '2016-12-13 11:19:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4496', 'Yopal', 'COL', '2016-12-13 11:19:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4497', 'Tauramena', 'COL', '2016-12-13 11:19:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4498', 'Acacias', 'COL', '2016-12-13 11:19:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4499', 'Granada', 'COL', '2016-12-13 11:19:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4500', 'Zipaquira', 'COL', '2016-12-13 11:19:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4501', 'Yumbo', 'COL', '2016-12-13 11:19:38', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4502', 'Tocancipa', 'COL', '2016-12-13 11:19:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4503', 'Tame', 'COL', '2016-12-13 11:19:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4504', 'Saravena', 'COL', '2016-12-13 11:19:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4505', 'San Gil', 'COL', '2016-12-13 11:19:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4506', 'Sabaneta', 'COL', '2016-12-13 11:19:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4507', 'Rionegro', 'COL', '2016-12-13 11:19:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4508', 'Puerto Lopez', 'COL', '2016-12-13 11:19:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4509', 'Puerto Gaitan', 'COL', '2016-12-13 11:19:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4510', 'Piedecuesta', 'COL', '2016-12-13 11:19:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4511', 'Sabana de Torres', 'COL', '2016-12-13 11:19:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4512', 'Pamplona', 'COL', '2016-12-13 11:19:39', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4513', 'Paipa', 'COL', '2016-12-13 11:19:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4514', 'Orocue', 'COL', '2016-12-13 11:19:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4515', 'Mosquera', 'COL', '2016-12-13 11:19:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4516', 'Monterrey', 'COL', '2016-12-13 11:19:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4517', 'Madrid', 'COL', '2016-12-13 11:19:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4518', 'La Estrella', 'COL', '2016-12-13 11:19:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4519', 'Funza', 'COL', '2016-12-13 11:19:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4520', 'Guadalajara de Buga', 'COL', '2016-12-13 11:19:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4521', 'La Dorada', 'COL', '2016-12-13 11:19:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4522', 'La Calera', 'COL', '2016-12-13 11:19:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4523', 'Guarne', 'COL', '2016-12-13 11:19:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4524', 'Villeta', 'COL', '2016-12-13 11:19:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4525', 'Villa Nueva', 'COL', '2016-12-13 11:19:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4526', 'Urumita', 'COL', '2016-12-13 11:19:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4527', 'Turbo', 'COL', '2016-12-13 11:19:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4528', 'Turbaco', 'COL', '2016-12-13 11:19:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4529', 'Tenjo', 'COL', '2016-12-13 11:19:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4530', 'Tabio', 'COL', '2016-12-13 11:19:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4531', 'Socha', 'COL', '2016-12-13 11:19:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4532', 'Sitionuevo', 'COL', '2016-12-13 11:19:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4533', 'Santa Rosa', 'COL', '2016-12-13 11:19:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4534', 'San José del Guaviare', 'COL', '2016-12-13 11:34:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4535', 'Roldanillo', 'COL', '2016-12-13 11:19:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4536', 'Puerto Tejada', 'COL', '2016-12-13 11:19:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4537', 'Puerto Santander', 'COL', '2016-12-13 11:19:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4538', 'Puerto Salgar', 'COL', '2016-12-13 11:19:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4539', 'Puerto Lleras', 'COL', '2016-12-13 11:19:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4540', 'Puerto Colombia', 'COL', '2016-12-13 11:19:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4541', 'Puerto Berrío', 'COL', '2016-12-13 11:34:22', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4542', 'Pradera', 'COL', '2016-12-13 11:19:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4543', 'Pitalito', 'COL', '2016-12-13 11:19:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4544', 'Miraflores', 'COL', '2016-12-13 11:19:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4545', 'Marinilla', 'COL', '2016-12-13 11:19:42', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4546', 'Manaure', 'COL', '2016-12-13 11:19:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4547', 'Málaga', 'COL', '2016-12-13 11:34:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4548', 'Magangue', 'COL', '2016-12-13 11:34:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4549', 'Liborina', 'COL', '2016-12-13 11:19:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4550', 'La Virginia', 'COL', '2016-12-13 11:19:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4551', 'La Vega', 'COL', '2016-12-13 11:19:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4552', 'La Plata', 'COL', '2016-12-13 11:19:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4553', 'Granada', 'COL', '2016-12-13 11:19:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4554', 'Gachancipa', 'COL', '2016-12-13 11:19:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4555', 'Fusagasuga', 'COL', '2016-12-13 11:19:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4556', 'Fundación', 'COL', '2016-12-13 11:34:40', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4557', 'Fredonia', 'COL', '2016-12-13 11:19:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4558', 'Fonseca', 'COL', '2016-12-13 11:19:43', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4559', 'Facatativá', 'COL', '2016-12-13 11:34:47', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4560', 'El Carmen de Viboral', 'COL', '2016-12-13 11:19:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4561', 'El Carmen de Chucurí', 'COL', '2016-12-13 11:34:53', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4562', 'Duitama', 'COL', '2016-12-13 11:19:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4563', 'Curumaní', 'COL', '2016-12-13 11:35:02', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4564', 'Cumaribo', 'COL', '2016-12-13 11:19:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4565', 'Cucutilla', 'COL', '2016-12-13 11:19:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4566', 'Coveñas', 'COL', '2016-12-13 11:35:12', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4567', 'Cotorra', 'COL', '2016-12-13 11:19:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4568', 'Cota', 'COL', '2016-12-13 11:19:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4569', 'Cogua', 'COL', '2016-12-13 11:19:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4570', 'Coello', 'COL', '2016-12-13 11:19:44', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4571', 'Ciudad Bolívar', 'COL', '2016-12-13 11:35:28', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4572', 'Chiquinquirá', 'COL', '2016-12-13 11:35:34', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4573', 'Chinchiná', 'COL', '2016-12-13 11:35:41', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4574', 'Chía', 'COL', '2016-12-13 11:35:50', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4575', 'Chaparral', 'COL', '2016-12-13 11:19:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4576', 'Caldas', 'COL', '2016-12-13 11:19:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4577', 'Calarcá', 'COL', '2016-12-13 11:35:54', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4578', 'Cajicá', 'COL', '2016-12-13 11:36:01', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4579', 'Cajamarca', 'COL', '2016-12-13 11:19:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4580', 'Bugalagrande', 'COL', '2016-12-13 11:19:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4581', 'Betania', 'COL', '2016-12-13 11:19:45', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4582', 'Belén de Umbría', 'COL', '2016-12-13 11:36:14', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4583', 'Barrancas', 'COL', '2016-12-13 11:19:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4584', 'Barbosa', 'COL', '2016-12-13 11:19:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4585', 'Arauca', 'COL', '2016-12-13 11:19:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4586', 'Barahona', 'DOM', '2016-12-13 11:19:46', '0000-00-00 00:00:00', '1');
INSERT INTO `cities` (`city_id`, `name`, `country_code`, `created_at`, `updated_at`, `active`) VALUES ('4587', 'Por Establecer', 'N/A', '2016-12-13 11:19:38', '0000-00-00 00:00:00', '1');


#
# TABLE STRUCTURE FOR: client_types
#

DROP TABLE IF EXISTS `client_types`;

CREATE TABLE `client_types` (
  `client_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`client_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO `client_types` (`client_type_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('1', 'Afiliado', '2017-07-26 23:51:23', '2017-12-18 10:28:38', '1');
INSERT INTO `client_types` (`client_type_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('2', 'No Afiliado', '2017-07-26 23:51:29', '2017-12-11 11:39:10', '1');
INSERT INTO `client_types` (`client_type_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('3', 'Estudiante de Pregrado', '2017-12-11 11:39:53', '0000-00-00 00:00:00', '1');
INSERT INTO `client_types` (`client_type_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('4', 'Internacional', '2017-12-11 11:39:57', '0000-00-00 00:00:00', '1');
INSERT INTO `client_types` (`client_type_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('5', 'ALASEHT', '2017-12-11 11:40:11', '0000-00-00 00:00:00', '1');
INSERT INTO `client_types` (`client_type_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('6', 'CISPROQUIM', '2017-12-18 10:27:53', '2017-12-18 10:28:50', '1');
INSERT INTO `client_types` (`client_type_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('7', 'RUC', '2017-12-18 10:28:52', '0000-00-00 00:00:00', '1');


#
# TABLE STRUCTURE FOR: clients
#

DROP TABLE IF EXISTS `clients`;

CREATE TABLE `clients` (
  `client_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `person_type_id` int(11) NOT NULL,
  `client_type_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `document_type_id` int(11) NOT NULL,
  `document_number` bigint(20) NOT NULL,
  `city_id_citizenship` int(11) NOT NULL,
  `address` varchar(100) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `cellphone_number` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `company` varchar(100) NOT NULL,
  `position` varchar(100) NOT NULL,
  `habeas_data` tinyint(1) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by_user_id` bigint(20) NOT NULL,
  `updated_by_user_id` bigint(20) DEFAULT NULL,
  `offline_mode_create` tinyint(1) NOT NULL DEFAULT '0',
  `offline_mode_update` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=526 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: consultant_clasifications
#

DROP TABLE IF EXISTS `consultant_clasifications`;

CREATE TABLE `consultant_clasifications` (
  `consultant_clasification_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`consultant_clasification_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `consultant_clasifications` (`consultant_clasification_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('1', 'Senior', '2017-07-24 00:40:13', '0000-00-00 00:00:00', '1');
INSERT INTO `consultant_clasifications` (`consultant_clasification_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('2', 'Junior', '2017-12-11 13:58:08', '0000-00-00 00:00:00', '1');
INSERT INTO `consultant_clasifications` (`consultant_clasification_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('3', 'Virtual', '2017-12-11 13:58:12', '0000-00-00 00:00:00', '1');


#
# TABLE STRUCTURE FOR: countries
#

DROP TABLE IF EXISTS `countries`;

CREATE TABLE `countries` (
  `country_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `name_EN` varchar(100) NOT NULL,
  `country_code` varchar(5) NOT NULL,
  `icon` varchar(50) NOT NULL,
  `latitude` varchar(20) NOT NULL,
  `longitude` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`country_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO `countries` (`country_id`, `name`, `name_EN`, `country_code`, `icon`, `latitude`, `longitude`, `created_at`, `updated_at`, `active`) VALUES ('1', 'Colombia', 'Colombia', 'COL', 'img_flag_flat_colombia', '3.908099', '-73.729248', '2016-12-12 12:56:08', '2016-10-28 19:14:14', '1');
INSERT INTO `countries` (`country_id`, `name`, `name_EN`, `country_code`, `icon`, `latitude`, `longitude`, `created_at`, `updated_at`, `active`) VALUES ('2', 'México', 'Mexico', 'MEX', 'img_flag_flat_mexico', '23.885838', '-102.458496', '2016-12-12 12:58:11', '2016-10-30 12:27:28', '1');
INSERT INTO `countries` (`country_id`, `name`, `name_EN`, `country_code`, `icon`, `latitude`, `longitude`, `created_at`, `updated_at`, `active`) VALUES ('3', 'Brasil', 'Brazil', 'BRA', 'img_flag_flat_brazil', '-9.0226194', '-56.0164594', '2016-12-12 12:55:06', '0000-00-00 00:00:00', '1');
INSERT INTO `countries` (`country_id`, `name`, `name_EN`, `country_code`, `icon`, `latitude`, `longitude`, `created_at`, `updated_at`, `active`) VALUES ('4', 'Estados Unidos', 'United States', 'USA', 'img_flag_flat_usa', '39.639538', '-101.118164', '2016-12-12 12:58:47', '0000-00-00 00:00:00', '1');
INSERT INTO `countries` (`country_id`, `name`, `name_EN`, `country_code`, `icon`, `latitude`, `longitude`, `created_at`, `updated_at`, `active`) VALUES ('5', 'Perú', 'Peru', 'PER', 'img_flag_flat_peru', '-10.919618', '-75.915527', '2016-12-12 12:58:55', '0000-00-00 00:00:00', '1');
INSERT INTO `countries` (`country_id`, `name`, `name_EN`, `country_code`, `icon`, `latitude`, `longitude`, `created_at`, `updated_at`, `active`) VALUES ('6', 'Ecuador', 'Ecuador', 'ECU', 'img_flag_flat_ecuador', '-1.428075', '-78.535767', '2016-12-12 12:57:14', '0000-00-00 00:00:00', '1');
INSERT INTO `countries` (`country_id`, `name`, `name_EN`, `country_code`, `icon`, `latitude`, `longitude`, `created_at`, `updated_at`, `active`) VALUES ('7', 'Chile', 'Chile', 'CHL', 'img_flag_flat_chile', '-26.902477', '-70.290527', '2016-12-12 12:59:26', '0000-00-00 00:00:00', '1');
INSERT INTO `countries` (`country_id`, `name`, `name_EN`, `country_code`, `icon`, `latitude`, `longitude`, `created_at`, `updated_at`, `active`) VALUES ('8', 'Uruguay', 'Uruguay', 'URY', 'img_flag_flat_uruguay', '-32.814978', '-55.958862', '2016-12-12 13:01:12', '0000-00-00 00:00:00', '1');
INSERT INTO `countries` (`country_id`, `name`, `name_EN`, `country_code`, `icon`, `latitude`, `longitude`, `created_at`, `updated_at`, `active`) VALUES ('9', 'Paraguay', 'Paraguay', 'PRY', 'img_flag_flat_paraguay', '-23.261534', '-58.502197', '2016-12-12 13:02:09', '0000-00-00 00:00:00', '1');
INSERT INTO `countries` (`country_id`, `name`, `name_EN`, `country_code`, `icon`, `latitude`, `longitude`, `created_at`, `updated_at`, `active`) VALUES ('10', 'Bolivia', 'Bolivia', 'BOL', 'img_flag_flat_bolivia', '-16.783506', '-64.632568', '2016-12-12 13:02:41', '0000-00-00 00:00:00', '1');
INSERT INTO `countries` (`country_id`, `name`, `name_EN`, `country_code`, `icon`, `latitude`, `longitude`, `created_at`, `updated_at`, `active`) VALUES ('11', 'Venezuela', 'Venezuela', 'VEN', 'img_flag_flat_venezuela', '7.144499', '-66.2146', '2016-12-12 12:56:38', '0000-00-00 00:00:00', '1');
INSERT INTO `countries` (`country_id`, `name`, `name_EN`, `country_code`, `icon`, `latitude`, `longitude`, `created_at`, `updated_at`, `active`) VALUES ('12', 'Argentina', 'Argentina', 'ARG', 'img_flag_flat_argentina', '-35.173808', '-65.01709', '2016-12-12 13:02:53', '0000-00-00 00:00:00', '1');


#
# TABLE STRUCTURE FOR: document_types
#

DROP TABLE IF EXISTS `document_types`;

CREATE TABLE `document_types` (
  `document_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`document_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `document_types` (`document_type_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('1', 'Cédula de Ciudadanía', '2017-07-23 23:16:19', '0000-00-00 00:00:00', '1');
INSERT INTO `document_types` (`document_type_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('2', 'Pasaporte', '2017-07-23 23:16:23', '0000-00-00 00:00:00', '1');
INSERT INTO `document_types` (`document_type_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('3', 'NIT', '2017-12-18 10:29:52', '0000-00-00 00:00:00', '1');
INSERT INTO `document_types` (`document_type_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('4', 'Tarjeta de Identidad', '2017-12-18 10:31:06', '0000-00-00 00:00:00', '1');
INSERT INTO `document_types` (`document_type_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('5', 'Cédula de Extranjería', '2017-12-18 10:31:15', '0000-00-00 00:00:00', '1');


#
# TABLE STRUCTURE FOR: event_assistance_types
#

DROP TABLE IF EXISTS `event_assistance_types`;

CREATE TABLE `event_assistance_types` (
  `event_assistance_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`event_assistance_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `event_assistance_types` (`event_assistance_type_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('1', 'Presencial', '2017-07-17 09:01:20', '2017-07-18 15:46:27', '1');
INSERT INTO `event_assistance_types` (`event_assistance_type_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('2', 'Semipresencial', '2017-07-17 09:01:25', '2017-07-18 15:46:47', '1');
INSERT INTO `event_assistance_types` (`event_assistance_type_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('3', 'Virtual', '2017-07-18 15:46:50', '2017-07-18 15:46:55', '1');


#
# TABLE STRUCTURE FOR: event_audience_types
#

DROP TABLE IF EXISTS `event_audience_types`;

CREATE TABLE `event_audience_types` (
  `event_audience_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`event_audience_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `event_audience_types` (`event_audience_type_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('1', 'Abierto', '2017-07-18 15:53:03', '0000-00-00 00:00:00', '1');
INSERT INTO `event_audience_types` (`event_audience_type_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('2', 'Cerrado', '2017-07-18 15:53:09', '2017-12-14 16:24:57', '1');


#
# TABLE STRUCTURE FOR: event_client_comments
#

DROP TABLE IF EXISTS `event_client_comments`;

CREATE TABLE `event_client_comments` (
  `event_client_comment_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) NOT NULL,
  `client_id` bigint(20) NOT NULL,
  `improve` varchar(500) DEFAULT NULL,
  `comment` varchar(500) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`event_client_comment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: event_client_payment
#

DROP TABLE IF EXISTS `event_client_payment`;

CREATE TABLE `event_client_payment` (
  `event_client_payment_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_client_id` bigint(20) NOT NULL,
  `payment_type_id` int(11) NOT NULL,
  `payment_method_id` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `isCompanyPaying_nit_company` bigint(20) DEFAULT NULL,
  `isArlPaying_arl_id` int(11) DEFAULT NULL,
  `comment` varchar(200) DEFAULT NULL,
  `isPaid` tinyint(1) NOT NULL,
  `paid_date` date DEFAULT NULL,
  `invoice_code` varchar(100) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `created_by_user_id` bigint(20) NOT NULL,
  `updated_by_user_id` bigint(20) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `offline_mode_create` tinyint(1) NOT NULL DEFAULT '0',
  `offline_mode_update` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`event_client_payment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: event_client_topics
#

DROP TABLE IF EXISTS `event_client_topics`;

CREATE TABLE `event_client_topics` (
  `event_client_topic_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_client_id` bigint(20) NOT NULL,
  `event_topic_id` bigint(20) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `created_by_user_id` bigint(20) NOT NULL,
  `updated_by_user_id` bigint(20) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `offline_mode` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`event_client_topic_id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: event_clients
#

DROP TABLE IF EXISTS `event_clients`;

CREATE TABLE `event_clients` (
  `event_client_id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) NOT NULL,
  `client_id` bigint(20) NOT NULL,
  `state_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by_user_id` bigint(20) NOT NULL,
  `offline_mode` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`event_client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: event_guests
#

DROP TABLE IF EXISTS `event_guests`;

CREATE TABLE `event_guests` (
  `event_guest_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `reply_to_invitation` tinyint(1) NOT NULL DEFAULT '0',
  `isInterested` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by_user_id` bigint(20) NOT NULL,
  PRIMARY KEY (`event_guest_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: event_intentions
#

DROP TABLE IF EXISTS `event_intentions`;

CREATE TABLE `event_intentions` (
  `event_intentions_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `city_id` int(11) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`event_intentions_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: event_locations
#

DROP TABLE IF EXISTS `event_locations`;

CREATE TABLE `event_locations` (
  `event_location_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) NOT NULL,
  `city_id` int(11) NOT NULL,
  `place` varchar(100) NOT NULL,
  `date_from` date NOT NULL,
  `date_until` date NOT NULL,
  `total_hours` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`event_location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: event_projections
#

DROP TABLE IF EXISTS `event_projections`;

CREATE TABLE `event_projections` (
  `event_projection_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) NOT NULL,
  `projected_guests` int(11) DEFAULT NULL,
  `projected_pre_registered` int(11) DEFAULT NULL,
  `projected_confirmed` int(11) DEFAULT NULL,
  `projected_assistants` int(11) DEFAULT NULL,
  `projected_new_clients` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by_user_id` bigint(20) NOT NULL,
  `updated_by_user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`event_projection_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: event_resources
#

DROP TABLE IF EXISTS `event_resources`;

CREATE TABLE `event_resources` (
  `event_resource_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) NOT NULL,
  `url_logo_event` varchar(100) NOT NULL,
  `url_template_certificate` varchar(100) NOT NULL,
  `isLandingRequired` tinyint(1) NOT NULL DEFAULT '0',
  `url_logo_landing` varchar(100) DEFAULT NULL,
  `landing_description` varchar(1000) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by_user_id` bigint(20) NOT NULL,
  `updated_by_user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`event_resource_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: event_scores
#

DROP TABLE IF EXISTS `event_scores`;

CREATE TABLE `event_scores` (
  `event_score_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) NOT NULL,
  `isScoreRequired` tinyint(1) NOT NULL,
  `score_assistance` double DEFAULT NULL,
  `score_attention` double DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by_user_id` bigint(20) NOT NULL,
  `updated_by_user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`event_score_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: event_survey_clients
#

DROP TABLE IF EXISTS `event_survey_clients`;

CREATE TABLE `event_survey_clients` (
  `event_survey_client_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_survey_id` bigint(20) NOT NULL,
  `client_id` bigint(20) NOT NULL,
  `score` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`event_survey_client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: event_surveys
#

DROP TABLE IF EXISTS `event_surveys`;

CREATE TABLE `event_surveys` (
  `event_survey_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) NOT NULL,
  `question` varchar(200) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `created_by_user_id` bigint(20) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`event_survey_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: event_topics
#

DROP TABLE IF EXISTS `event_topics`;

CREATE TABLE `event_topics` (
  `event_topic_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) NOT NULL,
  `topic_id` bigint(20) NOT NULL,
  `provider_id` bigint(20) NOT NULL,
  `date_hour` datetime NOT NULL,
  `url_memories` varchar(100) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by_user_id` bigint(20) NOT NULL,
  PRIMARY KEY (`event_topic_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: event_types
#

DROP TABLE IF EXISTS `event_types`;

CREATE TABLE `event_types` (
  `event_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`event_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `event_types` (`event_type_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('1', 'Cursos o Diplomados', '2017-07-18 15:45:52', '0000-00-00 00:00:00', '1');
INSERT INTO `event_types` (`event_type_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('2', 'Macro Evento', '2017-07-18 15:45:57', '0000-00-00 00:00:00', '1');


#
# TABLE STRUCTURE FOR: events
#

DROP TABLE IF EXISTS `events`;

CREATE TABLE `events` (
  `event_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `date_from` date NOT NULL,
  `date_until` date NOT NULL,
  `event_assistance_type_id` int(11) NOT NULL,
  `event_type_id` int(11) NOT NULL,
  `event_audience_type_id` int(11) NOT NULL,
  `training_platform_id` int(11) NOT NULL,
  `city_id` int(11) NOT NULL,
  `place` varchar(200) NOT NULL,
  `total_hours` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by_user_id` bigint(20) NOT NULL,
  `updated_by_user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: modules
#

DROP TABLE IF EXISTS `modules`;

CREATE TABLE `modules` (
  `module_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `alias` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`module_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `modules` (`module_id`, `name`, `alias`, `created_at`, `updated_at`, `active`) VALUES ('1', 'Home', 'home', '2017-12-30 14:49:10', '2017-12-30 15:20:31', '1');
INSERT INTO `modules` (`module_id`, `name`, `alias`, `created_at`, `updated_at`, `active`) VALUES ('2', 'Dashboard', 'dashboard', '2017-12-30 14:49:14', '2017-12-30 15:20:34', '1');
INSERT INTO `modules` (`module_id`, `name`, `alias`, `created_at`, `updated_at`, `active`) VALUES ('3', 'Eventos', 'events', '2017-12-30 14:49:45', '2017-12-30 15:20:37', '1');
INSERT INTO `modules` (`module_id`, `name`, `alias`, `created_at`, `updated_at`, `active`) VALUES ('4', 'Temáticas', 'topics', '2017-12-30 14:49:51', '2017-12-30 15:20:39', '1');
INSERT INTO `modules` (`module_id`, `name`, `alias`, `created_at`, `updated_at`, `active`) VALUES ('5', 'Proveedores', 'providers', '2017-12-30 14:49:55', '2017-12-30 15:20:41', '1');
INSERT INTO `modules` (`module_id`, `name`, `alias`, `created_at`, `updated_at`, `active`) VALUES ('6', 'Clientes', 'clients', '2017-12-30 14:49:59', '2017-12-30 15:20:44', '1');
INSERT INTO `modules` (`module_id`, `name`, `alias`, `created_at`, `updated_at`, `active`) VALUES ('7', 'Usuarios', 'users', '2017-12-30 14:50:03', '2017-12-30 15:20:46', '1');
INSERT INTO `modules` (`module_id`, `name`, `alias`, `created_at`, `updated_at`, `active`) VALUES ('8', 'Configuraciones', 'settings', '2017-12-30 14:50:09', '2017-12-30 15:20:49', '1');


#
# TABLE STRUCTURE FOR: payment_methods
#

DROP TABLE IF EXISTS `payment_methods`;

CREATE TABLE `payment_methods` (
  `payment_method_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`payment_method_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `payment_methods` (`payment_method_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('1', 'Efectivo', '2017-12-18 13:10:30', '0000-00-00 00:00:00', '1');
INSERT INTO `payment_methods` (`payment_method_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('2', 'Cheque', '2017-12-18 13:10:32', '0000-00-00 00:00:00', '1');
INSERT INTO `payment_methods` (`payment_method_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('3', 'Tarjeta de Crédito', '2017-12-18 13:10:44', '0000-00-00 00:00:00', '1');
INSERT INTO `payment_methods` (`payment_method_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('4', 'Tarjeta Débito', '2017-12-18 13:10:49', '0000-00-00 00:00:00', '1');
INSERT INTO `payment_methods` (`payment_method_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('5', 'Carta Empresa', '2017-12-18 13:10:59', '0000-00-00 00:00:00', '1');
INSERT INTO `payment_methods` (`payment_method_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('6', 'No Aplica', '2017-12-18 13:12:09', '0000-00-00 00:00:00', '1');


#
# TABLE STRUCTURE FOR: payment_types
#

DROP TABLE IF EXISTS `payment_types`;

CREATE TABLE `payment_types` (
  `payment_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`payment_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `payment_types` (`payment_type_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('1', 'ARL', '2017-07-26 10:55:50', '0000-00-00 00:00:00', '1');
INSERT INTO `payment_types` (`payment_type_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('2', 'PERSONA NATURAL', '2017-07-26 10:56:21', '2017-12-22 13:43:54', '1');
INSERT INTO `payment_types` (`payment_type_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('3', 'BECA', '2017-07-26 10:56:26', '2017-12-18 13:01:19', '1');
INSERT INTO `payment_types` (`payment_type_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('4', 'EMPRESA', '2017-07-26 10:56:31', '2017-12-18 13:01:17', '1');


#
# TABLE STRUCTURE FOR: permissions
#

DROP TABLE IF EXISTS `permissions`;

CREATE TABLE `permissions` (
  `permission_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `alias` varchar(100) NOT NULL,
  `module_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`permission_id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=latin1;

INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('1', 'Estadisticas de Plataforma', 'DASHBOARD_PLATFORM', '2', '2017-08-09 10:51:34', '2017-12-30 16:30:57', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('2', 'Creación de Evento Presencial', 'CREATE_PRESENTIAL_EVENT', '3', '2017-08-09 10:51:39', '2017-12-30 19:17:28', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('3', 'Ver Listado de Eventos', 'VIEW_EVENTS', '3', '2017-08-09 10:51:44', '2017-12-30 16:37:43', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('5', 'Invitación de Clientes', 'INVITE_EVENT', '3', '2017-08-09 10:51:54', '2017-12-30 16:38:25', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('6', 'Pre-registro de Clientes', 'PRE_REGISTER_EVENT', '3', '2017-08-09 10:52:01', '2017-12-30 16:32:01', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('7', 'Confirmación de Clientes', 'CONFIRM_EVENT', '3', '2017-08-09 10:52:07', '2017-12-30 16:32:08', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('8', 'Asistencia de Clientes', 'ASSISTANCE_EVENT', '3', '2017-08-09 10:52:12', '2017-12-30 16:32:20', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('9', 'Asignación de Temáticas e Instructores a Evento', 'ASSIGN_TOPICS', '3', '2017-08-09 10:52:18', '2017-12-30 16:38:36', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('10', 'Asignación de Encuesta', 'ASSIGN_SURVEY', '3', '2017-08-09 10:52:24', '2017-12-30 16:33:00', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('11', 'Estadisticas por Evento', 'DASHBOARD_EVENT', '2', '2017-08-09 10:52:31', '2017-12-30 16:33:17', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('12', 'Ver Listado de Temáticas', 'VIEW_TOPICS', '4', '2017-08-09 10:52:38', '2017-12-30 16:34:50', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('13', 'Crear Temática', 'CREATE_TOPIC', '4', '2017-08-09 10:52:43', '2017-12-30 16:33:37', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('14', 'Editar Temática', 'EDIT_TOPIC', '4', '2017-08-09 10:52:50', '2017-12-30 16:33:44', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('15', 'Ver Listado de Proveedores', 'VIEW_PROVIDERS', '5', '2017-08-09 10:52:56', '2017-12-30 16:38:48', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('16', 'Crear Proveedor', 'CREATE_PROVIDERS', '5', '2017-08-09 10:53:02', '2017-12-30 16:38:54', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('17', 'Editar Proveedor', 'EDIT_PROVIDERS', '5', '2017-08-09 10:53:07', '2017-12-30 16:39:02', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('18', 'Ver Listado de Clientes', 'VIEW_CLIENTS', '6', '2017-08-09 10:53:14', '2017-12-30 16:39:09', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('19', 'Crear Cliente', 'CREATE_CLIENTS', '6', '2017-08-09 10:53:19', '2017-12-30 16:39:15', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('20', 'Editar Cliente', 'EDIT_CLIENTS', '6', '2017-08-09 10:53:25', '2017-12-30 16:39:20', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('21', 'Ver Listado de Usuarios', 'VIEW_USERS', '7', '2017-08-09 10:53:31', '2017-12-30 16:39:30', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('22', 'Crear Usuario', 'CREATE_USERS', '7', '2017-08-09 10:53:35', '2017-12-30 16:39:35', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('23', 'Editar Usuario', 'EDIT_USERS', '7', '2017-08-09 10:53:37', '2017-12-30 16:39:40', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('24', 'Calendario de Eventos', 'EVENTS_CALENDAR', '1', '2017-12-30 19:05:07', '2017-12-30 19:05:33', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('25', 'Descarga Reporte Pre-registrados', 'PREREGISTER_REPORT', '2', '2017-12-30 19:08:35', '2017-12-30 19:08:58', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('26', 'Descarga Reporte Confirmados', 'CONFIRMED_REPORT', '2', '2017-12-30 19:08:48', '2017-12-30 19:08:59', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('27', 'Descarga Reporte Asistencia', 'ASSISTANCE_REPORT', '2', '2017-12-30 19:09:12', '2017-12-30 19:09:19', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('28', 'Descarga Reporte Respuestas Encuesta', 'SURVEY_REPORT', '2', '2017-12-30 19:09:37', '2017-12-30 19:09:47', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('29', 'Ver Detalle de Evento', 'VIEW_EVENT_DETAIL', '3', '2017-12-30 19:12:50', '2017-12-30 19:13:02', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('30', 'Asignación de Artes', 'ADD_DESIGN_EVENT', '3', '2017-12-30 19:14:01', '2017-12-30 19:14:58', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('31', 'Asignación de Calificaciones', 'ADD_SCORE_EVENT', '3', '2017-12-30 19:14:08', '2017-12-30 19:15:07', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('32', 'Asignación de Proyección de Evento', 'ADD_PROJECTION_EVENT', '3', '2017-12-30 19:14:42', '2017-12-30 19:15:14', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('33', 'Creación Evento Virtual', 'CREATE_VIRTUAL_EVENT', '3', '2017-12-30 19:16:25', '2017-12-30 19:18:02', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('34', 'Subir Calificaciones de Estudiantes', 'SCORE_CLIENTS_EVENTS', '3', '2017-12-30 19:21:18', '2017-12-30 19:21:29', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('35', 'Ver Detalle de Temática', 'VIEW_DETAIL_TOPIC', '4', '2017-12-30 19:23:25', '2017-12-30 19:23:33', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('36', 'Ver Detalle de Proveedor', 'VIEW_DETAIL_PROVIDER', '5', '2017-12-30 19:23:58', '2017-12-30 19:24:06', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('37', 'Ver Detalle de Cliente', 'VIEW_DETAIL_CLIENT', '6', '2017-12-30 19:24:55', '2017-12-30 19:25:07', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('38', 'Ver Detalle de Usuario', 'VIEW_DETAIL_USER', '7', '2017-12-30 19:25:54', '2017-12-30 19:26:25', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('39', 'Resetear Contrasena de Usuario', 'RESET_PASSWORD_USER', '7', '2017-12-30 19:27:13', '2017-12-30 19:27:22', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('40', 'Activar/Inactivar Usuario', 'ENABLE_USER', '7', '2017-12-30 19:27:38', '2017-12-30 19:27:48', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('41', 'Ver Listado de Perfiles', 'VIEW_PROFILES', '8', '2017-12-30 19:28:20', '2017-12-30 19:28:30', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('42', 'Asignar Permisos a Perfil', 'EDIT_PERMISSIONS_PROFILE', '8', '2017-12-30 19:29:11', '2017-12-30 21:35:04', '1');
INSERT INTO `permissions` (`permission_id`, `name`, `alias`, `module_id`, `created_at`, `updated_at`, `active`) VALUES ('44', 'Sincronización Modo Offline', 'SYNC_OFFLINE_DATA', '8', '2018-01-04 20:16:47', '2018-01-04 20:16:51', '1');


#
# TABLE STRUCTURE FOR: person_types
#

DROP TABLE IF EXISTS `person_types`;

CREATE TABLE `person_types` (
  `person_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`person_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `person_types` (`person_type_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('1', 'Natural', '2017-12-18 11:14:24', '0000-00-00 00:00:00', '1');
INSERT INTO `person_types` (`person_type_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('2', 'Jurídica', '2017-12-18 11:14:34', '0000-00-00 00:00:00', '1');


#
# TABLE STRUCTURE FOR: profile_permissions
#

DROP TABLE IF EXISTS `profile_permissions`;

CREATE TABLE `profile_permissions` (
  `profile_permission_id` int(11) NOT NULL AUTO_INCREMENT,
  `profile_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `created_by_user_id` bigint(20) NOT NULL,
  `updated_by_user_id` bigint(20) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`profile_permission_id`)
) ENGINE=InnoDB AUTO_INCREMENT=267 DEFAULT CHARSET=latin1;

INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('82', '1', '1', '2017-12-30 18:55:04', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('83', '1', '11', '2017-12-30 18:55:05', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('84', '1', '10', '2017-12-30 18:55:09', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('85', '1', '9', '2017-12-30 18:55:10', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('86', '1', '8', '2017-12-30 18:55:11', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('87', '1', '7', '2017-12-30 18:55:12', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('88', '1', '2', '2017-12-30 18:55:13', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('90', '1', '5', '2017-12-30 18:55:15', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('91', '1', '6', '2017-12-30 18:55:15', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('92', '1', '3', '2017-12-30 18:55:16', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('93', '1', '13', '2017-12-30 18:55:20', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('94', '1', '14', '2017-12-30 18:55:21', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('95', '1', '12', '2017-12-30 18:55:22', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('96', '1', '16', '2017-12-30 18:55:26', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('97', '1', '17', '2017-12-30 18:55:26', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('98', '1', '15', '2017-12-30 18:55:27', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('99', '1', '19', '2017-12-30 18:55:30', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('100', '1', '20', '2017-12-30 18:55:31', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('101', '1', '18', '2017-12-30 18:55:31', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('102', '1', '22', '2017-12-30 18:55:34', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('103', '1', '23', '2017-12-30 18:55:35', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('104', '1', '21', '2017-12-30 18:55:36', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('105', '1', '24', '2017-12-30 19:30:59', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('106', '1', '27', '2017-12-30 19:31:02', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('107', '1', '26', '2017-12-30 19:31:04', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('108', '1', '25', '2017-12-30 19:31:05', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('109', '1', '28', '2017-12-30 19:31:05', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('110', '1', '30', '2017-12-30 19:31:09', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('111', '1', '31', '2017-12-30 19:31:10', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('112', '1', '32', '2017-12-30 19:31:11', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('113', '1', '33', '2017-12-30 19:31:13', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('114', '1', '34', '2017-12-30 19:31:14', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('115', '1', '29', '2017-12-30 19:31:16', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('116', '1', '35', '2017-12-30 19:31:19', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('117', '1', '36', '2017-12-30 19:31:22', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('118', '1', '37', '2017-12-30 19:31:24', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('119', '1', '40', '2017-12-30 19:31:27', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('120', '1', '39', '2017-12-30 19:31:28', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('121', '1', '38', '2017-12-30 19:31:29', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('122', '1', '43', '2017-12-30 19:31:31', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('123', '1', '41', '2017-12-30 19:31:32', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('124', '1', '42', '2017-12-30 19:31:32', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('125', '2', '24', '2017-12-30 21:37:13', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('126', '2', '27', '2017-12-30 21:37:16', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('127', '2', '26', '2017-12-30 21:37:17', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('128', '2', '25', '2017-12-30 21:37:18', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('129', '2', '28', '2017-12-30 21:37:18', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('130', '2', '1', '2017-12-30 21:37:19', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('131', '2', '11', '2017-12-30 21:37:20', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('132', '2', '3', '2017-12-30 21:37:33', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('133', '2', '29', '2017-12-30 21:37:35', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('134', '2', '30', '2017-12-30 21:37:52', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('135', '2', '31', '2017-12-30 21:37:53', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('136', '2', '10', '2017-12-30 21:37:54', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('137', '2', '32', '2017-12-30 21:37:54', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('138', '2', '9', '2017-12-30 21:37:55', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('139', '2', '8', '2017-12-30 21:37:56', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('140', '2', '7', '2017-12-30 21:37:57', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('141', '2', '2', '2017-12-30 21:37:58', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('142', '2', '33', '2017-12-30 21:37:59', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('144', '2', '5', '2017-12-30 21:38:01', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('145', '2', '6', '2017-12-30 21:38:02', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('146', '2', '34', '2017-12-30 21:38:03', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('147', '2', '13', '2017-12-30 21:38:07', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('148', '2', '14', '2017-12-30 21:38:07', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('149', '2', '35', '2017-12-30 21:38:08', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('150', '2', '12', '2017-12-30 21:38:09', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('151', '2', '16', '2017-12-30 21:38:11', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('152', '2', '17', '2017-12-30 21:38:12', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('153', '2', '36', '2017-12-30 21:38:12', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('154', '2', '15', '2017-12-30 21:38:13', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('155', '2', '19', '2017-12-30 21:38:20', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('156', '2', '20', '2017-12-30 21:38:21', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('157', '2', '37', '2017-12-30 21:38:23', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('158', '2', '18', '2017-12-30 21:38:23', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('159', '2', '40', '2017-12-30 21:38:26', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('160', '2', '22', '2017-12-30 21:38:27', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('161', '2', '23', '2017-12-30 21:38:28', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('162', '2', '39', '2017-12-30 21:38:29', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('163', '2', '38', '2017-12-30 21:38:30', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('164', '2', '21', '2017-12-30 21:38:32', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('165', '2', '42', '2017-12-30 21:38:41', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('166', '2', '41', '2017-12-30 21:38:45', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('167', '6', '24', '2017-12-30 21:39:11', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('168', '6', '11', '2017-12-30 21:39:14', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('169', '6', '1', '2017-12-30 21:39:16', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('170', '6', '28', '2017-12-30 21:39:24', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('171', '6', '25', '2017-12-30 21:39:25', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('172', '6', '26', '2017-12-30 21:39:26', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('173', '6', '27', '2017-12-30 21:39:27', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('174', '6', '3', '2017-12-30 21:39:31', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('175', '6', '29', '2017-12-30 21:39:33', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('176', '6', '12', '2017-12-30 21:40:06', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('177', '6', '35', '2017-12-30 21:40:07', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('178', '6', '36', '2017-12-30 21:40:16', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('179', '6', '15', '2017-12-30 21:40:17', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('180', '6', '18', '2017-12-30 21:40:20', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('181', '6', '37', '2017-12-30 21:40:20', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('182', '7', '24', '2017-12-30 21:40:35', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('183', '7', '27', '2017-12-30 21:40:39', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('184', '7', '26', '2017-12-30 21:40:40', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('185', '7', '25', '2017-12-30 21:40:41', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('186', '7', '1', '2017-12-30 21:40:44', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('187', '7', '11', '2017-12-30 21:40:46', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('188', '7', '3', '2017-12-30 21:40:53', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('189', '7', '29', '2017-12-30 21:40:54', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('190', '7', '6', '2017-12-30 21:40:58', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('191', '7', '5', '2017-12-30 21:40:59', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('192', '7', '7', '2017-12-30 21:41:02', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('193', '7', '8', '2017-12-30 21:41:04', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('194', '7', '37', '2017-12-30 21:41:24', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('195', '7', '18', '2017-12-30 21:41:25', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('196', '7', '19', '2017-12-30 21:41:26', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('197', '7', '20', '2017-12-30 21:41:28', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('198', '4', '24', '2017-12-30 21:41:43', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('199', '4', '11', '2017-12-30 21:41:46', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('200', '4', '1', '2017-12-30 21:41:47', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('201', '4', '28', '2017-12-30 21:41:50', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('202', '4', '25', '2017-12-30 21:41:53', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('203', '4', '26', '2017-12-30 21:41:54', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('204', '4', '27', '2017-12-30 21:41:55', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('205', '4', '3', '2017-12-30 21:42:08', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('206', '4', '29', '2017-12-30 21:42:13', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('207', '4', '34', '2017-12-30 21:42:15', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('209', '4', '31', '2017-12-30 21:42:30', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('210', '4', '10', '2017-12-30 21:42:32', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('211', '4', '32', '2017-12-30 21:42:34', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('212', '4', '9', '2017-12-30 21:42:36', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('213', '4', '33', '2017-12-30 21:42:41', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('214', '4', '13', '2017-12-30 21:42:51', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('215', '4', '14', '2017-12-30 21:42:52', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('216', '4', '35', '2017-12-30 21:42:53', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('217', '4', '12', '2017-12-30 21:42:54', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('218', '4', '16', '2017-12-30 21:42:56', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('219', '4', '17', '2017-12-30 21:42:57', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('220', '4', '36', '2017-12-30 21:42:58', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('221', '4', '15', '2017-12-30 21:42:59', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('222', '3', '24', '2017-12-30 21:43:24', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('223', '3', '27', '2017-12-30 21:43:27', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('224', '3', '26', '2017-12-30 21:43:27', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('225', '3', '25', '2017-12-30 21:43:28', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('226', '3', '28', '2017-12-30 21:43:29', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('227', '3', '1', '2017-12-30 21:43:31', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('228', '3', '11', '2017-12-30 21:43:32', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('229', '3', '3', '2017-12-30 21:43:37', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('230', '3', '29', '2017-12-30 21:43:46', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('232', '3', '10', '2017-12-30 21:43:59', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('233', '3', '32', '2017-12-30 21:44:01', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('234', '3', '9', '2017-12-30 21:44:02', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('235', '3', '2', '2017-12-30 21:44:05', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('236', '3', '13', '2017-12-30 21:44:31', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('237', '3', '14', '2017-12-30 21:44:32', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('238', '3', '35', '2017-12-30 21:44:33', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('239', '3', '12', '2017-12-30 21:44:34', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('240', '3', '16', '2017-12-30 21:44:36', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('241', '3', '17', '2017-12-30 21:44:37', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('242', '3', '36', '2017-12-30 21:44:38', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('243', '3', '15', '2017-12-30 21:44:39', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('244', '5', '24', '2017-12-30 21:44:55', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('245', '5', '11', '2017-12-30 21:44:58', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('246', '5', '1', '2017-12-30 21:44:59', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('247', '5', '30', '2017-12-30 21:45:14', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('248', '5', '3', '2017-12-30 21:45:19', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('249', '5', '29', '2017-12-30 21:45:20', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('251', '8', '24', '2017-12-31 01:36:13', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('252', '8', '11', '2017-12-31 01:36:17', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('253', '8', '1', '2017-12-31 01:36:18', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('255', '8', '25', '2017-12-31 01:36:27', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('256', '8', '27', '2017-12-31 01:36:28', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('257', '8', '26', '2017-12-31 01:36:29', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('258', '8', '3', '2017-12-31 01:36:34', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('259', '8', '29', '2017-12-31 01:36:36', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('260', '8', '7', '2017-12-31 01:36:43', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('261', '8', '8', '2017-12-31 01:36:46', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('262', '8', '18', '2017-12-31 01:36:55', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('263', '8', '37', '2017-12-31 01:36:58', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('264', '8', '20', '2017-12-31 01:36:59', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('265', '8', '19', '2017-12-31 01:37:01', '0000-00-00 00:00:00', '0', '0', '1');
INSERT INTO `profile_permissions` (`profile_permission_id`, `profile_id`, `permission_id`, `created_at`, `updated_at`, `created_by_user_id`, `updated_by_user_id`, `active`) VALUES ('266', '1', '44', '2018-01-04 20:17:00', '0000-00-00 00:00:00', '0', '0', '1');


#
# TABLE STRUCTURE FOR: profiles
#

DROP TABLE IF EXISTS `profiles`;

CREATE TABLE `profiles` (
  `profile_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`profile_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO `profiles` (`profile_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('1', 'Superadministrador', '2017-07-16 22:49:01', '2017-07-16 22:49:02', '1');
INSERT INTO `profiles` (`profile_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('2', 'Administrador', '2017-07-16 22:49:02', '2017-07-16 22:49:06', '1');
INSERT INTO `profiles` (`profile_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('3', 'Gestor de Eventos Presenciales', '2017-08-09 11:49:36', '2017-12-19 01:53:27', '1');
INSERT INTO `profiles` (`profile_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('4', 'Gestor de Eventos EVAD', '2017-08-30 10:04:53', '2017-12-30 18:33:46', '1');
INSERT INTO `profiles` (`profile_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('5', 'Mercadeo', '2017-08-30 10:05:03', '2017-12-30 18:33:47', '1');
INSERT INTO `profiles` (`profile_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('6', 'Analista de Información', '2017-08-30 10:05:22', '2017-12-30 18:33:47', '1');
INSERT INTO `profiles` (`profile_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('7', 'Asesor Evento', '2017-08-30 16:02:13', '2017-12-30 18:33:48', '1');
INSERT INTO `profiles` (`profile_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('8', 'Tesorería', '2017-12-31 01:23:40', '2017-12-31 01:23:45', '1');


#
# TABLE STRUCTURE FOR: provider_types
#

DROP TABLE IF EXISTS `provider_types`;

CREATE TABLE `provider_types` (
  `provider_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`provider_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `provider_types` (`provider_type_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('1', 'Consultor Presencial', '2017-07-24 00:35:49', '0000-00-00 00:00:00', '1');
INSERT INTO `provider_types` (`provider_type_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('2', 'Consultor Virtual', '2017-07-24 00:35:56', '0000-00-00 00:00:00', '1');


#
# TABLE STRUCTURE FOR: providers
#

DROP TABLE IF EXISTS `providers`;

CREATE TABLE `providers` (
  `provider_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `provider_type_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `document_type_id` int(11) NOT NULL,
  `document_number` int(20) NOT NULL,
  `date_birthday` date NOT NULL,
  `date_start_ccs` date NOT NULL,
  `area_id` int(11) NOT NULL,
  `thematic_area_type_id` int(11) NOT NULL,
  `consultant_clasification_id` int(11) NOT NULL,
  `url_img_profile` varchar(100) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`provider_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: states
#

DROP TABLE IF EXISTS `states`;

CREATE TABLE `states` (
  `state_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`state_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO `states` (`state_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('1', 'Programado', '2017-07-17 08:47:45', '0000-00-00 00:00:00', '0');
INSERT INTO `states` (`state_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('2', 'Pre-registro', '2017-07-17 08:47:52', '0000-00-00 00:00:00', '0');
INSERT INTO `states` (`state_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('3', 'Confirmado sin Pago', '2017-07-17 08:47:56', '2017-12-04 09:51:57', '0');
INSERT INTO `states` (`state_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('4', 'Finalizado', '2017-07-17 08:48:38', '0000-00-00 00:00:00', '0');
INSERT INTO `states` (`state_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('5', 'Asistio', '2017-07-25 13:18:28', '0000-00-00 00:00:00', '0');
INSERT INTO `states` (`state_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('6', 'En Curso', '2017-08-04 08:39:32', '0000-00-00 00:00:00', '0');
INSERT INTO `states` (`state_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('7', 'Confirmado con Pago', '2017-12-04 09:52:07', '0000-00-00 00:00:00', '0');


#
# TABLE STRUCTURE FOR: thematic_area_types
#

DROP TABLE IF EXISTS `thematic_area_types`;

CREATE TABLE `thematic_area_types` (
  `thematic_area_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`thematic_area_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `thematic_area_types` (`thematic_area_type_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('1', 'Seguridad', '2017-07-24 00:25:51', '0000-00-00 00:00:00', '1');
INSERT INTO `thematic_area_types` (`thematic_area_type_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('2', 'Auditoria', '2017-07-25 00:49:15', '0000-00-00 00:00:00', '1');
INSERT INTO `thematic_area_types` (`thematic_area_type_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('3', 'Ambiental', '2017-12-18 10:27:34', '0000-00-00 00:00:00', '1');


#
# TABLE STRUCTURE FOR: topics
#

DROP TABLE IF EXISTS `topics`;

CREATE TABLE `topics` (
  `topic_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `thematic_area_type_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`topic_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: training_platforms
#

DROP TABLE IF EXISTS `training_platforms`;

CREATE TABLE `training_platforms` (
  `training_platform_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`training_platform_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `training_platforms` (`training_platform_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('1', 'Moodle', '2017-07-17 09:26:40', '0000-00-00 00:00:00', '1');
INSERT INTO `training_platforms` (`training_platform_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('2', 'WebEx', '2017-07-17 09:26:46', '0000-00-00 00:00:00', '1');
INSERT INTO `training_platforms` (`training_platform_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('3', 'No Aplica', '2017-07-18 10:26:13', '0000-00-00 00:00:00', '1');


#
# TABLE STRUCTURE FOR: training_types
#

DROP TABLE IF EXISTS `training_types`;

CREATE TABLE `training_types` (
  `training_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`training_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `training_types` (`training_type_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('1', 'Presencial', '2017-07-17 09:43:24', '0000-00-00 00:00:00', '1');
INSERT INTO `training_types` (`training_type_id`, `name`, `created_at`, `updated_at`, `active`) VALUES ('2', 'Virtual', '2017-07-17 09:43:30', '0000-00-00 00:00:00', '1');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `user_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `isChangePasswordRequired` tinyint(1) NOT NULL DEFAULT '1',
  `profile_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO `users` (`user_id`, `name`, `lastname`, `email`, `password`, `isChangePasswordRequired`, `profile_id`, `created_at`, `updated_at`, `active`) VALUES ('1', 'Super', 'Admin', 'superadmin@ccs.org.co', '7b724ab1bc5302eea03ebb91353a0747c35ff161', '0', '1', '2017-07-16 22:34:01', '2018-01-10 13:56:04', '1');
INSERT INTO `users` (`user_id`, `name`, `lastname`, `email`, `password`, `isChangePasswordRequired`, `profile_id`, `created_at`, `updated_at`, `active`) VALUES ('2', 'Gestor', 'Presencial', 'gestorpresencial@ccs.org.co', 'ae88d47751f084754e2350ad7100494530319b28', '1', '3', '2017-07-16 22:34:01', '2018-01-10 13:58:00', '1');
INSERT INTO `users` (`user_id`, `name`, `lastname`, `email`, `password`, `isChangePasswordRequired`, `profile_id`, `created_at`, `updated_at`, `active`) VALUES ('3', 'Analista', 'Información', 'analista@ccs.org.co', 'ae88d47751f084754e2350ad7100494530319b28', '1', '6', '2017-08-30 15:35:28', '2018-01-10 13:58:00', '1');
INSERT INTO `users` (`user_id`, `name`, `lastname`, `email`, `password`, `isChangePasswordRequired`, `profile_id`, `created_at`, `updated_at`, `active`) VALUES ('4', 'Mercadeo', 'Comercial', 'mercadeo@ccs.org.co', 'ae88d47751f084754e2350ad7100494530319b28', '1', '5', '2017-08-30 15:37:34', '2018-01-10 13:58:00', '1');
INSERT INTO `users` (`user_id`, `name`, `lastname`, `email`, `password`, `isChangePasswordRequired`, `profile_id`, `created_at`, `updated_at`, `active`) VALUES ('5', 'Administrador', 'CCS', 'admin@ccs.org.co', 'ae88d47751f084754e2350ad7100494530319b28', '1', '2', '2017-08-30 16:00:34', '2018-01-10 13:58:00', '1');
INSERT INTO `users` (`user_id`, `name`, `lastname`, `email`, `password`, `isChangePasswordRequired`, `profile_id`, `created_at`, `updated_at`, `active`) VALUES ('6', 'Asesor', 'Evento', 'asesor@ccs.org.co', 'ae88d47751f084754e2350ad7100494530319b28', '1', '7', '2017-08-30 16:05:17', '2018-01-10 13:58:00', '1');
INSERT INTO `users` (`user_id`, `name`, `lastname`, `email`, `password`, `isChangePasswordRequired`, `profile_id`, `created_at`, `updated_at`, `active`) VALUES ('7', 'Gestor', 'EVAD', 'gestorevad@ccs.org.co', 'ae88d47751f084754e2350ad7100494530319b28', '1', '4', '2017-11-28 16:21:37', '2018-01-10 13:58:00', '1');
INSERT INTO `users` (`user_id`, `name`, `lastname`, `email`, `password`, `isChangePasswordRequired`, `profile_id`, `created_at`, `updated_at`, `active`) VALUES ('8', 'Tesoreria', 'Pagos', 'tesoreria@ccs.org.co', 'ae88d47751f084754e2350ad7100494530319b28', '1', '8', '2017-12-31 01:36:02', '2018-01-10 13:58:00', '1');


